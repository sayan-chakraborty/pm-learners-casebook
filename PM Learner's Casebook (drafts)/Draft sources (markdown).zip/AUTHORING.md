# Authoring guide — PM Learner's Casebook (read fully before writing)

The book is a clean, single-column A4 PDF built from Markdown files in `/home/claude/guide/content/`
(rendered alphabetically; file names are pre-assigned to you). Build a preview of YOUR files only with:
`cd /home/claude/guide && python3 build.py /tmp/<you>.pdf <substring-of-your-filenames>`
then render pages to PNG (`pdftoppm -r 60 -f N -l N -png file.pdf out`) and LOOK at a few to check diagrams.
Fix anything cramped, overlapping or unreadable. A "[gv warning] graph shrunk" message means switch arch/tree to rankdir="TB" or fewer/narrower nodes.

## Reader and voice
Reader: an MBA student preparing for product-manager interviews who wants to LEARN, not just cram.
Learning method (non-negotiable): **examples first, theory after.** Open every concept with a concrete, vivid, real-world example
(Indian products preferred: UPI, Swiggy, Zepto, Flipkart, Jio, IRCTC, etc.), then explain the mechanism in plain language, then name the
concept/framework, then give a contrasting example (where it does NOT apply / the opposite case), then "how it shows up in a PM interview".
Plain English, short sentences, no jargon without an immediate explanation, no AI-sounding filler ("in today's fast-paced world", "delve", "crucial", "leverage").
Numbers must be real (cite source + date in a figure `src:` line or inline) or clearly labelled "illustrative". Today is 24 Sep 2026.

## Markdown directives
- New chapter (starts a new page):  `%% chapter | RUBRIC | Headline | One-sentence standfirst`
- Sub-article inside a chapter (no page break): `%% article | RUBRIC | Headline | standfirst`
- Normal markdown: `##`, `###`, lists, **bold**, tables (pipe tables), `>` quotes.
- Boxes:
```
::: key Title of the box
markdown content
:::
```
  kinds: `key` (core idea, blue), `try` (exercise / think-first prompt, yellow), `words` (glossary, green), `note` (grey), `quiz` (recall questions, yellow).
- Diagrams: a fenced block with language `dia`. Optional first lines `title:`, `sub:`, `src:`; then ONE Python expression calling a function below.
```dia
title: What happens after you tap Pay
sub: A UPI payment, step by step
src: NPCI; illustrative timings
steps([("You tap Pay", "App sends request to your bank via NPCI", ""), ("Bank debits", "Checks PIN and balance", "Most failures happen here")])
```

## Diagram functions (all in dia.py — read its docstrings). Every diagram must EXPLAIN, not just label: use the description fields.
- `steps([(title, description, watch-out note)], hl=[indices to highlight red], per_row=5)` — numbered process cards.
- `vsteps([...same...])` — vertical numbered list (good for 6+ steps).
- `journey(stages, rows=[(row label, [cell per stage])], curve=[1-5 feeling per stage])` — journey map; a row label containing "pain" turns red.
- `funnel([(label, value text, share 0-1, note on drop-off)])`
- `bars([(label, value, note)], unit="", hl=[...], fmt="{:,.0f}")`, `cols([(label, value)], notes=[(idx, text)])`,
  `linechart({series: [values]}, xlabels, notes=[(series, idx, text)])`, `stack100([(row, [(segment, pct)])], note=...)`
- `waterfall([(label, value, note)], total="Contribution", takeaway="one-line so-what")` — unit economics.
- `matrix(xlabel, ylabel, [(TL title, desc), (TR...), (BL...), (BR...)], points=[(label, x0-1, y0-1)])`
- `loop([(title, desc)], center="name", center_desc="...", edges=[labels on arrows])` — flywheels / growth loops.
- `layers([(name, what it does, everyday example)])` — stacks (tech stack, OSI-like, value chain).
- `hub(center, [(title, desc)], center_desc=...)` — ecosystem / stakeholders.
- `versus(left title, [items], right title, [items], verdict="...")` items can be "text" or (title, text) — contrasts (weak vs strong, before vs after, A vs B).
- `cards([(title, desc)], ncol=3)` — small multiples of concepts.
- `pyramid([(title, desc)])`, `timeline([(date, title, desc)])`, `seq(actors, [(from, to, label, note)])` — sequence diagrams for request flows.
- `analogy([(everyday thing, tech concept, what it means)])` — the plain-language bridge (use a lot in technical sections).
- `formula([(term, description, example value)], result="Revenue ≈ ...", ops=["×","×","÷"])` — metric/guesstimate decomposition.
- `scale(left pole, right pole, [(label, position 0-1, note)])` — trade-off spectrums.
- `phone([(screen block, relative height)], [(block index, heading, explanation)])` — annotated app screens for teardowns.
- `arch({id: (title, description, tag)}, [(a, b, label, style)], clusters={label: [ids]}, rankdir="LR"|"TB")`
  tags: B blue, N navy, R red (highlight), T teal, G gold, C light blue, L outline, Y grey, M mauve; style "d" dashed, "r" red.
- `tree(["Root|desc", [["Child|desc", ["Leaf|desc", "!Culprit|desc"]]]])` — issue/metric trees; "!" highlights.
Keep text inside diagrams short (titles ≤ 5 words, descriptions ≤ 18 words). Aim for roughly one diagram per page of text.
Python strings: use double quotes; avoid unescaped double quotes inside; ₹ and – are fine.

## Style of a good section (pattern)
1. A hook: a real scene or example (2–4 sentences).
2. The mechanism explained simply, with a diagram.
3. The named concept + a `key` box with the one-line rule.
4. A contrasting example (when it breaks / the opposite).
5. "In the interview" — how it gets asked, what a strong answer says (concrete sample lines), common traps.
6. End each chapter with a `quiz` box: 5–8 recall questions (answers NOT given; they force retrieval). Mix in 1–2 questions from earlier chapters (interleaving).
