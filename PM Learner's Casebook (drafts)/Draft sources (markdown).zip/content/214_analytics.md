%% chapter | Product dossier · Analytics | From "raise a ticket" to "just ask" | ThoughtSpot lets business users search company data like Google. Amplitude shows product teams what users actually do. Both are rebuilding themselves around AI agents that answer questions without anyone writing a query.

Monday, 10 a.m., at a Bengaluru lending start-up. The head of growth wants to know why loan applications fell 12% last week. In 2016 she would have raised a ticket with the data team, waited three days for a SQL query, and received a spreadsheet that raised three new questions. In 2026 she types *"Why did applications drop last week?"* into an analytics tool. Thirty seconds later she has a chart: the drop is entirely on Android, in one app version, at the PAN-verification step. She forwards it to the engineering lead before her coffee is cold.

## The job, and the two categories

Business teams hire analytics for **"answer my question about the business now, without waiting for an analyst."** Product teams hire product analytics for **"show me what users do in my product, where they get stuck, and whether my change worked."** These are two different categories. Interviewers like candidates who can tell them apart.

```dia
title: Two kinds of analytics
versus("Business intelligence (ThoughtSpot, Tableau, Power BI)", [("Data", "Company data in a warehouse: sales, finance, operations"), ("Typical question", "Revenue by region this quarter vs last?"), ("User", "Business teams, analysts, executives")], "Product analytics (Amplitude, Mixpanel, PostHog)", [("Data", "Events: every tap, screen and action in an app"), ("Typical question", "Where do users drop in onboarding? Did the new button help?"), ("User", "PMs, growth, designers, engineers")], verdict="BI answers 'what happened to the business'. Product analytics answers 'what did users do, and why'. AI agents are now blurring the line.")
```

```dia
title: Where analytics tools sit in a company's data stack
sub: From raw data at the bottom to answers at the top
layers([("AI agents", "Ask in plain language; the agent writes queries and explains results", "Spotter, Amplitude's Global Agent"), ("Analytics apps", "Dashboards, search, funnels, retention, experiments", "ThoughtSpot, Amplitude, Tableau"), ("Semantic layer", "Shared definitions: what counts as 'active user' or 'revenue'", "Stops two teams reporting different numbers"), ("Warehouse", "All company data in one place, queried at scale", "Snowflake, BigQuery, Databricks"), ("Sources", "Apps, payments, CRM, marketing tools", "Razorpay payments, app events")])
```

The big change of 2025–26 is at the top of that stack. Large language models can now turn a plain-English question into a database query. Anyone can build a demo of that. What cannot be copied quickly is **getting the answer right**: using the company's agreed definitions, respecting who is allowed to see what, and explaining how the number was produced. Both dossiers below are bets on owning that trust layer, and both face rivals who give a "good enough" version away inside tools companies already pay for.

%% article | Analytics · ThoughtSpot | Search for your company's numbers | ThoughtSpot's founding idea was a Google-style search bar for company data. Its 2026 version is a team of AI agents that build dashboards and models for you.

**Who it is for.** Large enterprises whose business users want answers from a cloud data warehouse without learning SQL or waiting for analysts. Also software companies that want to **embed** analytics inside their own products. Founded in 2012, with large engineering teams in India. Positioning: *"AI-powered analytics for everyone."* It was named a Leader in Gartner's 2026 Magic Quadrant for analytics and BI (ThoughtSpot, Jul 2026).

**Core loop.** A user asks a question → gets a chart → asks a follow-up ("break it down by city") → saves it to a Liveboard (a live dashboard) → shares it → colleagues start asking their own questions → more users and more queries → more value, so the contract expands.

```dia
title: From a typed question to an answer
sub: What happens when you ask ThoughtSpot 'revenue by city last quarter'
src: Simplified from ThoughtSpot product documentation
steps([("You ask", "Natural-language question typed or spoken", ""), ("Semantic model", "Maps 'revenue' and 'city' to the right tables and definitions", "Bad definitions give confident wrong answers"), ("Query written", "The agent writes SQL for the warehouse", ""), ("Warehouse runs it", "Live on Snowflake or BigQuery; no data copied", "Cost per query matters"), ("Answer + why", "Chart, summary and suggested follow-ups", "User can check the query")], hl=[1])
```

| Feature | User problem | Why designed this way | Metric it moves |
|---|---|---|---|
| Search and Spotter (AI analyst) | "I can't write SQL" | Ask in plain language; follow up in conversation | Weekly active business users |
| Liveboards | "Static dashboards go stale" | Live, drillable dashboards on warehouse data | Dashboard views, shares |
| SpotterModel | Analysts: "Building data models takes weeks" | AI drafts the semantic model | Time to first answer for a new customer |
| SpotterViz | "Designing dashboards is slow" | Builds a dashboard from a description | Liveboards created |
| SpotterCode and Embedded | SaaS firms: "Our customers want analytics in our app" | Analytics components developers embed | Embedded revenue |
| Monitor and alerts | "I find out about drops too late" | Alerts when a KPI moves unusually | Alerts acted on |

**Business model.** Enterprise subscriptions priced by users or consumption, plus embedded licences. ThoughtSpot is private. It was last valued at about **$4.2 billion in 2021**.

**Moat and threats.** Its moat is search and semantic technology built over a decade, **live connection** to cloud warehouses (no copying of data), and enterprise customer relationships. The threats are strong: **Microsoft Power BI** comes bundled with Microsoft 365, **Tableau** has Salesforce behind it, **Looker** has Google, and the warehouses themselves (Snowflake, Databricks) now offer AI assistants that answer questions directly. With large language models making "ask in English" easy for everyone, ThoughtSpot's edge has to be **accuracy and trust**: whether the agent is right, and whether it can show how it knows.

**Metrics.** *North Star:* weekly active users getting answers (questions answered and acted on). *Inputs:* questions per user, share of answers saved or shared, time to first answer for new customers, embedded deployments. *Guardrails:* answer accuracy (checked against analyst-verified queries), warehouse cost per query, customer net retention.

::: key What I would build next at ThoughtSpot
1. **"Show your working" trust panel.** *Problem:* executives don't trust AI answers they can't verify. *Bet:* every answer shows the definition used, the query, and a confidence note, and analysts can certify common questions. *Metric:* share of answers used in decisions; accuracy audits passed.
2. **WhatsApp and Slack answers for field teams.** *Problem:* sales teams in the field never open dashboards. *Bet:* ask Spotter from WhatsApp (via Business API) or Slack and get a chart back. *Metric:* weekly active non-desk users.
:::

%% article | Analytics · Amplitude | The product team's microscope | Amplitude turned funnels, retention curves and cohorts into everyday tools for PMs. In 2026 it calls itself an AI analytics company.

**Who it is for.** Product, growth and marketing teams at digital companies, from start-ups to large enterprises. Positioning: *"the digital analytics platform"*, now expanded to experiments, session replay, surveys and AI agents. It was founded in 2012 and listed in 2021.

**Core loop.** Instrument the app with events → a PM builds a funnel or retention chart → finds a drop-off → designs a fix → runs an **experiment** in Amplitude → sees the lift → shares it → more teams adopt → more events tracked → the contract grows. This is **land and expand**: start with one team and grow across the company.

```dia
title: The chart that made Amplitude famous: the funnel
sub: A lending app's onboarding, weekly users; illustrative
src: Illustrative example of an Amplitude funnel analysis
funnel([("Opened app", "10,000", 1.0, ""), ("Started application", "6,200", 0.62, ""), ("PAN verified", "3,100", 0.31, "Biggest drop: Android v5.2 fails here"), ("Bank linked", "2,600", 0.26, ""), ("Loan applied", "2,300", 0.23, "Segment by device and version to find the cause")], hl=[2])
```

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Funnels, retention, cohorts | "Where do users drop? Who comes back?" | Self-serve charts on event data, no SQL | Charts created per PM |
| Experiment | "Did my change actually work?" | A/B tests with results in the same place as the analytics | Experiments run |
| Session Replay | "I see the drop but not why" | Watch recordings of real sessions at the drop point | Time to root cause |
| Guides and Surveys | "Ask users why, inside the app" | In-app messages and surveys tied to behaviour | Response rate |
| Global Agent, Wave, MCP | "I don't have time to look at every chart" | AI that watches signals and explains changes; connects to Claude and Slack | Insights acted on |
| Agent Analytics | "How do I measure my AI chatbot?" | Tracks AI agent conversations and outcomes | New AI-product customers |

**Business model and results.** Subscriptions priced by data volume and features. In Q2 2026 revenue reached **$100.9 million (+21%)**, its first $100 million quarter, **ARR $410 million (+22%)**, **824 customers paying over $100,000 a year (+30%)**, net revenue retention **105%**, and free cash flow of $23.7 million (Amplitude Q2 2026 release).

```dia
title: How a SaaS company like Amplitude grows
sub: The ARR bridge and net revenue retention (NRR)
src: Amplitude Q2 2026: ARR $410M, NRR 105% (trailing twelve months)
formula([("Starting ARR", "Recurring revenue a year ago", "$336M"), ("New customers", "Revenue from logos won this year", "+ new"), ("Expansion", "Existing customers buying more", "+ upsell"), ("Churn and contraction", "Customers leaving or cutting back", "− lost")], result="Ending ARR = start + new + expansion − churn.  NRR = (start + expansion − churn) ÷ start = 105%", ops=["+", "+", "−"])
```

An NRR of 105% means that, with no new customers at all, revenue from last year's customers grew 5%. Enterprise SaaS leaders often run at 120% or more. Amplitude's lower figure reflects cost-cutting by software customers after 2022, which is why its AI push matters.

**Moat.** **Switching costs** (years of events, charts and definitions; teams trained on it), a strong brand among PMs, and a **data network** that grows with each product added. The threats are cheaper and open-source rivals (PostHog, Mixpanel), warehouse-native analytics, and free Google Analytics.

**Metrics.** *North Star:* weekly learning users (people who view or create an analysis and act on it). *Inputs:* charts and experiments per account, seats per account, products adopted, AI-agent insights accepted. *Guardrails:* NRR, event-volume cost to customers, data accuracy incidents.

::: key What I would build next at Amplitude
1. **"Launch review" agent.** *Problem:* PMs ship features and forget to check the results. *Bet:* an agent that automatically reviews every launch after 7 and 30 days, compares it with a holdout group, and posts the result to Slack. *Metric:* share of launches with a measured result; expansion revenue.
2. **India starter plan with UPI billing.** *Problem:* Indian start-ups find dollar pricing hard at an early stage. *Bet:* a rupee plan with event limits, paid by UPI Autopay. *Metric:* Indian self-serve sign-ups; conversion to paid.
:::

## Comparing the two

| | ThoughtSpot | Amplitude |
|---|---|---|
| Category | Business intelligence, search and agents | Product analytics, experiments |
| Data | Warehouse tables | App events |
| Buyer | CIO, data leader | Head of product or growth |
| AI bet | Spotter agents: model, visualise, embed | Global Agent, Wave, Agent Analytics |
| Moat | Search tech, live warehouse connection | Switching costs, PM brand |
| Main threat | Bundled BI (Power BI), warehouse AI | Open-source and cheaper tools, warehouse-native analytics |

```dia
title: Who asks, and what data
sub: Where each tool sits (author's judgement)
matrix("Business user (not analyst)", "Behavioural event data", [("Analyst, events", "Mixpanel, PostHog: product analysts"), ("Business user, events", "Amplitude with AI agents"), ("Analyst, warehouse", "SQL notebooks, Looker"), ("Business user, warehouse", "ThoughtSpot, Power BI Copilot")], points=[("Amplitude", 0.64, 0.62), ("Mixpanel", 0.3, 0.6), ("ThoughtSpot", 0.82, 0.2), ("Power BI", 0.62, 0.12), ("Looker", 0.25, 0.2)])
```

## Likely interview questions

1. **"You're the PM for ThoughtSpot's AI agent. What's your North Star?"** Questions answered correctly and acted on. The guardrail is accuracy, audited against verified queries.
2. **"How would you sell Amplitude to a CFO?"** Frame it as revenue saved: faster diagnosis of drops, experiments that lift conversion, and fewer analyst hours.
3. **"Low adoption of a CRM or analytics tool inside a company. Diagnose."** (IIMA: low CRM adoption) Look at who was trained, whether the data can be trusted, the time to first value, and the incentives to use it.
4. **"NRR fell from 110% to 105%. What happened?"** Split it into churn, contraction and weaker expansion, by customer segment and product. Tie it to customers' budgets.
5. **"Will LLMs kill BI tools?"** They commoditise the 'ask in English' part. The value moves to trusted definitions (the semantic layer), accuracy, governance and embedding.

::: quiz Recall: analytics
1. Explain the difference between BI and product analytics with one question each would answer.
2. What is a semantic layer, and why does it matter more once AI writes the queries?
3. Draw a funnel for an app you use and mark where you would look first.
4. Define NRR and interpret Amplitude's 105%.
5. Name two threats to ThoughtSpot and one way it can defend itself.
6. What does "land and expand" mean in B2B SaaS?
7. (Gaming) Which Amplitude charts would a games PM use to track D1, D7 and D30 retention?
:::
