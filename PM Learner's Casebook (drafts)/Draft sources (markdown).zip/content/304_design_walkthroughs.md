%% chapter | Technology · System design in practice | Design it like a PM: three worked walkthroughs | A repeatable method for "design X" questions, applied to a UPI payment, a food order with live tracking, and WhatsApp-style messaging

Knowing the building blocks is half the job. The other half is putting them together under pressure: in a design review where the engineering lead asks what matters most, or in an interview that begins "Walk me through how UPI works" or "How would you design live order tracking?" This chapter gives you one method and uses it three times.

## A method for any "design X" question

A PM-level system design answer is not a list of technologies. It is a chain of reasoning that starts with the user and ends with trade-offs and metrics.

```dia
title: Eight steps for a PM-level system design answer
sub: Spend most of your time on steps 1–3 and 6–8; that is where PM judgement shows
vsteps([("Clarify the user and the goal", "Who is using it, for what, in what context? One primary flow first.", "Interviewers reward narrowing the scope out loud."), ("List functional requirements", "What must it do? Pay, track, send, notify. Mark must-haves versus later.", ""), ("Set non-functional requirements", "Scale, spikes, latency, consistency, availability, security, cost, regulation.", "This is where the design is decided."), ("Estimate on the back of an envelope", "Users × actions ÷ seconds = requests per second; peak = average × a spike factor.", "Round numbers; state assumptions."), ("Draw the main boxes", "Clients, gateway, core services, data stores, queues, third parties.", "Five to eight boxes, not thirty."), ("Walk the critical flow", "Follow one request end to end with a sequence diagram.", "Say what the user sees at each step."), ("Break it on purpose", "What if a service is slow, a message is lost, the network drops, traffic triples?", "Name the degraded experience."), ("Trade-offs, metrics, questions", "Which trade-offs you chose and why; how you would measure success and health.", "End with what you'd ask the engineers.")], hl=[2, 6])
```

::: key The one-line rule
Start with the user, decide what must be correct and what can be approximate, draw only the boxes you need, and spend your remaining time on what happens when things go wrong.
:::

%% article | Walkthrough 1 · Payments | How a UPI payment works, and what can go wrong | Scanning a QR code at a kirana store, traced through five systems in a few seconds

You scan the QR code at a kirana store in Indore, type ₹240, enter your PIN, and within a couple of seconds you see a green tick while the shop's soundbox announces "₹240 received". India now does this at a staggering scale: **24.51 billion UPI transactions worth ₹29.82 lakh crore in August 2026** alone (NPCI data via Business Standard, Sep 2026). That averages about **9,150 transactions every second**, around the clock, with festival and month-start peaks well above that.

**Requirements.** Functionally: pay to a UPI ID, phone number or QR; authenticate with a PIN; show a clear final status; reverse failed payments; notify both sides. Non-functionally: **never debit twice and never lose money** (strong consistency), a few seconds end to end, available 24×7, interoperable across hundreds of banks and dozens of apps, and secure enough that a stolen phone alone is not enough to pay.

**The design idea.** UPI is a **hub-and-spoke** network. Apps like PhonePe, Google Pay or Paytm are **PSP apps** (Payment Service Providers) that sit on top of partner banks. None of them hold your money. At the centre sits **NPCI's UPI switch**, which routes every message between the payer's bank and the payee's bank. This central switch is what makes any app work with any bank.

```dia
title: UPI is a hub-and-spoke network
sub: Apps never hold the money; banks do. NPCI routes the messages between them
arch({"a1": ("PSP apps", "PhonePe, GPay, Paytm: the screens you use", "L"), "p": ("PSP banks", "Banks behind each app", "B"), "n": ("NPCI UPI switch", "Central router; resolves UPI IDs; runs the rules", "R"), "b1": ("Payer's bank", "Checks PIN and balance; debits", "N"), "b2": ("Payee's bank", "Credits the merchant", "N"), "m": ("Merchant app + soundbox", "Hears 'received'", "L")}, [("a1", "p", "request"), ("p", "n", ""), ("n", "b1", "debit"), ("n", "b2", "credit"), ("b2", "m", "notify")], rankdir="LR", wrapch=14)
```

```dia
title: One UPI payment, step by step
sub: A scan-and-pay at a store; the whole exchange normally completes in seconds
src: Simplified from NPCI's published UPI flow
seq(["Your app (PSP)", "NPCI switch", "Your bank", "Store's bank", "Store's app"], [("Your app (PSP)", "NPCI switch", "Pay ₹240 to store@bank, txn ID 7F3A…, PIN encrypted on the phone", "The unique txn ID makes retries safe"), ("NPCI switch", "Store's bank", "Resolve the UPI ID to an account", "Wrong or blocked IDs fail here"), ("NPCI switch", "Your bank", "Debit ₹240, verify PIN", "Most failures: wrong PIN, low balance, bank down"), ("Your bank", "NPCI switch", "Debited"), ("NPCI switch", "Store's bank", "Credit ₹240"), ("Store's bank", "NPCI switch", "Credited"), ("NPCI switch", "Your app (PSP)", "Success: green tick"), ("Store's bank", "Store's app", "₹240 received: soundbox speaks")])
```

Notice where the PIN goes. It is encrypted on your phone and checked by **your bank**, not by the app or by NPCI. That is why no UPI app can ever "see" your PIN, and why a customer-care caller asking for it is always a fraudster.

### Breaking it on purpose

Payments are hardest not when everything works, but in the grey zone where something *might* have happened.

- **Timeout after the debit.** Your bank debited you, but the reply got lost on the way back. The app does not know the outcome, so it shows "Pending" rather than guessing. It then asks NPCI using the **Check Transaction Status** API. If the credit to the store failed, the debit is **reversed automatically**. RBI's turnaround-time rules require failed UPI debits to be reversed by the next day (T+1), with compensation of ₹100 per day of delay beyond that (RBI circular, September 2019).
- **Retry without double-charging.** Users tap Pay twice; networks resend messages. Every payment carries a **unique transaction ID**, and every system treats a repeated ID as the same payment. This is **idempotency** in action.
- **Retry storms.** In the UPI outages of March–April 2025, one problem was that banks could query transaction status without limit; when one hop slowed down, banks bombarded the system with status checks, making the slowdown worse. NPCI's April 2025 circular capped these calls: the first check only after 90 seconds (later 45–60 seconds), and a maximum of three checks in the first two hours (Business Standard, April 2025). It also cut API response times from June 2025: the pay request limit fell from 30 to 15 seconds and status checks from 30 to 10 seconds (Business Today, June 2025).
- **A bank is down.** Some banks' core systems slow down at month-start and during festivals. UPI Lite, an on-device balance for small payments without a PIN, was designed partly to take small, frequent payments off banks' core systems.
- **Fraud.** Collect-request scams ("enter your PIN to receive money") exploit the UX, not the technology. Warnings on collect requests, limits for new devices and cooling periods for first-time large transfers are product defences.

```dia
title: UPI's key design choices and what each one buys
cards([("Central switch (NPCI)", "Buys interoperability: any app, any bank. Costs: a system-wide single point that must be engineered for extreme reliability."), ("Strong consistency", "Buys trust: money is never created or lost. Costs: some transactions sit in 'pending' until confirmed."), ("Unique transaction IDs", "Buys safe retries: duplicate messages never double-debit. Costs: every system must store and check IDs."), ("PIN checked by the bank", "Buys security: apps never see credentials. Costs: bank systems are in the critical path for every payment."), ("Strict timeouts and retry caps", "Buys stability under stress. Costs: some payments fail fast instead of waiting."), ("Status-first UX", "Buys calm users: 'Pending, don't pay again' prevents double payment. Costs: design and support effort.")], ncol=3)
```

::: try Questions a PM should ask the engineers
What share of our failures are bank-side versus our side, by bank? What does the user see while status is unknown, and for how long? How do we stop users paying twice when a payment is pending? Are our retries within NPCI's limits? What is our p95 time to a final status? Which support scripts change if timeouts change?
:::

%% article | Walkthrough 2 · Logistics | A food-delivery order with live tracking | From "Place order" to the rider at your gate, and why the moving dot is harder than it looks

It is 8:30 pm in Hyderabad. You order from a restaurant 4 km away. Over the next 35 minutes the app tells you the restaurant accepted, the food is being prepared, a rider named Suresh is assigned, he has picked up the order, and a little bike icon moves along the roads towards you with an ETA that updates. At the same moment tens of thousands of other orders in the city are doing the same thing.

**Requirements.** Functionally: browse and order; pay; send the order to the restaurant; assign a rider at the right moment; show live status, rider location and ETA; allow chat or call with masked numbers; handle cancellations and refunds. Non-functionally: dinner-time peaks several times the afternoon load; order state and payment must be **exactly right**; rider location can be **a few seconds stale**; ETA should be accurate and honest; the rider app must not drain battery or data.

**Back of the envelope (illustrative).** Suppose 2 lakh riders are active at the national dinner peak and each phone sends its GPS position every 4 seconds. That is 2,00,000 ÷ 4 = **50,000 location updates per second**, just from riders, before any customer opens the tracking screen. This one number explains why location is handled by a separate, specialised service and not by the orders database.

```dia
title: The main services behind a food order
sub: Solid arrows: requests; dashed: events and live streams
arch({"ca": ("Customer app", "Browse, pay, track", "L"), "gw": ("API gateway", "Auth, limits, routing", "B"), "os": ("Order service", "State machine; source of truth", "N"), "pay": ("Payments", "Gateways, UPI", "N"), "ev": ("Event stream", "order.placed, rider.assigned…", "M"), "rs": ("Restaurant service", "Tablet, prep time", "B"), "dis": ("Dispatch", "Best rider, timed to food", "R"), "ntf": ("Notifications", "Push, SMS", "Y"), "ra": ("Rider app", "GPS every few seconds", "L"), "loc": ("Location service", "Live positions, in-memory geo store", "G"), "eta": ("ETA model", "Prep + travel + traffic", "T")}, [("ca", "gw"), ("gw", "os", "place order"), ("os", "pay", "charge"), ("os", "ev", "events", "d"), ("ev", "rs", "", "d"), ("ev", "dis", "", "d"), ("ev", "ntf", "", "d"), ("ra", "loc", "GPS"), ("dis", "loc", "nearby riders"), ("loc", "eta", ""), ("loc", "ca", "live, WebSocket", "d")], clusters={"Ordering": ["gw", "os", "pay", "ev"], "Fulfilment": ["rs", "dis", "ntf"], "Tracking": ["ra", "loc", "eta"]}, rankdir="TB", wrapch=16, nodesep=0.15, ranksep=0.3)
```

**The order is a state machine.** The order service is the single source of truth for where each order is, and it only allows legal moves: an order cannot be "delivered" before it is "picked up". Every change is published as an event so other services react without being called directly.

```dia
title: The order state machine
sub: Each arrow is an event other services listen to; the red step is where most cancellations happen
steps([("Placed", "Payment authorised; order saved", "Payment failure ends here"), ("Accepted", "Restaurant confirms, gives prep time", "Restaurant may reject: auto-refund"), ("Preparing", "Dispatch times a rider to arrive as food is ready", "Too early: rider waits; too late: food cools"), ("Picked up", "Rider confirms pickup at the restaurant", "Handover delays at busy kitchens"), ("Delivered", "Rider marks delivered; rating prompt", "Proof: OTP or photo for high-value")], hl=[1])
```

```dia
title: Live tracking, step by step
seq(["Rider app", "Location service", "ETA service", "Customer app"], [("Rider app", "Location service", "Position every ~4 s (more often when moving fast)", "Batched to save battery and data"), ("ETA service", "Location service", "Where is rider 311 now?"), ("ETA service", "Customer app", "ETA 12 min, pushed only when it changes meaningfully", "Avoid jumpy numbers"), ("Location service", "Customer app", "New position over an open WebSocket", "Falls back to polling on weak networks")])
```

### The trade-offs a PM owns here

- **Freshness versus battery and cost.** GPS every second looks smooth but drains the rider's phone and multiplies server load. Every 4–5 seconds, with the app **animating** the icon smoothly between points and **snapping** it to the road map, looks just as good.
- **ETA accuracy versus honesty.** A precise ETA that keeps jumping (25, then 40, then 32 minutes) erodes trust more than a slightly padded, stable one. Good ETA models combine restaurant prep time, rider travel time, traffic and the "last 100 metres" (finding the gate, climbing stairs). Google Maps showed how much better models help: DeepMind's graph neural networks improved Maps' ETA accuracy by up to 50% in cities such as Sydney, Tokyo and Jakarta (DeepMind, September 2020).
- **Batching versus speed.** Giving one rider two nearby orders cuts cost per delivery but adds minutes to one of them. The dispatch algorithm encodes a business choice.
- **Consistency where it matters.** Order and payment states are strongly consistent; the dot on the map is eventually consistent. Never show "Delivered" based on a location guess.
- **Graceful degradation.** If the location service is overloaded, show the last known status with a timestamp ("Rider picked up your order, 8:52 pm") rather than a frozen map.

::: try Questions a PM should ask the engineers
What is our p95 gap between promised and actual delivery time, by city and restaurant type? How often do riders wait more than five minutes at the restaurant? What does the customer see when location updates stop? How much battery does the rider app use per hour? What happens to in-flight orders if the dispatch service restarts?
:::

%% article | Walkthrough 3 · Messaging | How a WhatsApp message gets delivered | One grey tick, two grey ticks, two blue ticks: a lesson in store-and-forward, push, and end-to-end encryption

In October 2020, Mark Zuckerberg said WhatsApp was delivering roughly **100 billion messages a day** (TechCrunch, Oct 2020). That averages over a million messages every second. Each one must arrive once, in order, even if the recipient's phone is switched off in a train tunnel, and WhatsApp's servers must not be able to read any of them.

The ticks you see are the system's state, shown honestly to the user:

```dia
title: What the ticks actually mean
cards([("One grey tick", "The message reached WhatsApp's server. Your phone's job is done; the server now holds it.", "#758D99"), ("Two grey ticks", "The message was delivered to the recipient's phone (every device, in a group: every member).", "#758D99"), ("Two blue ticks", "The recipient opened the chat. Read receipts can be turned off, in which case ticks stay grey.", "#006BA2")], ncol=3)
```

**Requirements.** Deliver every message exactly once and in order; work when the recipient is offline; feel instant when both are online; support groups, media and multiple devices; **end-to-end encryption** so only sender and recipient can read content; work on cheap phones and weak networks.

```dia
title: Sending a message to a friend who is offline, then online
seq(["Asha's phone", "Chat server", "Push service (APNs / FCM)", "Ravi's phone"], [("Asha's phone", "Chat server", "Encrypted message + message ID over a persistent connection", "Server cannot read the content"), ("Chat server", "Asha's phone", "Stored: one grey tick"), ("Chat server", "Push service (APNs / FCM)", "Ravi is offline: send a wake-up push", "Push carries no readable message"), ("Ravi's phone", "Chat server", "Phone reconnects, asks for pending messages"), ("Chat server", "Ravi's phone", "Deliver queued message"), ("Ravi's phone", "Chat server", "Delivery receipt", "Server then deletes its copy"), ("Chat server", "Asha's phone", "Two grey ticks"), ("Ravi's phone", "Asha's phone", "Read receipt via server: blue ticks")])
```

**The key ideas.**

- **Persistent connections.** While the app is open, the phone keeps one long-lived connection to a chat server (like a phone line left open), so messages arrive instantly in both directions without polling.
- **Store and forward.** If the recipient is offline, the server holds the encrypted message in a queue and delivers it when they reconnect, then deletes it. WhatsApp says undelivered messages are deleted from its servers after 30 days.
- **Push to wake up.** When the app is in the background, the server asks Apple's or Google's push service to wake it; the app then fetches the message itself.
- **Message IDs and acknowledgements.** Each message has an ID; each hop acknowledges it. Resends with the same ID are ignored, so network retries never create duplicates.
- **End-to-end encryption.** Since 2016, WhatsApp uses the Signal protocol: messages are locked on the sender's phone with keys that only the recipients' devices hold. The server moves sealed envelopes it cannot open. This is a product promise with consequences: the company cannot read chats to moderate them or restore them without the user's own backup.
- **Groups fan out.** A message to a 200-member group is sent once to the server and then delivered to 200 devices. Group size limits exist partly to keep this fan-out, and misinformation spread, under control.
- **Media travels separately.** A photo is encrypted and uploaded once to storage; the message carries only a link and the key to open it.

### A related design: the notification system

Almost every company eventually builds a central **notification service**, because dozens of teams want to message users and nobody wants each team spamming separately.

```dia
title: A central notification service
sub: One front door for every team's messages, with rules that protect the user
arch({"t": ("Many teams", "Orders, marketing, security, payments", "L"), "api": ("API + rules engine", "Template, preferences, quiet hours, frequency caps, dedupe", "R"), "q1": ("High-priority queue", "OTPs, payment alerts, order updates", "N"), "q2": ("Low-priority queue", "Offers, reminders, digests", "Y"), "ch": ("Channel senders", "Push, SMS, WhatsApp, email; provider failover", "T"), "tr": ("Tracking", "Delivered, opened, opted out", "G")}, [("t", "api"), ("api", "q1", "urgent"), ("api", "q2", "can wait"), ("q1", "ch"), ("q2", "ch"), ("ch", "tr", "", "d")], rankdir="LR", wrapch=16)
```

The design choices are mostly product choices: **separate queues** so a marketing blast of 5 crore messages never delays an OTP; **frequency caps** ("no more than three promotional pushes a day"); **quiet hours**; **deduplication** so users do not get the same alert on three channels; **channel fallback** (push first, SMS if the push is not delivered within a minute for critical messages); and **provider failover** when an SMS vendor is down. The metric that matters is not "messages sent" but **useful messages opened** and **opt-out rate**.

::: try Questions a PM should ask the engineers
What is our delivery latency for OTPs at p95, and does it change during a marketing campaign? What happens to messages for users who are offline for a week? How do we prevent duplicate notifications across channels? What is the opt-out rate by notification type? If we wanted end-to-end encryption, which features (search, moderation, backup) would change?
:::

## In the interview

Interviewers use these three systems because every Indian candidate uses them daily. A strong answer to "How does UPI work?" covers the actors (PSP app, PSP bank, NPCI, issuing and beneficiary banks), the flow, where the PIN is checked, what "pending" means, and one failure mode with its fix. A strong answer to "Design live tracking" starts with the user's anxiety ("where is my food and when will it come?"), estimates location traffic, separates the exact order state from the approximate location, and ends with ETA honesty. A strong answer to "Why does WhatsApp show two ticks?" explains store-and-forward and receipts, then adds a product insight: *"The ticks are a trust feature. They turn an invisible system state into something the user can see, which cuts 'did you get my message?' anxiety."*

Traps: listing technologies without explaining why; ignoring failure; promising strong consistency and instant speed everywhere; forgetting the other side of the marketplace (restaurant, rider, merchant).

::: quiz Check yourself
1. Name the eight steps of the PM system-design method. Which steps show the most PM judgement?
2. Draw the UPI flow from memory with five actors. Where is the PIN verified, and why does that matter?
3. A payment is stuck at "Pending". What is happening in the system, and what should the app tell the user?
4. How did unlimited status checks make the 2025 UPI outages worse, and what did NPCI change?
5. Estimate location updates per second for 1 lakh active riders sending GPS every 5 seconds.
6. Which data in a food order must be strongly consistent, and which can be eventually consistent?
7. Explain the three WhatsApp tick states and the store-and-forward idea.
8. *(From the system-design chapter)* Why must an OTP never wait behind a marketing message, and which building block solves this?
:::
