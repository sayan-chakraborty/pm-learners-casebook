%% chapter | Technology · Building without code | Low-code, no-code and vibe coding | How PMs can now build working tools and prototypes themselves, which tool fits which job, and where the shortcuts become traps

You could build a house by learning to make bricks, mix mortar and frame walls from scratch. Or you could use a box of high-quality, pre-made LEGO blocks and have a good-looking house by evening. The first gives you total freedom and takes years; the second is fast but you are limited to the shapes in the box.

That is the idea behind **low-code and no-code (LCNC) platforms**: they provide ready-made building blocks for software (forms, databases, workflows, dashboards) that you assemble visually instead of writing every line of code. Since 2024, a third option has joined them: describing what you want in plain English and letting an AI write the code. For a PM, all three are levers for speed.

```dia
title: Three ways to build without (much) code
sub: The LEGO analogy, extended
analogy([("A LEGO kit with instructions", "No-code", "Assemble apps from ready blocks, no code at all. Airtable, Bubble, Shopify, Zapier, n8n."), ("A LEGO kit plus custom 3D-printed pieces", "Low-code", "Mostly visual, with bits of code for special needs. Retool, OutSystems, Microsoft Power Apps."), ("A master builder robot that builds what you describe", "AI-assisted coding and 'vibe coding'", "Describe it in English; AI writes real code. GitHub Copilot, Cursor, Claude Code, Replit, Lovable, Bolt, v0.")])
```

| Category | Example use case | Tools |
|---|---|---|
| **No-code** | Track user feedback: an Airtable form and database, with an n8n or Zapier automation that posts each new entry to the team's Slack channel | Airtable, Bubble, Shopify, Zapier, n8n |
| **Low-code** | Sales wants a dashboard showing which customers use a new feature, pulling live data from the internal database, which a spreadsheet cannot do; built in Retool in a day | Retool, OutSystems, Power Apps, Appsmith |
| **AI-assisted pro-code** | Engineers building a complex feature use an AI pair programmer or coding agent to write routine code, tests and migrations | GitHub Copilot, Cursor, Claude Code, Codex |

## English is the new programming language

In February 2025, AI researcher Andrej Karpathy coined the phrase **"vibe coding"** for building software by conversation: you describe what you want, the AI writes the code, you run it, and you steer with more English rather than reading every line.

```dia
title: Vibe coding in practice
steps([("Describe", "'I need a script that collects app-store reviews mentioning our competitor.'", "Be specific about inputs and outputs"), ("AI generates", "The assistant writes and runs the code", ""), ("Test and refine", "'Good. Now tag each review's sentiment and save the negative ones to a Google Sheet.'", "Check the output, not just that it runs"), ("Iterate", "Add a chart, a daily schedule, a Slack alert", "Small steps, one change at a time"), ("Decide its fate", "Keep as a personal tool, share as a prototype, or hand to engineering", "Prototype ≠ production")], hl=[4])
```

The newest frontier is **agent and workflow builders**: platforms where you configure an AI agent that reads a knowledge base, calls APIs (to check order status, say) and escalates to a human, through a visual interface. App builders such as Lovable, Bolt and Replit can produce a working web app with login and a database from a few paragraphs of description.

## The PM's toolkit: which tool for which job

```dia
title: Picking the right tool
cards([("Internal tracker or form", "Airtable, Google Sheets + Apps Script, Notion databases"), ("Automations between apps", "Zapier, Make, n8n: 'when X happens in one app, do Y in another'"), ("Internal dashboards on live data", "Retool, Looker Studio, Metabase, Power BI"), ("Clickable product prototype", "Figma for design; Lovable, Bolt, v0 for a working prototype"), ("Data analysis and quick scripts", "An AI assistant writing SQL or Python you can run and check"), ("Customer-facing product at scale", "Engineering team with AI-assisted pro-code; not a no-code tool")], ncol=3)
```

## Speed versus control

```dia
title: Advantages and risks of LCNC and AI-built software
versus("Advantages", [("Faster time to market", "MVPs, internal tools and AI features in days instead of months."), ("Lower cost", "Less engineering time for standard apps and automations."), ("Agility", "PMs can build and change prototypes and internal tools directly."), ("Democratised innovation", "Business users solve their own problems, freeing engineers for core work.")], "Risks and limits", [("Vendor lock-in", "Moving off a proprietary platform can mean a complete rebuild."), ("Scale and performance ceilings", "Pure no-code tools can struggle at enterprise load."), ("Black-box debugging", "AI-generated code nobody understands is hard to fix when it breaks."), ("Security and governance", "'Shadow IT' built by citizen developers can leak data or skip access controls.")], lc="#379A8B", rc="#E3120B", verdict="Use these tools freely for learning, prototypes and internal tools; bring engineering in before anything touches customer data or money at scale.")
```

As Andrew Ng has put it: *"Engineers are 10x faster. Product managers haven't sped up at the same rate. Now they're the bottleneck."* When building gets cheap, the scarce skill becomes deciding **what** to build and **whether it worked**. The PMs who benefit most use these tools to shorten their own loops: synthesising research in an afternoon, testing three prototype variants with users in a week, and arriving at engineering reviews with something people can click rather than a document people must imagine.

::: key The one-line rule
Build prototypes and internal tools yourself; let engineering own anything customer-facing, security-sensitive or meant to scale. A prototype that proves a point in three days is worth more than a spec that takes three weeks.
:::

**In the interview.** "How do you use AI in your PM work?" (concrete examples: research synthesis, SQL for a quick analysis, a clickable prototype tested with five users, with the checks you do on the output), "Should we build this internal tool on a no-code platform?" (who uses it, how many, what data it touches, how long it must live, lock-in and security). Trap: claiming you would ship a vibe-coded app straight to customers.

%% article | Technology · Trust | Building trust: security, resilience and governance | The three lenses that decide whether users will hand a product their time, data, money and beliefs

A decade ago, many users accepted trade-offs: convenience at the cost of privacy, speed at the cost of reliability. That balance has shifted. Users are more aware, regulators more watchful, and competition unforgiving. A single breach, a payment outage on salary day, or an AI that treats some users unfairly can undo years of brand building. **Security, resilience and governance** are no longer back-end concerns; they are front-line tests of whether a product deserves to exist.

```dia
title: Three lenses of trust
sub: Each answers a question the user never asks out loud
cards([("Security: keeping promises", "Can I trust you with my data, identity and money? Breaches are broken promises, not just technical failures. PM question: what are we promising, and can we keep it under stress?"), ("Resilience: keeping them consistently", "Will it work when I need it, on the IPL final or salary day? Users rarely notice resilience, but instantly feel its absence. PM question: can the product absorb shocks and still deliver its core value?"), ("Governance: doing the right thing", "Should this be built at all? Who could be harmed? Fairness, transparency, accountability. PM question: will this decision still look right when explained in public?")], ncol=3)
```

**Security** is not only encryption and compliance; it is designing experiences that make users *feel* safe without friction. UPI's rule that the PIN is only ever entered to *pay*, never to *receive*, is a security principle turned into a simple habit users can learn. Risk-based step-up checks (extra verification only for a new device or an unusual transfer) protect without taxing every user.

**Resilience** is the silent foundation. Latency spikes, outages and fraud attacks do not just frustrate; they erode credibility. PMs should prioritise fault tolerance, graceful degradation and recovery with the same seriousness as new features, and practise the incident playbook before it is needed (the system-design chapter covers the mechanics).

**Governance** grows in importance as products grow powerful, especially with AI. It is not about saying no to innovation; it is about innovation that sustains trust. In India it now has regulatory teeth: the Central Consumer Protection Authority's 2023 guidelines prohibit a list of **dark patterns** such as false urgency, basket sneaking, drip pricing and "confirm-shaming", and the DPDP Act requires clear consent and purpose limits for personal data.

::: key The PM's takeaway
Treat security, resilience and governance as lenses, not checkboxes. For every decision, ask not just "will it work?" but "will it be safe, will it endure, and will it do right by the user?"
:::

**In the interview.** Trust themes appear inside other questions: "Design a digital locker for documents" (security and consent first), "Launch an AI loan-approval feature" (fairness audits, explanations, human review, appeal path), "Your app was down for two hours on Diwali; what now?" (communicate honestly, compensate where fair, postmortem, resilience investment). Naming these lenses unprompted signals maturity.

%% article | Technology · Marketing measurement | The customer funnel and brand lift | How to prove that a campaign changed what people know, think and intend, using the same logic as an A/B test

You launch a new "Split bill" feature in a payments app and spend ₹5 crore on a YouTube and Instagram campaign. Usage rises 12%. Was that the campaign, or the festive season, or a competitor's outage? Did people actually become *aware* of the feature, and do they now *think* of your app as the one for splitting bills?

A **brand lift study** measures how much a campaign changed people's **awareness** and **perception** of a product or feature. Awareness mainly helps the top of the customer funnel (getting considered); perception helps the bottom (getting chosen).

```dia
title: What a campaign can move, stage by stage
funnel([("Awareness", "Heard of it", 1.0, "'Have you heard of Split bill?' Brand lift measures ad recall and awareness here"), ("Perception", "Likes it", 0.7, "'Is it easy, safe, better than alternatives?' Favourability and association with the job"), ("Intent", "Plans to try", 0.45, "'Will you try it next month?' Consideration and purchase intent"), ("Usage", "Used it", 0.3, "Did they actually split a bill? Measured with product data, not surveys"), ("Loyalty", "Keeps using", 0.24, "Retention and referrals")])
```

## How a brand lift study works

It is a randomised experiment, like an A/B test, run on audiences rather than app users.

```dia
title: Running a brand lift study
steps([("Choose what to measure", "Awareness, favourability, intent for the feature; write neutral survey questions", "Decide the primary metric first"), ("Split the audience", "At random: an exposed group sees the campaign; a control group is held out", "Randomisation is the whole point"), ("Run the campaign", "Promote the feature as planned to the exposed group", ""), ("Survey both groups", "Ask the same questions to both (ideally before and after)", "Same timing, same questions"), ("Calculate the lift", "Difference between exposed and control = the campaign's effect", "Check the difference is significant")], hl=[1])
```

A worked example. After the campaign, 40% of the exposed group know about Split bill, versus 20% of the control group. The **absolute lift** in awareness is 20 percentage points; the **relative lift** is 100% (awareness doubled). Always say which one you mean; they are easy to confuse in presentations. If you also surveyed before the campaign, compare the *change* in each group (a before-and-after in both groups), which removes pre-existing differences between them.

| What it answers | Example question |
|---|---|
| Awareness | Are more people aware of the new feature after the campaign? |
| Perception | Do people have a better opinion of it: easy, safe, useful? |
| Intent | Are more people planning to try or buy it? |
| Engagement | Are people using it more, and saying positive things? |

The benefits: understanding what the campaign actually did, making data-driven decisions about future campaigns, allocating budget to what works, and proving return on investment to stakeholders. Google (for YouTube), Meta and other ad platforms offer built-in brand lift studies that hold out a control group automatically.

```dia
title: Real-world brand-lift questions
cards([("YouTube Shorts", "Rolling out Shorts globally: do people know Shorts exists as an alternative to TikTok-style video, and do they see it as fun enough to use? Track awareness and perception."), ("WhatsApp privacy features", "After campaigns for disappearing messages and encryption: do users feel WhatsApp is safer and trust it with private conversations? Track perception (safety, trust) and intent."), ("Airbnb 'I'm Flexible'", "Did ads and in-app nudges make travellers aware of flexible search, and do they now see Airbnb as a place to discover trips, not just book them? Track awareness and engagement.")], ncol=3)
```

**Contrasting case and limits.** Surveys measure what people say, not what they do; a lift in awareness does not guarantee a lift in usage. Pair brand lift with **conversion lift** (the same exposed-versus-control design, measured on actual sign-ups or purchases) or **geo experiments** (run the campaign in some cities and not in matched others). Sample sizes must be large enough, questions neutral, and the control group truly unexposed.

::: key The one-line rule
Measure campaigns like experiments: a randomly held-out control group, the same questions to both groups, and the lift is the difference. Awareness and perception come first in the funnel, but usage is the result that matters.
:::

**In the interview.** "How would you measure whether our launch campaign worked?" (define the funnel stage the campaign targets; brand lift for awareness and perception with a holdout; conversion lift or geo test for usage; watch for seasonality), "Awareness went up but usage didn't; why?" (message not linked to a job; friction in the product; wrong audience; timing). A strong line: *"I'd separate awareness from adoption: brand lift tells me whether people heard us, and a holdout on product usage tells me whether hearing us changed what they did."*

::: quiz Check yourself
1. Distinguish no-code, low-code and AI-assisted pro-code with one use case each.
2. What is vibe coding, and what is its biggest risk in production?
3. Name two advantages and two risks of LCNC platforms. What is 'shadow IT'?
4. What question does each of the three trust lenses answer? Give an Indian product example for each.
5. Name three dark patterns and explain why they are a governance issue, not just a UX one.
6. Design a brand lift study for a new feature: groups, questions, and how you compute lift.
7. Exposed awareness is 30% and control is 24%. What are the absolute and relative lifts?
8. *(From the A/B testing chapter)* Why is a randomly held-out control group essential both in A/B tests and in brand lift studies?
:::
