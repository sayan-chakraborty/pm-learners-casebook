%% chapter | Product dossier · Payments | Free money movement, paid everything else | UPI made payments free and instant. That forced every payments company in India to find its profits somewhere else. Here is where each one is looking.

It is 7:40 a.m. outside a tea stall in Koramangala. A student scans a QR code, types a four-digit PIN, and before she has picked up her cup a small speaker on the counter says, in Kannada, "Twenty rupees received on PhonePe." The owner does not look at his phone. He trusts the box.

That scene happens about **79 crore times a day**. In August 2026 India made **24.51 billion UPI payments worth ₹29.82 lakh crore**. The average payment was just ₹1,217 (NPCI data, via MediaNama, Sep 2026). Payments now come in small amounts, many times a day, by habit, and they cost the user nothing.

```dia
title: The teardown checklist used in every dossier
sub: Every dossier in Part II follows these ten questions (adapted from HelloPM, LogRocket and Lenny Rachitsky's product-sense guide). Use them to take apart any product in an interview.
cards([("1. User and job", "Who hires this product, and for which job? What did they use before?"), ("2. Positioning", "The one-line promise, and who it is NOT for."), ("3. Core loop", "The action users repeat, and what brings them back."), ("4. First run", "What happens in the first five minutes. Where do new users drop?"), ("5. Key features", "For each feature: the problem, the design choice, the metric it moves."), ("6. Business model", "Who pays, for what, and what is left per order or user."), ("7. Growth loops", "How one user or order brings the next one in."), ("8. Moat", "Why a copycat with money still loses: Helmer's 7 Powers."), ("9. Metrics", "North Star, three or four input metrics, and guardrails."), ("10. Build next", "Two or three bets: the user problem, the idea, the metric.")], ncol=5)
```

## The job, and the market

Users hire a payments app for one job: **move money right now, without worrying that it will fail or get stolen**. Merchants hire a payments company for a different job: **get paid by every customer, see the money in the bank, and know which payment was which**. The best products in this dossier serve one side very well and then use that position to sell something else.

Since 2020, UPI payments to merchants have carried **zero MDR**. MDR, the merchant discount rate, is the fee a shop pays on each digital payment. With UPI it is zero, so the app that processes your ₹20 chai payment earns nothing from it. That single rule shapes every strategy below. Payments became the free way in, and the profit has to come from loans, insurance, investing, merchant devices, card payments, or software.

```dia
title: Who processes India's UPI payments
sub: Share of UPI transaction volume by app, August 2026 (%)
src: NPCI data via Inc42 (Sep 2026); WhatsApp figure is May 2026 (NPCI via Trak.in)
bars([("PhonePe", 45.9, "Default app for small merchants"), ("Google Pay", 32.4, "Urban and Android-heavy"), ("Paytm", 8.1, "Recovering after 2024 bank curbs"), ("Navi", 4.4, "Fastest riser, cashback-led"), ("super.money", 1.7, "Flipkart's UPI app"), ("BHIM", 1.04, "NPCI's own app"), ("WhatsApp", 0.65, "500M+ users, tiny share")], unit="%", hl=[6], fmt="{:.1f}")
```

Two apps handle almost four in every five payments. NPCI has proposed a **30% cap on any one app's share**, but it has pushed the deadline back twice. The deadline now stands at 31 December 2026. If the cap is enforced, PhonePe and Google Pay would have to turn users away, which no product team would plan for. That is why every interviewer loves asking about it.

```dia
title: What happens in the two seconds after you tap Pay
sub: A UPI payment from a PhonePe user to a shop that banks with HDFC
src: NPCI UPI architecture; simplified
seq(["You (app)", "Your PSP app", "NPCI switch", "Your bank", "Shop's bank"], [("You (app)", "Your PSP app", "Scan QR, enter PIN", "PIN is encrypted on your phone"), ("Your PSP app", "NPCI switch", "Payment request", ""), ("NPCI switch", "Your bank", "Debit ₹20", "Most failures happen here: bank server down"), ("NPCI switch", "Shop's bank", "Credit ₹20", ""), ("NPCI switch", "Your PSP app", "Success", "Speaker at shop announces it")])
```

The payment app does not hold your money. It is only the front door, a **PSP (payment service provider) app**, while banks move the money and NPCI connects them. So apps compete on what you can see: speed to "Paid", failure rate, safety, and what else they sell you afterwards.

%% article | Payments · Razorpay | The payment company built for developers | Razorpay won online checkout by being easy to plug in. Its next problem: UPI pays it nothing, so it has to sell businesses everything else.

**Who it is for.** Any business that takes money online, from a two-person D2C brand on Shopify to Zomato and Swiggy. The first user is not the founder but the **developer**. Razorpay's early growth came from clean documentation, a test mode that works in minutes, and plug-ins for every common platform. Positioning: *"one integration for every way Indians pay, and then banking, payroll and credit for the same business."* It is not built for the kirana store that only needs a QR code.

**Core loop.** A merchant integrates → customers pay → Razorpay learns which bank, card and UPI route succeeds at what time → success rates rise → the merchant earns more and tells other founders → more merchants join. More payments lead to better routing data, which leads to a higher success rate. That data advantage grows with scale.

**First run.** Sign up with an email, get test API keys straight away, and make a dummy payment within minutes. KYC (identity checks on the business) happens afterwards, before real money flows. Letting developers build first and complete paperwork later is a deliberate choice. The drop-off point is **activation**: merchants who start KYC but never go live. That is the funnel Razorpay's onboarding teams watch.

| Feature | User problem it solves | Why it is designed this way | Metric it moves |
|---|---|---|---|
| Payment Gateway | "I need cards, UPI, netbanking, wallets, EMI" | One API and one dashboard hide 100+ bank integrations | Merchant activation, GMV |
| Optimizer (smart routing) | "A failed payment is a lost sale" | Routes each payment to the gateway or bank most likely to succeed right now | Payment success rate |
| Magic Checkout | "Shoppers abandon when typing addresses" | Pre-fills address and payment details across Razorpay's shopper network; scores COD risk | Checkout conversion, RTO (return-to-origin) rate |
| Payment Links and Pages | "I sell on Instagram and have no website" | A link that works in any chat | New small merchants |
| Subscriptions / UPI Autopay | "Collecting monthly fees is manual" | Mandates set up once, charged automatically | Recurring GMV, churn |
| RazorpayX, Payroll, POS | "My money, salaries and store sales are in five tools" | Sells into the same dashboard the merchant already opens daily | Products per merchant |
| Agentic Payments (2026) | "An AI assistant can find food but cannot pay for it" | Built on UPI Reserve Pay: user pre-approves a limit once; agent pays within it | New commerce surface |

**Business model and unit economics.** Razorpay's FY25 revenue was **₹3,783 Cr (+65%)**, with a net loss of ₹1,209 Cr driven by one-time ESOP and "reverse flip" costs from moving its holding company back to India (company filings via the press). It handles about **$180 billion of annualised payments** for over 12 million businesses and has roughly **55% of India's online gateway market** (industry estimates, 2026). On a card payment Razorpay keeps only a thin slice of the fee. On a UPI payment it keeps nothing at all.

```dia
title: What a gateway keeps from a ₹1,000 credit-card payment
sub: ₹ per payment, illustrative; actual rates vary by card type and merchant size
src: Illustrative, based on standard ~2% MDR plans and typical interchange ranges
waterfall([("MDR charged to merchant", 20, "Standard ~2% plan"), ("Interchange to card issuer", -15, "The bank that gave the card"), ("Network fee", -1.5, "Visa, Mastercard, RuPay"), ("Acquiring bank", -1, "Holds merchant account"), ("Tech, risk, support", -1, "Fraud checks, servers")], total="Gateway keeps", fmt="{:,.1f}", takeaway="On a ₹1,000 UPI payment the same waterfall starts at zero. That is why RazorpayX, payroll and lending matter.")
```

**Growth loops.** Developer word of mouth (engineers carry Razorpay to their next start-up); a shopper network (each Magic Checkout purchase makes the next Razorpay merchant's checkout faster); and cross-sell (a merchant settling money with Razorpay is easy to sell a current account or loan).

**Moat, in plain words.** Switching costs are the biggest one. Changing a payment gateway means rewriting code, re-testing refunds, and rebuilding reconciliation, the daily matching of payments to orders. Scale economies come next: more volume gives better routing data, which gives higher success rates. Finally, process power: years of work on bank downtime, fraud rules and settlements that a newcomer cannot copy quickly. The weakness is that for plain UPI, a gateway is close to a commodity.

**Metrics.** *North Star:* successful payment volume processed (₹ TPV that actually succeeded). *Inputs:* active merchants, payment success rate, checkout conversion on Magic Checkout, products per merchant. *Guardrails:* fraud and chargeback rate, downtime minutes, settlement delay.

**2025–26 moves.** Razorpay received the RBI licence for cross-border payments (PA-CB) in January 2026. In February 2026, at the India AI Impact Summit, it launched **Agentic Payments with NPCI on Anthropic's Claude**, with Zomato, Swiggy and Zepto as early merchants. It filed confidentially for an IPO in June 2026. It also pushes offline with POS and into lending, because online UPI earns it nothing.

**Strengths:** developer trust, high success rates, product range. **Weaknesses:** thin core margins, RBI dependence, and strong rivals (Cashfree, PayU, Juspay) in every line.

::: key What I would build next at Razorpay
1. **Agent-ready checkout.** *Problem:* AI agents cannot read most checkout pages. *Bet:* a "merchant agent kit" that publishes catalogue, prices and payment limits in a form assistants can use, with Reserve Pay mandates built in. *Metric:* GMV through agent-initiated payments; mandate approval rate.
2. **Cash-flow forecast for small merchants.** *Problem:* D2C founders do not know if they can pay next month's salaries. *Bet:* use settlement data to predict cash 30 days ahead and offer a credit line before the gap appears. *Metric:* loan book per active merchant, 90-day repayment rate.
3. **RTO shield as a service.** *Problem:* cash-on-delivery returns eat 20–30% of some brands' orders (illustrative). *Bet:* sell the COD risk score from Magic Checkout to merchants who do not use Razorpay checkout. *Metric:* RTO rate for paying merchants; attach revenue from merchants who do not use Razorpay for payments, and the share of COD orders that the score flags correctly.
:::

%% article | Payments · PhonePe | The default app of Bharat | PhonePe won UPI by making the scan-and-pay moment fast everywhere. Now it has to earn money from users it trained to expect free payments.

**Who it is for.** Everyone, and especially the small-town and small-merchant India that Google Pay reached later. PhonePe has over **60 crore registered users** (company, 2025). Positioning: *"the app that works at every shop."* The product feels like a utility: large buttons, a clear Scan button, and vernacular support.

**Core loop.** Scan a QR → pay in seconds → the shop's speaker confirms it → the user trusts the habit → the user pays again tomorrow. On the merchant side: more PhonePe users at the counter → shopkeepers display PhonePe QR codes and speakers → customers see PhonePe everywhere → they install PhonePe. UPI is **interoperable**: any app can pay any QR code. So PhonePe's network effect comes from habit and brand visibility, not from a technical lock-in. That makes it weaker than it looks.

**First run.** You enter your mobile number, the app verifies the SIM with an SMS, finds your bank accounts linked to that number, and asks you to set a UPI PIN using your debit card. The riskiest step is the PIN set-up. Users without a debit card at hand drop off, which is why Aadhaar-OTP PIN set-up matters for first-time users.

```dia
title: PhonePe home screen, annotated
sub: Everything is arranged around getting to Pay in one tap
phone([("Profile · QR · Alerts", 0.6), ("Banner: offers / loan ad", 1.0), ("Transfer money: to mobile, to bank, self, balance", 1.3), ("Recharge and pay bills", 1.1), ("Loans · Insurance · Wealth", 1.0), ("Nav: Home · Search · SCAN · Alerts · History", 0.7, "#F6D9D7")], [(2, "Money transfer comes first", "P2P brings new users in; each payment to a non-user is an invite."), (1, "Banner is ad space", "Brands and PhonePe's own products compete for this slot."), (4, "Money products below", "Loans and insurance sit where regular users scroll past them daily. This is where the profit comes from."), (3, "Bills and recharges", "Monthly habits that keep users coming back between shop payments."), (5, "Scan sits in the middle", "The most common action gets the biggest, central button. Metric: taps to payment.")])
```

| Feature | User problem | Design choice | Metric |
|---|---|---|---|
| Scan & Pay | "I need to pay in the queue, fast" | Opens straight to the camera; remembers recent merchants | Time to pay, success rate |
| SmartSpeaker (sound box) | Shopkeeper: "Did the money actually arrive?" | Speaks every payment aloud in local languages; stops fake-screenshot fraud | Merchant retention, device rental revenue |
| UPI Lite | "Small payments fail when the bank is slow" | Small on-device balance, no PIN for low amounts | Failure rate on sub-₹500 payments |
| RuPay credit card on UPI | "I want credit-card rewards at a QR shop" | Links a credit card to UPI | Revenue: MDR applies on larger merchants |
| Lending, insurance, Share.Market | "I need a loan or cover, quickly" | Distributes partner products to a user base that already trusts the app | Revenue per MTU |

**Business model.** FY26 revenue was **₹7,920 Cr (+11%)** and the loss widened to **₹2,792 Cr** (company filings, 2026). Growth has slowed sharply: 74% → 40% → 11% across three years. The profitable engines are small but growing fast: lending distribution earned ₹945 Cr (more than double), insurance ₹191 Cr, and broking ₹108 Cr. PhonePe deferred a planned $1.3 billion IPO in March 2026. Its Pincode shopping app was pivoted to serve businesses (B2B) after failing in consumer commerce. It also runs **Indus Appstore**, an Android app store, as a longer-term bet.

**Moat.** Brand and habit (branding power), plus the physical network of speakers and QR stickers at millions of shops (a cornered resource that takes years to build). Switching costs for users are close to zero. That explains why a 30% share cap would be so damaging: nothing technical stops users from moving.

**Metrics.** *North Star:* monthly transacting users (MTU). *Inputs:* payments per MTU, payment success rate, active merchant devices, cross-sell rate into lending or insurance. *Guardrails:* fraud losses, complaint resolution time, and share of UPI volume, which must stay under any cap.

**Strengths:** reach, reliability, merchant presence. **Weaknesses:** revenue grows much slower than usage, losses are rising, the 30% cap threat, and it depends on partner banks and NBFCs for every money product.

::: key What I would build next at PhonePe
1. **Scam shield for first-time users.** *Problem:* older and first-time users are the main targets of "collect request" and fake-refund scams. *Bet:* on-device warnings in the local language when a payment matches scam patterns, plus a "check with family" hold through UPI Circle. *Metric:* fraud reports per lakh transactions; payment completion rate, a guardrail so warnings do not block genuine payments.
2. **Speaker-data credit for shopkeepers.** *Problem:* kirana owners cannot get working capital. *Bet:* use daily speaker-confirmed inflows to offer daily-repayment loans. *Metric:* disbursals per active device; repayment rate.
3. **Share-cap-proof loyalty.** *Problem:* if the cap bites, PhonePe must keep its best users while turning others away. *Bet:* a membership tier with insurance, credit and bill-pay benefits for heavy users. *Metric:* revenue per MTU, retention of the top 10% of users.
:::

%% article | Payments · Google Pay | Google-grade trust, Google-scale indifference to revenue | Google Pay proved that a clean design and scratch cards could win urban India. It then had to decide what India payments were for.

**Who it is for.** Urban, smartphone-first users, mostly on Android, who value a clean interface and trust the Google brand with money. Positioning: *"simple, secure payments from the company you already trust."*

**Core loop.** Pay a friend → the conversation-style history shows every payment with that person → you pay them again from the same thread. In 2018–20 the loop was powered by **scratch cards**: each payment could win cashback, which turned payments into a small game. Those rewards have mostly gone. The habit has stayed, which tells you they did their job of forming the habit.

**Key features.**

- **Chat-style payment threads.** Payments with each person look like a messaging thread. This makes splitting costs and paying back feel social. Metric: repeat P2P payments.
- **UPI Circle (2024).** A primary user lets a trusted secondary user, such as a parent or college student, pay from their account, either with each payment approved or up to a monthly limit. It brings in users who have no bank app. Metric: new users activated via Circle.
- **Bill payments and ClickPay QR.** Scan a QR printed on a utility bill to pay it without typing account numbers. Since 2025 Google Pay has charged a small convenience fee on credit-card bill payments, one of its few direct fees.
- **Tap to pay and UPI Lite**, and in 2026 **biometric authentication** (fingerprint or face instead of a PIN) for UPI payments, which NPCI now allows.
- **Loans and gold from partners**, shown to users with good payment histories.

**Business model.** Google does not report Google Pay India's revenue. Its value is mainly strategic: it keeps Android the best way to use UPI and builds a trusted money relationship that Google can extend to loans and merchant services. Direct revenue comes from loan and card distribution, convenience fees and merchant services.

**Moat.** Brand trust and Android distribution, since the app comes preinstalled or one tap away. It is weaker at small merchants, where PhonePe's and Paytm's speakers dominate.

**Metrics.** *North Star:* monthly transacting users. *Inputs:* P2P payments per user, merchant payments per user, UPI Circle activations, loan applications from eligible users. *Guardrails:* fraud rate, failure rate, share cap.

::: key What I would build next at Google Pay
1. **Gemini "explain this payment request."** *Problem:* users approve collect requests they do not understand. *Bet:* one tap shows in plain language who is asking, why, and whether it looks like a known scam pattern. *Metric:* scam losses per lakh users.
2. **Shared household ledger.** *Problem:* families track rent, maids, milk and school fees in their heads. *Bet:* a shared view built on UPI Circle that tags recurring household payments. *Metric:* households with 2+ active members; recurring payments made.
:::

%% article | Payments · Paytm | From super-app to merchant machine | Paytm lost its bank, most of its consumer share and its valuation in 2024. It came back by doubling down on the shopkeeper.

**Who it is for today.** Small and mid-sized merchants first, then consumers. Paytm serves **1.57 crore storefronts with Soundbox devices** and has **8 crore monthly transacting users** (Paytm Q1 FY27 earnings release, Jul 2026). Positioning: *"everything a shopkeeper needs to get paid, get credit, and grow."*

**What happened.** In January 2024 the RBI stopped Paytm Payments Bank from taking new deposits over compliance failures, and consumer UPI users left for PhonePe and Google Pay. The licence was cancelled in April 2026. Paytm now runs UPI as a **TPAP** (third-party app provider) on Axis, HDFC, SBI and Yes Bank rails, like its rivals.

**Core loop.** A merchant rents a Soundbox → every payment is announced → the merchant keeps Paytm QR at the counter → Paytm sees daily cash flows → it can offer the merchant a loan through a partner lender → the merchant stays loyal. The device is the anchor, and it turns free payments into data and a monthly fee.

Around the Soundbox, Paytm sells card machines for customers who still pay by card, **merchant loans** from partner lenders (offered from payment history), Paytm Postpaid and wealth products for regular users, and an AI-led travel booking flow that it says converts 7–8 times better than its old app screens.

**Business model and results.** FY26 was Paytm's **first full-year profit: ₹552 Cr on ₹8,437 Cr revenue**, with ₹13,315 Cr of cash on hand. In Q1 FY27 revenue rose 28% to ₹2,448 Cr, profit after tax was ₹220 Cr and merchant GMV reached ₹7.1 lakh crore (company release). Paytm now puts all new investment into AI.

**Moat.** A physical merchant network, merchant-credit data, and a brand among shopkeepers that survived 2024. Its weakness is regulatory memory: regulators watch Paytm more closely than anyone.

**Metrics.** *North Star:* active merchant devices (monthly). *Inputs:* GMV per device, loan disbursals per active merchant, consumer MTU, subscription churn. *Guardrails:* compliance incidents, loan default rate at partners, device downtime.

::: key What I would build next at Paytm
1. **Shopkeeper co-pilot on the Soundbox.** *Problem:* merchants have no time to read dashboards. *Bet:* a voice summary each night ("You earned ₹8,420, 12% more than last Tuesday; your loan EMI is due Friday"). *Metric:* device retention at 12 months.
2. **Inventory credit with distributors.** *Problem:* shopkeepers pay suppliers in cash on delivery. *Bet:* let merchants pay distributors via Paytm with 15-day credit. *Metric:* credit GMV; default rate.
:::

%% article | Payments · WhatsApp Pay | The biggest distribution in India, the smallest share | WhatsApp has over 500 million Indian users and less than 1% of UPI payments. It is the best case study of why distribution alone does not win.

**Who it is for.** In theory, every Indian with WhatsApp. In practice, a small group of users who send money to family inside chats. **Share of UPI volume: about 0.65%** (NPCI, May 2026).

**Why it lost the first round.**

- **Late and capped.** WhatsApp launched a pilot in 2018, but NPCI allowed it only a limited number of users until the cap was fully removed in **December 2024**. By then the UPI habit belonged to PhonePe and Google Pay.
- **Wrong moment.** Most UPI payments are *merchant scans*, not *chat payments*. When you stand at a counter you open a scan-first app, not a messaging app.
- **No reward and little reason to switch.** Rivals paid users with cashback while WhatsApp could not. UPI interoperability meant there was no feature only WhatsApp could offer.
- **Trust split.** Many users are happy to chat on WhatsApp but hesitate to link their bank account to a social app.

**The second attempt.** Meta has made commerce inside WhatsApp a priority. Businesses message customers under **per-message pricing** (from July 2025, billed in rupees from January 2026). More than **1 million businesses use Meta's Business Agents weekly** (Meta Q2 2026), and WhatsApp added bill payments through BBPS. In June 2026 CRED founder **Kunal Shah was named head of WhatsApp**, a clear signal that payments and commerce are central to its plans (press reports). If the 30% cap is enforced, WhatsApp is the biggest ready-made alternative.

```dia
title: Where chat payments fit, and where they do not
sub: The payment moment decides which app wins
versus("Where WhatsApp Pay loses", [("Paying at a shop", "Scan-first apps open to the camera in one tap"), ("Habit already formed", "Users have used PhonePe or Google Pay for 5+ years"), ("No cashback", "Nothing pulls users to try it")], "Where WhatsApp Pay can win", [("Paying a business in chat", "The order, the bill and the payment happen in one thread"), ("Family transfers", "Money goes where the conversation already is"), ("Agent commerce", "A business agent answers, quotes and collects payment")], verdict="Distribution does not beat habit at the moment of use. WhatsApp should own payments that start in a conversation, not fight for the QR scan.")
```

::: key What I would build next at WhatsApp Pay
1. **One-tap checkout inside business chats.** *Problem:* a customer finishes a chat order and is then sent to a payment link in a browser. *Bet:* the business agent sends a native "Pay ₹640" card. *Metric:* chat-to-payment conversion rate for businesses.
2. **Group split for trips and flatmates.** *Problem:* groups track shared costs in separate apps. *Bet:* split and settle inside the group chat. *Metric:* groups with a settled split; new UPI users activated through a split.
:::

## Comparing the five

| | Razorpay | PhonePe | Google Pay | Paytm | WhatsApp Pay |
|---|---|---|---|---|---|
| Main customer | Online businesses | Mass consumers + small shops | Urban consumers | Small merchants | Chatting users, businesses |
| Core job | Accept every payment online | Pay anywhere, fast | Pay simply, safely | Get paid and get credit | Pay where you already chat |
| How it earns | MDR on cards, value-added services | Loans, insurance, broking, devices | Distribution, fees; strategic value | Devices, processing, loan fees | Business messaging (Meta) |
| Main moat | Switching costs, routing data | Habit, merchant presence | Brand, Android | Merchant devices, credit data | Distribution |
| Biggest risk | Thin margins, regulation | 30% cap, slow revenue growth | 30% cap, low priority inside Google | Regulatory memory | Habit already set elsewhere |

```dia
title: Reach versus money made per user
sub: Where each player sits today (author's judgement)
matrix("Consumer reach", "Revenue per user or merchant", [("Deep, narrow", "Few users, high value each: B2B tools"), ("Rare prize", "Large reach AND monetised: nobody fully here yet"), ("Early or stuck", "Neither reach nor revenue"), ("Free utility", "Huge reach, little revenue per user")], points=[("Razorpay", 0.15, 0.68), ("Paytm", 0.36, 0.56), ("PhonePe", 0.82, 0.24), ("Google Pay", 0.66, 0.12), ("WhatsApp Pay", 0.1, 0.1)])
```

## Likely interview questions

1. **"NPCI enforces the 30% cap tomorrow. You are PM at PhonePe. What do you do?"** A strong answer protects the heaviest and most profitable users first, then moves the rest on purpose (not at random) and treats it as a revenue-per-user problem, not a volume problem.
2. **"How would you make money from UPI without charging users?"** Walk through the stack: merchant devices, credit on UPI, distribution, ads. Name the guardrail: trust drops if every screen is an ad.
3. **"Why did WhatsApp Pay fail despite 500M users?"** Use the moment-of-use argument (scan versus chat) and interoperability, then say where it can still win.
4. **"Define success metrics for UPI Circle."** North Star: secondary users who make 3+ payments in 30 days. Guardrail: fraud disputes raised by primary users.
5. **"Payment success rate dropped 2 points on Razorpay. Find the cause."** Break it down by method (UPI, cards), bank, device and time. Most drops trace back to one bank's downtime.
6. **"Design a payments product for first-time rural users."** Consider voice, feature phones (UPI 123Pay), trust signals and family delegation. Measure a second payment within 7 days.

::: quiz Recall: payments
1. What does zero MDR on UPI mean, and why does it push payment apps into lending and devices?
2. Explain in two sentences why UPI interoperability weakens PhonePe's network effect.
3. Name three of Razorpay's features and the metric each one moves.
4. What problem does a sound box solve for a shopkeeper, and what does it give Paytm in return?
5. Give two reasons WhatsApp Pay's share is below 1%.
6. What is UPI Reserve Pay, and why does agentic commerce need it?
7. For PhonePe, pick a North Star metric and two guardrails, and justify each.
:::
