%% chapter | Product dossier · Social media | From friends to feeds to machines that know you | Social apps began as ways to see what your friends did. Today most of what you see comes from strangers, picked by AI. The teardowns below show who adapted, who did not, and how each one makes money from your attention.

A 21-year-old in Pune opens Instagram "for a minute" at 11 p.m. The first Reel is from a comedian she does not follow. The second is a cooking hack, the third a friend's story, the fourth an ad for a skincare brand. She did not know the brand existed, but it fits her so well she saves it. It is 11:40 when she puts the phone down. No friend sent her any of those Reels. A recommendation system chose them, one swipe at a time, from millions of candidates.

## The job, and the market

People hire social apps for several jobs, and each app is built around one of them. **"Keep up with my people"** (Facebook's original job, Snapchat's today). **"Entertain me when I'm bored"** (Reels, TikTok-style feeds). **"Tell me what's happening and let me react"** (X, Threads). **"Show off, and be seen"** (Instagram's grid). Advertisers hire them all for one job: **"find the exact people likely to buy, and prove it worked."**

```dia
title: How big each network is
sub: Latest reported users, 2026. Note the different measures: daily (DAU) vs monthly (MAU)
src: Meta Q2 2026 call; Threads (Meta, Jun 2026); X audited figures in SpaceX S-1 (Mar 2026); Snap Q2 2026
bars([("Facebook", 3000, "3B+ monthly users (Meta)"), ("Instagram (DAU)", 2000, "2B daily users, Jul 2026"), ("Snapchat", 1000, "~1B monthly users"), ("X", 550, "550M MAU, audited"), ("Threads", 500, "500M MAU, Jun 2026")], unit="M", hl=[4])
```

The biggest shift of the decade is from the **social graph** (you see what people you know post) to the **interest graph** (you see whatever the algorithm predicts you will watch). TikTok proved the interest graph wins attention. Meta rebuilt Facebook and Instagram around it.

```dia
title: Social graph versus interest graph
versus("Social graph (2008–2018)", [("What you see", "Posts from friends and pages you follow"), ("Growth", "Invite friends; value grows with your network"), ("Limit", "Feed runs out; friends post less over time")], "Interest graph (2019– )", [("What you see", "Anything, from anyone, ranked by predicted interest"), ("Growth", "Great content from strangers; works from day one"), ("Limit", "Weaker ties to friends; creators, not friends, supply content")], verdict="The interest graph solved the cold-start problem and the 'friends stopped posting' problem. The price is that the app feels less personal, which is why Instagram keeps adding friend features.")
```

```dia
title: How Meta's ad revenue is built
sub: The formula to use in any social-media revenue question
src: Meta Q2 2026: revenue $60.8B (+28%); ad impressions +14%, average price per ad +12%
formula([("Daily users", "3.60B daily active people across Meta apps", "+3% YoY"), ("Time per user", "Driven by AI ranking of Reels and feed", "Video time up"), ("Ad load", "Share of posts that are ads", "Impressions +14%"), ("Price per ad", "Set by auction; rises when ads convert better", "+12%")], result="Ad revenue ≈ users × time × ad load × price per ad", ops=["×", "×", "×"])
```

Price per ad rises when ads **convert better**. Meta says new AI models lifted ad conversions by up to 15.7% on Facebook, and its automated campaign product Advantage+ has reached a **$75 billion annual run rate** (Meta Q2 2026 call). Better targeting makes each ad worth more, advertisers bid more, and Meta earns more without showing more ads.

%% article | Social · Instagram | The app that kept reinventing itself | Instagram copied Snapchat's Stories, then TikTok's short videos, and grew each time. It now has two billion daily users and is India's favourite social app.

**Who it is for.** Everyone aged about 16–35, and creators and small businesses of every kind. India is Instagram's largest market. Positioning: *"bringing you closer to the people and things you love."* In practice it is three products in one: a **friends app** (Stories, DMs), an **entertainment app** (Reels), and a **shop window** for creators and brands.

**Core loop.** Watch Reels → share one with a friend in DMs → the friend replies and watches more → both post Stories → the algorithm learns what each person likes → more relevant Reels. Sharing in DMs is the loop Instagram now optimises hardest, because a shared Reel is a strong signal and also brings a friend back.

**First run.** Sign up → follow suggestions (contacts, popular accounts) → the Reels tab works immediately, even with zero follows, because it runs on the interest graph. An empty feed used to be the biggest risk. Reels removed it.

```dia
title: Instagram Reels tab, annotated
sub: One full-screen video; every button is a signal to the ranking system
phone([("Reels · Friends toggle", 0.4), ("Full-screen video", 3.2, "#DDE8F0"), ("Creator name · Follow · audio", 0.5), ("Like · Comment · Share (DM) · Save", 0.6, "#F6E6B8"), ("Nav: Home · Search · Create · Reels · Profile", 0.5, "#F6D9D7")], [(0, "Friends toggle", "Reels your friends liked or made: a fix for 'too many strangers'."), (1, "Swipe is the input", "Watch time and skips tell the model what you like in seconds."), (2, "One-tap follow", "Converts strangers into your social graph."), (3, "Share and save", "DM shares and saves count far more than likes. They are what Instagram optimises."), (4, "Create in the middle", "Supply matters: easy creation keeps content flowing. Edits app helps.")])
```

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Reels (up to 3 min) | "I'm bored; entertain me" | Full-screen, AI-ranked, endless | Time spent, DAU |
| Stories and Close Friends | "I want to share without a permanent post" | Disappears in 24 hours; smaller audience | Posting frequency |
| DMs, Blend, reposts | "I want to talk about what I watched" | Share Reels into chats; shared feeds with friends | Sends per user, DAU |
| Trial Reels | Creators: "Will my followers hate this?" | Test a Reel on non-followers first | Creator posting rate |
| Your Algorithm | "My feed feels random" | Users see and edit the topics Instagram thinks they like | Satisfaction, session quality |
| Edits (separate app) | Creators: "Editing needs another app" | Meta's own video editor | Reels uploaded |
| Teen Accounts | Parents: "Is my child safe?" | Private by default, content limits, sleep mode | Regulatory risk, parent trust |

**Business model.** Advertising: feed, Stories and Reels ads, bought through Meta's auction. Creators earn through brand deals, subscriptions and gifts. Instagram's revenue is not reported separately. It is the largest growth engine inside Meta's Family of Apps.

**Moat.** Network effects (your friends and favourite creators are here). Scale economies in AI: more users produce more data, which gives better ranking and better ads. Switching costs: your profile, followers and DMs. Branding among young users.

**Metrics.** *North Star:* daily active users who share or create (not only watch). *Inputs:* Reels watch time, DM sends per user, creator uploads, follow rate from Reels. *Guardrails:* time-well-spent surveys, teen safety reports, ad load, creator churn.

::: key What I would build next at Instagram
1. **"Local now" Reels for India.** *Problem:* users want to know what's happening in their own city (events, food, traffic). *Bet:* a city channel mixing creators and local businesses, with maps. *Metric:* local sessions per user; local business ad spend.
2. **Creator storefront with UPI.** *Problem:* Indian creators sell through DMs and payment screenshots. *Bet:* native product tags and UPI checkout in DMs. *Metric:* creator GMV; creators earning monthly.
:::

%% article | Social · Threads | Meta's fast follower | Threads borrowed Instagram's social graph to skip the cold-start problem. It reached 500 million monthly users in three years.

**Who it is for.** People who want text-based public conversation without X's toxicity or politics. Positioning: *"a new, open space for real-time conversation."*

**How it launched.** On day one in July 2023, users could sign in with Instagram and import their followers. That borrowed an existing **atomic network**, the smallest group that makes a network useful, so new users saw activity immediately. 100 million sign-ups came in five days. Many then drifted away, which is a lesson in itself: *borrowed graphs bring sign-ups; content and habit bring retention.*

**Features that fixed retention.** Direct messages, **Communities** (topic groups that came out of beta in 2026), **Live Chats** during events, **ghost posts** that disappear after 24 hours, and **Your Algo**, which lets users tell the feed what to show for 1, 3 or 7 days (TechCrunch, Jun 2026). Ads now run on Threads globally.

**Results.** **500 million monthly users in June 2026**, up 100 million in ten months. By January 2026 Threads had overtaken X in daily mobile users by some measures (TechCrunch, citing Similarweb). *North Star:* daily posters and repliers. *Guardrail:* share of feed from accounts the user doesn't follow, which must not crowd out conversation.

::: key What I would build next at Threads
**Cricket and cinema live rooms for India.** *Problem:* Indian fans react to matches and film releases in scattered places. *Bet:* official match threads with live scores and verified voices. *Metric:* DAU on match days; replies per user.
:::

%% article | Social · Facebook | The giant going back to friends | Facebook is still the world's largest social network. Its challenge is staying relevant to young people while its biggest users age.

**Who it is for.** Over three billion monthly users, skewing older than Instagram, with strength in groups, Marketplace and communities, especially outside the US. Positioning in 2025–26: a return to *"friends"*, plus video.

**What changed.** Facebook rebuilt its feed around AI-recommended video, and **video time spent rose 9% globally** in Q2 2026 (Meta call). It also added a **Friends tab** showing only friends' content, and put Messenger back inside the main app: messenger.com shut in April 2026 and users were redirected to facebook.com/messages (Social Media Today).

**Key features and their jobs.** **Groups** ("people who share my interest or problem"): a big reason people stay. **Marketplace** ("buy and sell used goods locally"): a high-intent daily habit and the subject of an IIMA metrics case. **Dating** and **Events**: attempts to win young adults back. **Community Notes** replaced third-party fact-checking in the US in 2025, a model borrowed from X.

**Metrics.** *North Star:* daily active users who interact with friends or groups. *Inputs:* Marketplace listings and messages, group posts, video time. *Guardrails:* young-adult share of DAU, integrity (fake accounts, scams on Marketplace).

::: key What I would build next at Facebook Marketplace
**Verified local sellers with escrow via UPI.** *Problem:* buyers fear scams on used-goods deals. *Bet:* seller verification plus payment held until pickup is confirmed. *Metric:* listings that sell; scam reports per 1,000 transactions.
:::

%% article | Social · X (formerly Twitter) | The town square that became part of a rocket company | X shrank as a business after 2022. It kept its role in news and politics, and it is now tied to xAI's Grok and SpaceX.

**Who it is for.** Journalists, politicians, investors, tech and crypto communities, sports fans: anyone who wants **real-time news and argument**. Positioning under Elon Musk: *"the everything app"* and a platform for free speech.

```dia
title: X since the acquisition
sub: From a $44B take-private to a unit of SpaceX
src: Company announcements; SpaceX S-1 filing (May 2026) via Social Media Today
timeline([("Oct 2022", "Musk buys Twitter", "$44B; ~80% of staff later cut"), ("2023", "Rebrand to X; paid blue ticks", "Many large advertisers pause spending"), ("2023–25", "Community Notes, Grok, long posts, video", "Subscriptions grow; ads shrink"), ("Mar 2025", "xAI merges with X", "Grok AI and X data combined"), ("2026", "SpaceX acquires xAI; S-1 filed", "First audited X numbers made public"), ("2026", "X Money in beta", "Payments: the 'everything app' step")])
```

**The numbers.** The SpaceX filing showed **550 million MAU** (March 2026), below the 600 million the company had claimed, and about **350 million posts a day**. **Ad revenue was $1.8 billion in 2025**, down from $4.4 billion in 2022. There are 6.3 million paying subscribers across X Premium and SuperGrok, and **Grok reaches 117 million monthly users** (Social Media Today, May 2026).

**What X does uniquely well.** **Community Notes**: crowd-sourced context added to misleading posts, shown only when people who usually disagree both rate a note helpful. It is a clever design that Meta copied. X is also still the fastest place for breaking news.

**Weaknesses.** Brand safety concerns for advertisers, a user base that fell after 2022, heavy dependence on one leader's decisions, and a less than 1% paid conversion.

::: key What I would build next at X
**Verified-source news mode.** *Problem:* in a crisis users cannot tell rumours from reports. *Bet:* a toggle showing only posts from verified news organisations and Community-Noted posts. *Metric:* DAU during breaking news; advertiser return on brand-safe inventory.
:::

%% article | Social · Snapchat | The camera company | Snapchat opens to a camera, not a feed. That one decision still defines it, and India has become its biggest growth market.

**Who it is for.** Teens and young adults who talk to close friends through pictures. Positioning: *"the fastest way to share a moment"*, private, playful and not about follower counts. Snap reported **about 1 billion monthly users** and added **10 million daily users in Q2 2026**, mostly outside North America and Europe, with India a major contributor (Snap Q2 2026).

```dia
title: Snapchat opens to the camera
sub: The default screen is the product strategy
phone([("Flash · flip · settings", 0.5), ("Live camera view", 3.0, "#DDE8F0"), ("Lens carousel (AR filters)", 0.6, "#F6E6B8"), ("Capture button", 0.4, "#F6D9D7"), ("Nav: Map · Chat · Camera · Stories · Spotlight", 0.5)], [(0, "Streaks, via Chat", "Daily back-and-forth habits (Snapstreaks) drive retention."), (1, "Camera first", "Creating is the default, not scrolling. Metric: Snaps sent per user."), (2, "Lenses", "AR fun makes ordinary photos worth sending. 'Lens plays' is an input metric."), (3, "One big button", "Tap for photo, hold for video; anyone can learn it in seconds."), (4, "Chat next to camera", "Snaps go to friends, not a public feed: private and low-pressure.")])
```

**Business model.** Ads (AR lens ads, Stories ads, Spotlight) plus **Snapchat+ subscriptions**, which drove "other revenue" up **85% to $316 million** in Q2 2026. Total quarterly revenue was about **$1.6 billion (+19%)**. Snap is also betting on AR hardware: **Specs** glasses priced at $2,195.

**Moat.** Close-friend network effects, where your best friends and your Streaks are here. Branding with young people. An AR engine and creator ecosystem (Lens Studio). Its weakness is monetisation per user: Indian users bring growth but earn far less in ad revenue than US users.

**Metrics.** *North Star:* daily users who send a Snap. *Inputs:* Snaps per user, Lens plays, Stories views, Snapchat+ conversion. *Guardrails:* teen safety reports, revenue per user by region.

::: key What I would build next at Snapchat India
**Festival and college Lenses with local brands.** *Problem:* Indian users are active but low-value for advertisers. *Bet:* sponsored AR Lenses for Diwali, IPL and college fests, sold self-serve to Indian SMEs. *Metric:* India revenue per DAU; Lens plays per user.
:::

## Comparing the five

| | Instagram | Threads | Facebook | X | Snapchat |
|---|---|---|---|---|---|
| Main job | Entertain + share with friends | Public text conversation | Groups, Marketplace, video | Real-time news and debate | Close-friend visual chat |
| Graph | Interest + social | Borrowed Instagram social + interest | Social + interest | Interest (public) | Close social |
| Money | Ads | Ads (new) | Ads | Ads + subscriptions | Ads + Snapchat+ |
| 2026 scale | 2B DAU | 500M MAU | 3B+ MAU | 550M MAU | ~1B MAU |
| Risk | Teen safety, TikTok-style fatigue | Retention | Ageing users | Advertisers, governance | Monetising RoW users |

```dia
title: Public versus private, friends versus strangers
sub: Where each app's core experience sits (author's judgement)
matrix("Content from strangers (interest graph)", "Public audience", [("Public, friends", "Classic Facebook feed"), ("Public, strangers", "X, Threads, Reels: broadcast"), ("Private, friends", "Snapchat, DMs: close circles"), ("Private, strangers", "Group chats, communities")], points=[("X", 0.82, 0.68), ("Threads", 0.64, 0.56), ("Instagram", 0.58, 0.64), ("Facebook", 0.34, 0.6), ("Snapchat", 0.14, 0.2)])
```

## Likely interview questions

1. **"Instagram's DAU fell 3% in India. Diagnose."** (IIMA: Instagram low adoption) Split by age, platform and region, and check whether it is new users or returning ones. Look at a Reels ranking change, app performance, or a competitor such as YouTube Shorts.
2. **"What metric would you use for Instagram creator commerce?"** (IIMA) Creator GMV, supported by creators transacting monthly and buyer conversion. Guardrails: ad load and feed quality.
3. **"How would you grow Threads in India?"** Content supply first: cricket, cinema and news creators. Then local-language support and notifications for live events.
4. **"Should X make everyone pay?"** Estimate conversion against user loss. Network effects collapse if the free tier shrinks, so keep reading free and charge for reach or features.
5. **"Design Facebook Reactions today."** (IIMA) Richer signals than a like, helping ranking. Measure reactions per post and whether more people post.
6. **"How does Meta make money if the product is free?"** Walk through users × time × ad load × price per ad, and explain why better AI raises the price per ad.

::: quiz Recall: social media
1. Explain the difference between the social graph and the interest graph, with one app for each.
2. Write Meta's ad revenue formula and say which term AI improvements raise.
3. How did Threads avoid the cold-start problem, and why was that not enough?
4. What makes Community Notes' design resistant to one side gaming it?
5. Why does Snapchat open to the camera, and what metric does that choice protect?
6. Give Instagram a North Star metric that is better than "time spent", and explain why.
7. (E-commerce) How is Instagram becoming a competitor to Myntra?
:::
