%% chapter | Product dossier · Ad-supported media | Free to watch, paid for by attention | YouTube, Spotify, Twitch and Moj give you content for free and sell your attention to advertisers. Each also has to pay the creators who make that content. How they split the money decides who wins.

A mechanic in Coimbatore fixes a Royal Enfield while a YouTube video in Tamil explains the carburettor. He has watched this creator for three years. The creator, a former mechanic himself, earns more from YouTube ads, a sponsored tool brand and channel memberships than he did from his garage. Neither the viewer nor the creator pays YouTube anything. The advertiser pays, YouTube keeps a share, and the creator gets the rest. Every ad-supported media business is some version of that triangle.

## The job, and the market

Viewers and listeners hire these products for **"entertain or teach me, for free, whenever I have a spare minute."** Creators hire them for **"an audience, and a way to earn from it."** Advertisers hire them for **"attention from the right people, at a price that pays back."** The platform's product job is to keep all three satisfied: enough ads to pay creators, few enough that viewers stay.

```dia
title: What a creator earns from 1 lakh views in India
sub: The creator-economics formula every ad-supported platform runs on
src: Revenue share from YouTube Partner Program terms (55% long-form); other values illustrative for Indian audiences
formula([("Views", "Monetised long-form views", "1,00,000"), ("Ad impressions per view", "Pre-roll, mid-roll; many views show no ad", "~0.6"), ("Price per 1,000 impressions", "India CPMs are far below US levels", "₹80 (illus.)"), ("Creator share", "YouTube long-form: 55% to creator", "55%")], result="Creator earnings ≈ 1,00,000 × 0.6 × ₹80 ÷ 1,000 × 55% ≈ ₹2,640", ops=["×", "×", "×"])
```

That small number explains Indian creator behaviour. Ads alone rarely pay the bills, so creators add **brand deals, memberships, courses and live gifts**. It also explains why platforms fight over **revenue share**: a few points more for creators can pull the best ones across.

```dia
title: How much of the money goes to the creator
sub: Headline creator revenue shares, 2026
src: YouTube Help (Partner Program); Twitch and Kick public terms; reported in industry coverage (2026)
bars([("Kick subscriptions", 95, "95/5, used to lure big streamers"), ("YouTube fan funding", 70, "Memberships, Super Chat"), ("Twitch Partner Plus", 70, "Top streamers only"), ("YouTube long-form ads", 55, "The long-standing standard"), ("Twitch standard subs", 50, "Most streamers"), ("YouTube Shorts", 45, "Share of a pooled ad fund")], unit="%", hl=[0])
```

The pattern to notice: the challenger pays creators the most, and the leader pays the least but offers the biggest audience. Creators usually follow the audience, not the percentage.

%% article | Media · YouTube | The world's largest library, and India's TV | YouTube is where India learns, laughs and listens. It has over 500 million Indian users and pays creators more than any other platform.

**Who it is for.** Everyone: over **2.7 billion users worldwide and around 518 million in India**. Positioning: *"give everyone a voice and show them the world."* It has four products in one: long-form video (now mostly watched on TVs in many markets), **Shorts** (200 billion daily views), YouTube Music, and Premium.

**Core loop.** Search or open Home → watch → the next video autoplays or is recommended → subscribe to a creator → notifications bring you back → creators see their audience grow and upload more. The **supply loop** matters as much: more viewers → more ad money → more creators earning → more and better videos.

```dia
title: YouTube home on a phone, annotated
sub: Serving three habits: long videos, Shorts and subscriptions
phone([("Search · cast · notifications", 0.5), ("Topic chips: All · Music · Cricket · Tamil", 0.4, "#DCEFE0"), ("Recommended long video (with ad)", 1.4, "#DDE8F0"), ("Shorts shelf (vertical tiles)", 1.2, "#F6E6B8"), ("More recommendations", 1.0), ("Nav: Home · Shorts · + · Subscriptions · You", 0.5, "#F6D9D7")], [(0, "Cast button", "Long-form is moving to TV screens; casting is a key habit."), (1, "Language and topic chips", "India watches in many languages; chips let users steer the feed."), (2, "Recommendations drive most views", "Ranked for satisfaction, not only clicks. Metric: watch time plus surveys."), (3, "Shorts shelf", "Short videos on Home pull users into Shorts and vice versa."), (5, "Upload button in the middle", "Supply matters: easy creation keeps content flowing.")])
```

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Recommendations | "I don't know what to watch" | Ranking tuned for satisfaction surveys as well as watch time | Watch time, satisfaction |
| Shorts | "I have 30 seconds" | Vertical feed; revenue pooled and shared | Shorts views, creator uploads |
| Partner Program (YPP) | Creators: "How do I earn?" | Tiers: 500 subscribers (fan funding), 1,000 + watch hours (ads) | Monetising creators |
| Memberships, Super Chat, Shopping | Creators: "Ads don't pay enough" | Direct fan payments; product tags | Creator revenue per channel |
| Premium and Music | "Ads interrupt my music" | Ad-free, background play, downloads | Subscribers (125M incl. trials, 2025) |
| Auto-dubbing and captions | "It's not in my language" | AI dubbing into other languages | Views from other languages |

**Business model.** Ads (about 55% of long-form ad revenue goes to creators), subscriptions (Premium, Music, YouTube TV in the US), and a cut of fan payments. YouTube ad revenue grew **13%** in Q2 2026 (Alphabet). YouTube says it paid creators, artists and media companies **over $100 billion** between 2021 and 2024. In August 2026 YouTube announced that from **February 2027** new creators will need **8,000 watch hours (or 20 million Shorts views)** to join the ad programme, double today's bar (reported by Indian creator-economy sites). The aim is to reward sustained quality over volume.

**Moat.** **Two-sided network effects** (viewers ↔ creators), the **largest video library in the world** (a cornered resource built over 20 years), Google's **ad-sales machine**, and **Android distribution**.

**Metrics.** *North Star:* daily watch time from satisfied viewers. *Inputs:* daily viewers, Shorts views, uploads by active creators, share of monetising creators. *Guardrails:* policy violations (misinformation, unsafe content for kids), ad load, creator earnings concentration.

::: key What I would build next at YouTube India
1. **Learning mode for exam students.** *Problem:* students watch lectures but lose track across channels. *Bet:* playlists turned into courses with progress tracking, notes and quizzes. *Metric:* weekly learners; completion rate.
2. **Regional creator accelerator.** *Problem:* small creators in Bhojpuri, Odia and Assamese can't monetise under the higher bar. *Bet:* auto-dubbing and a regional fund for fast-growing channels. *Metric:* monetising creators in smaller languages.
:::

%% article | Media · Spotify | Freemium audio at scale | Spotify gives most of its users music for free, paid for by ads, and turns enough of them into subscribers to make a profit.

**Who it is for.** Music and podcast listeners worldwide: **777 million monthly users, 300 million paying** (Spotify Q2 2026). In India most users are on the free tier, and Spotify competes with YouTube Music, JioSaavn and Gaana. Positioning: *"the soundtrack to your life."*

**Core loop.** Listen free with ads → Spotify learns your taste → Discover Weekly, Daily Mix and Wrapped make the product feel personal → frustration with ads or limits → upgrade to Premium. Spotify's 2018 listing documents said that over 60% of new Premium subscribers had first been free users, which is why the free tier is a **marketing channel**, not charity.

```dia
title: Spotify's users, free versus paying
sub: Q2 2026, approximate (millions)
src: Spotify Q2 2026 results (777M MAU, 300M subscribers). Ad-supported share derived by subtraction
stack100([("MAU", [("Premium subscribers", 39), ("Ad-supported free users", 61)])], note="Premium brings in most of the revenue; the free tier feeds it and earns from ads. 'Talk to Spotify' (voice) and Reserved (ticketing) launched in 2026.")
```

```dia
title: Where a €10 Premium payment goes
sub: Per subscriber per month, using Spotify's Q2 2026 margins; illustrative split of costs
src: Spotify Q2 2026: gross margin 33.4%, operating income €655M on €4.8B revenue; cost split illustrative
waterfall([("Premium revenue", 10, ""), ("Royalties and delivery", -6.66, "Mostly paid to labels and publishers"), ("R&D", -0.7, "Product and engineering"), ("Sales and marketing", -0.9, ""), ("G&A", -0.38, "")], total="Operating profit", fmt="{:,.2f}", takeaway="Spotify keeps about €1.36 of every €10. Record labels, not Spotify, capture most of music streaming's value.")
```

**Key features.** **Discover Weekly and Daily Mixes** (personal discovery; metric: tracks saved). **Wrapped** (a year-end summary that users share: a free viral marketing campaign every December). **Podcasts and audiobooks** (content Spotify can own or license more cheaply than music, which improves margins). **AI DJ and "Talk to Spotify"** (voice requests). **Free tier upgrades** so free users can pick specific songs (2025), which reduces the reason to leave for YouTube.

**Moat.** Personalisation data and **switching costs** (your playlists and years of taste history). Scale in negotiating with labels. The weakness is that labels hold the **cornered resource** (the music), so they capture most of the value, and Spotify's margins depend on them.

**Metrics.** *North Star:* time spent listening by monthly users. *Inputs:* free-to-Premium conversion, Premium churn, podcast minutes, ad fill rate. *Guardrails:* gross margin, artist and label satisfaction, ad frequency on the free tier.

::: key What I would build next at Spotify India
**Regional "radio" with local ads.** *Problem:* Indian free users listen in many languages, and advertisers can't target them well. *Bet:* language-based live stations with local DJs (AI-assisted) and city-level audio ads sold to small businesses. *Metric:* free-tier listening hours; India ad revenue per user.
:::

%% article | Media · Twitch | Live, together, now | Twitch turned watching other people play video games into a social experience, and it still leads live streaming. But rivals are paying creators more to leave.

**Who it is for.** Gamers and fans of live, unscripted streams: gaming, "Just Chatting", music, esports. Twitch is owned by Amazon (since 2014). It has **about 54% of live-streaming watch time**, against YouTube's 24% and Kick's 11% (industry trackers, 2026). Positioning: *"you're already one of us."*

**Core loop.** Join a live stream → chat with others → the streamer reacts to your message → you subscribe, send Bits (tips), use emotes → you come back at the next scheduled stream. The **live chat** is the product: viewers watch *with* each other, not just watch.

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Live chat and emotes | "I want to be part of it" | Channel-specific emotes unlock with a subscription | Chatters per stream |
| Subscriptions, Bits | "I want to support my streamer" | Monthly subs and micro-tips shown on stream | Revenue per viewer |
| Raids | Streamers: "How do small channels grow?" | Send your audience to another streamer at the end | New-viewer discovery |
| Clips | "I missed the best moment" | Short shareable clips | Off-platform reach |
| Channel points | "Reward loyal viewers" | Points for watching, redeemable for perks | Watch time |

**Creator economics under pressure.** Twitch's standard subscription split is **50/50**, rising to 70/30 for top creators. **Kick** offers creators **95%**, which has lured some big streamers. Twitch's challenge is that live video is **expensive to deliver** (it shut down in South Korea in 2024 because of high network fees). It cannot easily match 95/5 without losing money.

```dia
title: Twitch versus Kick
versus("Twitch", [("Creator split", "50/50 standard; up to 70/30"), ("Strength", "Largest audience, culture, tools"), ("Weakness", "High delivery costs; creators feel underpaid")], "Kick", [("Creator split", "95/5 on subscriptions"), ("Strength", "Pays stars to switch; looser rules"), ("Weakness", "Smaller audience; brand-safety concerns")], verdict="Money moves creators, but audiences move slowly. Twitch's defence is discovery and community, not matching the split.")
```

**In India**, most live streaming happens on YouTube, with gaming-first local apps like Loco and Rooter. Twitch is small, because of low ad rates and the payment habits of Indian fans.

::: key What I would build next at Twitch
**Co-streaming for new creators.** *Problem:* new streamers stream to empty rooms and quit. *Bet:* match small streamers to "co-stream" events alongside bigger ones in the same game. *Metric:* 90-day retention of new streamers; average concurrent viewers.
:::

%% article | Media · Moj (ShareChat) | The TikTok-shaped hole | When India banned TikTok in 2020, Moj launched within days. After years of losses it found profit, not in short videos, but in micro-dramas and live gifting.

**Who it is for.** Users in smaller towns watching in Hindi and regional languages. **ShareChat and Moj together have about 150 million monthly users** (Mohalla Tech, 2026). Positioning: *"India's own"* short video, in 15+ languages.

```dia
title: Moj's path, from launch to profit
src: Company statements; Business Today and Bloomberg (Jul 2026)
timeline([("Jun 2020", "TikTok banned in India", "~200M users need a new app"), ("Jul 2020", "Moj launches", "Built in days on ShareChat's stack"), ("2022", "Merges with MX TakaTak", "Consolidation; heavy creator payments"), ("2022–24", "Cost cuts, layoffs", "Reels and Shorts win the category"), ("2025–26", "Micro-dramas and QuickTV", "Paid episodic short shows"), ("Q1 FY27", "Operationally profitable", "~₹1,400 Cr annual run rate; IPO planned")])
```

**What worked.** Competing with Instagram Reels and YouTube Shorts on free short videos was a losing fight. ShareChat found money in two formats Meta and Google did not dominate. **Micro-dramas**: very short, episodic soap operas, where ShareChat has about two-thirds of India's audience, with 65 million monthly viewers and a subscription app, QuickTV. And **live audio chatrooms with virtual gifts**, where fans pay hosts in small amounts.

**Business model.** Ads, virtual gifting and micro-drama subscriptions. Annual revenue is running at about **₹1,400 Cr, growing over 30%**, and the company plans a **$400 million IPO** (Business Today, Jul 2026).

**Lesson.** When you cannot win a category against Meta and Google, find a **format or monetisation model** they are not optimised for, and own it.

::: key What I would build next at Moj
**Creator-led micro-drama studio.** *Problem:* micro-drama supply depends on a few studios. *Bet:* give top Moj creators tools and revenue share to produce their own series. *Metric:* series published per month; paid conversions per series.
:::

## Comparing the four

| | YouTube | Spotify | Twitch | Moj / ShareChat |
|---|---|---|---|---|
| Core format | Long video + Shorts | Audio (music, podcasts) | Live streams | Short video, micro-dramas, live audio |
| Money | Ads + Premium | Premium + ads | Subs, Bits, ads | Ads, gifting, subscriptions |
| Creator deal | 55% long-form, 45% Shorts | Pays rights holders | 50/50 to 70/30 | Gifting share, creator funds |
| Moat | Library, network, Google ads | Personalisation, habit | Live community | Regional languages, niche formats |
| Risk | Regulation, creator bar | Label power | Creator poaching, costs | Scale against Meta and Google |

## Likely interview questions

1. **"YouTube's daily revenue: estimate it."** (IIMA guesstimate) Daily viewers × videos watched × ads per video × CPM, then check the result against Alphabet's reported YouTube ad revenue.
2. **"Should Spotify launch a cheaper India plan?"** Weigh the conversion lift against cannibalisation of existing subscribers. Test in two cities. Guardrail: revenue per user. (Compare the IIMA JioSaavn family-plan case.)
3. **"Design a podcast feature for Spotify."** (IIMA) Pick a segment (commuters in India), a problem (discovery in regional languages), and a metric (weekly podcast listeners).
4. **"How would you stop top streamers leaving Twitch for Kick?"** Tools, discovery, guaranteed deals for the top tier, and community features money cannot buy.
5. **"Is raising YouTube's monetisation bar a good idea?"** It improves quality and advertiser trust, but may slow new creators. Offer a fan-funding path at lower thresholds.
6. **"Moj's growth has stalled. What next?"** Double down on formats where it leads, micro-dramas and live gifting, rather than copying Reels.

::: quiz Recall: ad-supported media
1. Write the creator-earnings formula and fill it in for 1 lakh views.
2. Why is Spotify's free tier described as a marketing channel?
3. Who captures most of the value in music streaming, and why?
4. What makes Twitch's live chat the core of the product?
5. How did ShareChat reach operating profit after losing the short-video fight?
6. Place YouTube Shorts, Twitch and Kick on the creator-share scale.
7. (OTT) How is JioHotstar's ad model different from YouTube's?
:::
