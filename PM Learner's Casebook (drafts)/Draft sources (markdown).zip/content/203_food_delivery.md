%% chapter | Product dossier · Food delivery | The three-sided marketplace that learned to make money | Zomato and Swiggy took a decade to turn a ₹450 biryani order into a profit. The lessons in that climb are what interviewers probe.

Friday, 9:15 p.m., heavy rain in Bengaluru. Orders on both apps jump sharply. Riders are fewer, because many stay home. Within minutes the apps show a small "rain fee", widen delivery-time estimates, and quietly stop showing restaurants that are more than a few kilometres away. None of this is visible as a "feature". It is the marketplace balancing three groups at once: hungry customers, busy kitchens, and delivery partners who are getting wet.

## The job, and the market

A customer hires a food app to **"get the food I'm craving, now, without cooking or going out."** A restaurant hires it to **"fill my kitchen with orders beyond the tables I have."** A delivery partner hires it to **"earn a steady income per hour, on my own schedule."** A good answer about this industry always names all three.

```dia
title: One order, three customers
sub: The platform must keep all three sides coming back
hub("Food app", [("Customer", "Wants choice, speed and fair prices. Pays food cost + delivery and platform fees."), ("Restaurant", "Wants orders and visibility. Pays 18–30% commission plus ads."), ("Delivery partner", "Wants earnings per hour and safety. Paid per order plus incentives."), ("Advertisers", "Restaurants and brands pay for top slots in search and banners."), ("Regulators and payments", "Gig-worker rules, GST on fees, payment costs.")], center_desc="matches demand, supply and riders every minute")
```

India's food delivery market is a **duopoly**. Zomato (owned by Eternal) leads, Swiggy follows, and a handful of challengers compete for what is left.

```dia
title: The duopoly, by order value
sub: Q1 FY27 (Apr–Jun 2026), ₹ crore per quarter
src: Eternal and Swiggy shareholder letters via MediaNama, YourStory (Jul 2026). Zomato reports NOV (net order value); Swiggy reports GOV (gross), so the gap is slightly understated
bars([("Zomato: order value", 10769, "+20% YoY; 27.2M monthly customers"), ("Swiggy: order value", 9490, "+17.4% YoY; 19.2M monthly users"), ("Zomato: adj. EBITDA", 606, "5.6% of NOV"), ("Swiggy: adj. EBITDA", 292, "about 3.1% of GOV")], fmt="{:,.0f}", hl=[2, 3])
```

Both companies are now profitable in food delivery. It took ten years. The route there tells you most of what matters.

```dia
title: Where the money goes on a ₹450 food order
sub: ₹ per order, illustrative; calibrated to reported margins of 3–6% of order value
src: Illustrative, built from company disclosures on take rates, platform fees and margins
waterfall([("Restaurant commission", 90, "~20% of food value"), ("Customer fees", 38, "Delivery + ₹14.9 platform fee"), ("Ads from restaurants", 15, "Sponsored listings"), ("Delivery partner cost", -85, "Pay per order + incentives"), ("Discounts", -18, "Platform-funded offers"), ("Payments, support, tech", -15, "Gateway, refunds, servers")], total="Contribution", takeaway="About ₹25 per order is left before marketing and overheads. Every ₹5 of rider cost or discount matters.")
```

The lever that moves this waterfall most is **delivery cost per order**. It falls when a rider completes more orders per hour, which requires **density**: many orders in a small area. That is why the apps limit how far away a restaurant can be during peak hours, **batch** two orders on one trip, and pay incentives to keep riders logged in at dinner time.

%% article | Food delivery · Zomato | From restaurant reviews to India's most profitable food app | Zomato started as a place to read menus. Its advantage is still discovery: knowing what you want to eat before you do.

**Who it is for.** Urban diners aged about 18–40, in over 800 cities. Positioning: *"better food for more people."* The brand voice is witty and self-aware, and its push notifications have become part of its marketing. Zomato is part of **Eternal**, which also owns Blinkit (quick commerce), District (going out) and Hyperpure (supplies for restaurants).

**Core loop.** Open the app → discover (search, recommendations, ratings) → order → get it in about 30 minutes → rate → better recommendations next time → order again. The **supply loop** runs underneath: more orders → more restaurants list and advertise → more choice → more customers.

**First run.** Phone number and OTP → location permission → a home screen showing restaurants that deliver *right now*. The biggest drop-off is the first order. New users see first-order offers and "Top rated" filters, which reduce the risk of a bad first meal.

```dia
title: Zomato delivery home, annotated
sub: Built to turn a vague craving into an order in under a minute
phone([("Address · Profile", 0.5), ("Search: 'biryani', 'pizza'...", 0.6), ("Filter chips: Rating 4+, Pure veg, Offers", 0.5), ("What's on your mind? (dish icons)", 1.0), ("Ad: sponsored restaurant", 0.8, "#F6E6B8"), ("Restaurant cards: rating · time · offer", 1.7), ("Nav: Delivery · District · Blinkit", 0.5, "#F6D9D7")], [(1, "Dish-first search", "People crave dishes, not restaurants. Search returns dishes across kitchens."), (3, "Dish icons", "One tap turns a craving into a list of options. Lowers decision effort."), (2, "Filters as chips", "Trust filters (rating, veg) come before price. Metric: search-to-menu rate."), (5, "The card shows three facts", "Rating, delivery time, offer: the three things users compare."), (4, "Paid slot in the feed", "Restaurants pay per click. Guardrail: ads must not lower order rate.")])
```

| Feature | User problem | Why designed this way | Metric it moves |
|---|---|---|---|
| Ratings and reviews | "Will this place be good?" | Zomato's origin; separate delivery and dining ratings | First-order conversion |
| Live tracking and rider chat | "Where is my food?" | Map plus ETA cuts anxious support calls | Support contacts per order |
| Zomato Gold | "Delivery fees add up" | Low-priced membership: free delivery + discounts on eligible orders | Order frequency, retention |
| Healthy mode (2025) | "I want to eat better but can't tell what's healthy" | Health scores on dishes; a healthy filter | Share of health-focused orders |
| Food Rescue | "Cancelled orders waste food" | Cancelled orders are offered nearby at a discount | Cancellation cost, waste |
| Platform fee | Zomato: "tiny margins on each order" | A flat ₹14.9 per order in major cities | Revenue per order (guardrail: conversion) |
| Restaurant ads and Hyperpure | Restaurants: "I need visibility and supplies" | Pay-per-click ads; B2B ingredients delivered | Ad revenue, restaurant retention |

**Business model.** Food delivery NOV was **₹10,769 Cr in Q1 FY27 (+20%)**, with adjusted EBITDA of **₹606 Cr (5.6% of NOV)**. There are 328,000 restaurant partners and 638,000 delivery partners (Eternal Q1 FY27). The platform fee alone brought in about ₹154 Cr in the quarter (Inc42). Revenue per order comes from commission, customer fees, and ads.

**Growth loops.** (1) *Content and brand*: witty notifications and social posts get shared, which acts as free acquisition. (2) *Restaurant flywheel*: more orders → more restaurants onboard and advertise → more choice. (3) *Cross-sell within Eternal*: Blinkit and District users become Zomato users and the other way round.

**Moat.** Local **network effects**: in each neighbourhood, more restaurants and more riders make the service better for everyone. **Scale economies** in delivery: higher density gives lower cost per order. **Data**: ten years of what people order, when, and where. The weakness is that both switching costs and multi-homing are easy. Most heavy users have both apps and compare prices.

**Metrics.** *North Star:* orders delivered per week, or NOV. *Inputs:* monthly transacting customers, orders per customer, search-to-order conversion, restaurant availability at peak (% of top restaurants online at 8 p.m.), median delivery time. *Guardrails:* cancellations, order accuracy complaints, rider earnings per hour, total fees as a % of the bill.

**2025–26 moves.** The parent company was renamed **Eternal** in 2025. Zomato launched Healthy mode and healthy subscriptions. It shut its quick-food experiments *Zomato Quick* and *Everyday* but kept **Bistro**, the Blinkit-branded 10-minute café app for ₹50–150 items, which is growing slowly (about 10 kitchens a quarter). Management argues that "discount-led growth" by rivals has peaked.

::: key What I would build next at Zomato
1. **"Decide for me" for groups.** *Problem:* a group of four takes 20 minutes to agree on dinner. *Bet:* each person votes on dishes in a shared link; the app proposes one order from one restaurant that satisfies everyone's constraints (veg, budget, spice). *Metric:* group orders per week; time from opening the link to order.
2. **Restaurant menu engineering assistant.** *Problem:* small restaurants don't know which dishes lose them money on delivery. *Bet:* show each restaurant dish-level conversion, repeat rate and packaging complaints, with suggested changes. *Metric:* restaurant GOV growth; restaurant churn.
3. **Health-goal plans.** *Problem:* people who order daily want to hit a protein or calorie goal. *Bet:* weekly meal plans built from nearby menus, delivered on a schedule. *Metric:* orders per subscriber; 60-day retention.
:::

%% article | Food delivery · Swiggy | The convenience platform | Swiggy's bet is that one membership and one delivery fleet can serve food, groceries, dining out and more. Food delivery pays for that bet.

**Who it is for.** The same urban customer as Zomato, with a stronger hold in South India. Positioning: *"unparalleled convenience"*, across food, Instamart groceries, Dineout table reservations and Scenes events. Swiggy was built from day one around owning **the delivery experience**. It was the first to run its own large fleet rather than relying on restaurants' riders.

**Core loop.** The food loop is the same as Zomato's. On top of it sits a *platform loop*: a Swiggy One member → free delivery on food **and** Instamart → uses more services → the membership pays for itself → renews.

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Swiggy One | "I pay delivery fees on three apps" | One membership across food, Instamart and Dineout | Cross-service users, frequency |
| Bolt (10-minute food) | "I want a snack now, not in 35 minutes" | Only nearby restaurants and quick-to-make items | Orders under 15 min, repeat rate |
| 99 Store and Toing | "Food delivery is too expensive for daily meals" | Low-price meals; Toing is a separate budget app | New users, orders per user |
| Dineout and Scenes | "Where do we go out tonight?" | Table booking with bill discounts; events | Out-of-home GOV (profitable) |
| Builders Club / AI stack (2026) | Developers: "Let AI assistants order food" | Opens Swiggy's commerce stack to developers and agents | Orders from partner surfaces |

**Business model.** Q1 FY27 food GOV was **₹9,490 Cr (+17.4%)** with adjusted EBITDA of **₹292 Cr** and **19.2 million monthly transacting users**. Group revenue was ₹6,812 Cr (+37%) and the net loss narrowed to ₹791 Cr, mostly because Instamart losses shrank (YourStory, Inc42, Jul 2026). Food delivery funds the group. Instamart is where the losses have been.

**What went wrong, and what it teaches.** Swiggy launched **Snacc**, a 15-minute cloud-kitchen snack app, in January 2025 and **shut it in February 2026** because "the broader economics made it challenging to scale." Zomato closed Quick and Everyday. Zepto Café scaled back its menu and footprint. Only Swiggy's **Bolt**, which uses existing restaurants rather than new kitchens, and Zomato's small Bistro survived. The lesson: speed is a cost, so a faster promise must come from supply you already have.

```dia
title: The quick-food experiments, 2022–2026
sub: Most tried to add speed with new kitchens; most closed
src: Company announcements and press reports (TechCrunch, YourStory, Business Standard)
timeline([("2022", "Zomato Instant", "10-minute food from 'finishing stations'. Wound down in 2023."), ("Oct 2024", "Swiggy Bolt", "10-minute delivery from existing nearby restaurants. Still live."), ("Dec 2024", "Bistro by Blinkit", "10-minute café food at ₹50–150. Growing slowly."), ("Jan 2025", "Swiggy Snacc", "Own cloud kitchens, 15-minute snacks. Shut Feb 2026."), ("2025", "Zomato Quick, Everyday", "Shut: 'unclear path to profitability'."), ("2025–26", "Zepto Café", "Rapid rollout, then cut back stores and menu.")])
```

**Moat.** The same as Zomato's, but slightly weaker at number two: lower order density in many cities means a higher cost per order. Swiggy's distinct asset is the **cross-category membership** plus one shared fleet.

**Metrics.** *North Star:* weekly transacting users across the platform. *Inputs:* food orders per user, Swiggy One penetration, cross-category users, delivery time. *Guardrails:* food adjusted-EBITDA margin (it must keep funding Instamart), cancellations, rider earnings.

::: key What I would build next at Swiggy
1. **Office lunch subscriptions.** *Problem:* office workers order lunch daily but pay high fees on small orders. *Bet:* pooled office deliveries at fixed slots with lower fees. *Metric:* orders per rider-hour at lunch; subscriber retention.
2. **One cart across food and Instamart.** *Problem:* customers want a dessert from a restaurant and ice cream from the store in one delivery. *Bet:* a combined cart with a single rider when both are within range. *Metric:* AOV per trip; cross-category orders.
:::

%% article | Food delivery · magicpin | The challenger on an open network | magicpin cannot outspend the duopoly. So it rides ONDC, a government-backed open network, and competes on lower commissions and lower prices.

**Who it is for.** Price-sensitive customers who compare prices, and restaurants unhappy with duopoly commissions. Positioning: *"the same food, cheaper."* magicpin began in 2015 as a hyperlocal discovery app that gave cashback for spending at local shops. It now calls itself **India's third-largest food delivery app** and is the largest food seller app on ONDC. It handled around 150,000 orders a day in late 2024 (Business Standard, Oct 2024).

**How ONDC works.** ONDC (Open Network for Digital Commerce) separates the pieces a marketplace normally owns. A *buyer app* (such as Paytm or magicpin) shows the menu. A *seller app* connects the restaurant. A *logistics provider* delivers. Each piece can be a different company, so the restaurant can be found in many apps at once, usually at lower commission.

```dia
title: An order on ONDC versus inside Zomato
sub: Open network: many front doors, shared supply
src: ONDC documentation; simplified
steps([("Buyer app", "Paytm, magicpin and others show menus to the customer", ""), ("ONDC gateway", "Finds sellers for the search and applies common rules", ""), ("Seller app", "magicpin connects the restaurant to the network", ""), ("Restaurant", "Lists once and is visible in every buyer app", "Lower commission than the duopoly"), ("Logistics partner", "Delivers the order; can be a different company", "Delivery quality varies")], hl=[1])
```

**Key features.** **magicNOW**, 15-minute food delivery from nearby restaurants, which grew to about 13% of orders in 2025 (Inc42). **Lower prices** on the same restaurants, because commissions are lower. **magicPoints** loyalty from its discovery days. A partnership with **Rapido's Ownly** food service to challenge the duopoly together.

**Business model.** Revenue tripled to **₹870 Cr in FY24** (Business Standard). It earns from commissions, delivery fees and brand deals. ONDC incentives, which once subsidised orders, have been reduced, and that tests how many customers stay without them.

**Moat and risk.** The main advantage is **counter-positioning**: Zomato and Swiggy cannot match low commissions without cutting their own profits. The risk is that customers return to the duopoly for better selection and faster delivery once discounts end.

**Metrics.** *North Star:* repeat orders per week. *Inputs:* restaurants live at peak, price gap with Zomato and Swiggy on the same dish, delivery time, magicNOW share. *Guardrail:* contribution per order without incentives.

::: key What I would build next at magicpin
1. **"Same dish, lower price" proof.** *Problem:* users do not believe magicpin is cheaper. *Bet:* show the price of the same dish on other apps at checkout. *Metric:* first-order conversion from price-comparison visitors.
2. **Restaurant-direct loyalty.** *Problem:* restaurants want to own their regular customers. *Bet:* let restaurants run their own loyalty on magicpin at no extra cost. *Metric:* restaurants live; orders per restaurant.
:::

## Comparing the three

| | Zomato | Swiggy | magicpin |
|---|---|---|---|
| Positioning | Best discovery, best food | Convenience across categories | Cheaper, open network |
| Scale (Q1 FY27) | ₹10,769 Cr NOV/quarter | ₹9,490 Cr GOV/quarter | Much smaller |
| Profit | 5.6% of NOV | ~3% of GOV | Depends on incentives |
| Membership | Gold | Swiggy One (cross-category) | magicPoints |
| Speed bet | Bistro (small) | Bolt | magicNOW |
| Moat | Density, data, brand | Density, cross-category fleet | Counter-positioning on commission |

```dia
title: Why the leader tends to stay the leader
sub: Higher order density lowers costs, which pays for the next customer
loop([("More orders per area", "Leader gets more orders in each neighbourhood"), ("More orders per rider-hour", "Batching and shorter trips"), ("Lower cost per order", "Rider cost is the biggest line"), ("Lower fees or better offers", "Or higher margins to reinvest"), ("More customers and restaurants", "Better value attracts both sides")], center="Density loop", center_desc="why #2 finds it hard to catch up")
```

## Likely interview questions

1. **"Orders on Swiggy dropped 8% week-on-week in one city. Diagnose."** Split the drop into users and orders per user. Check restaurant availability, delivery time, fees and app issues. Look for a local cause such as rain, a festival, or restaurants going offline.
2. **"Should Zomato raise the platform fee from ₹14.9 to ₹19.9?"** Estimate revenue gained against conversion lost. Test it in a few cities. Use the fee as a share of the bill as a guardrail.
3. **"Design a feature for restaurant partners."** Pick one segment (small restaurants), one problem (low visibility or menu losses), and one metric (restaurant GOV or churn).
4. **"Why did 10-minute food mostly fail?"** Speed needs dense supply, and new kitchens cost too much for low-value orders. Bolt works because it uses existing kitchens.
5. **"Improve delivery partner retention."** Focus on earnings per hour, predictable shifts, safety and insurance. Metric: 90-day active partners.
6. **"Estimate daily food delivery orders in India."** Monthly users × orders per month ÷ 30. Cross-check against the reported order value ÷ average order value.

::: quiz Recall: food delivery
1. Name the three sides of a food-delivery marketplace and what each one wants.
2. Which cost line decides food-delivery unit economics, and what lowers it?
3. Why did Snacc and Zomato Quick shut while Bolt survived?
4. Explain ONDC's buyer app / seller app / logistics split in two sentences.
5. What is counter-positioning? Use magicpin as the example.
6. Give Zomato a North Star, three inputs and two guardrails.
7. (Investing) What is the difference between monetising breadth and intensity?
:::
