%% chapter | Technology · RAG, tools and MCP | Giving the model a library card and a pair of hands | How AI products answer from your own, current data (RAG), how they take actions through tools, and why MCP became the common plug for connecting them

Ask a general-purpose chatbot, "How much checked baggage can I take on my Kochi–Dubai flight next week?" and it may give a confident, generic answer based on what airlines typically allowed when it was trained. Ask the airline's own assistant the same question and it first looks up the airline's *current* baggage policy for that route and your fare type, then answers: "30 kg on your Saver fare; see section 4.2 of the baggage policy", with a link. The model inside both could be identical. The difference is the system built around it.

That system is called **Retrieval-Augmented Generation (RAG)**. A common misconception is that RAG is a feature of the model. It is not. It is an **architecture around the model**: a retrieval step that finds relevant information and places it in the prompt, so the model generates its answer from that material rather than from memory.

```dia
title: RAG is an open-book exam
analogy([("A closed-book exam: answer from memory", "A plain LLM", "Knows a lot, but only up to its training cutoff, nothing private, and may guess confidently."), ("An open-book exam: find the page, then answer", "LLM + retrieval (RAG)", "Looks up the relevant passages first, then writes the answer from them."), ("Citing the page number in your answer", "Citations", "The user (and your eval) can check the claim against the source."), ("Saying 'the book doesn't cover this'", "Abstention", "If nothing relevant is found, say so instead of guessing.")])
```

## How RAG works

RAG has two phases: preparing the library ahead of time, and using it when a question arrives.

```dia
title: Phase 1, done in advance: building the searchable library
steps([("Collect", "Policies, help articles, product catalogue, past tickets, PDFs, database rows", "Stale documents = stale answers"), ("Chunk", "Split documents into passages of a few hundred words", "Bad splits break tables and lists"), ("Embed", "Turn each chunk into an embedding: numbers capturing its meaning", "Similar meaning, nearby numbers"), ("Store", "Save in a vector database, often alongside a keyword index; tag each chunk with who may see it", "Access control lives here")], hl=[0])
```

```dia
title: Phase 2, for every question: retrieve, then generate
seq(["User", "AI app", "Search (vector + keyword)", "LLM"], [("User", "AI app", "Can I carry 30 kg to Dubai on a Saver fare?"), ("AI app", "Search (vector + keyword)", "Find the most relevant chunks this user may see", "Semantic search matches 'luggage' to 'baggage'"), ("Search (vector + keyword)", "AI app", "Top 5 chunks, re-ranked by relevance"), ("AI app", "LLM", "Instructions + question + retrieved chunks: 'Answer only from these; cite; say if unsure'", "This is the 'augmented' prompt"), ("LLM", "AI app", "Answer with citations"), ("AI app", "User", "Answer + links to sources", "Guardrails check before sending")])
```

The knowledge sources can be almost anything: web search results (how chat assistants answer questions about last night's match), internal documents (an HR policy assistant), live databases (order status), knowledge graphs, or the user's own history (past purchases for personalised suggestions).

### What RAG fixes, and what it does not

RAG helps with the four biggest weaknesses of a plain model. It supplies **current** information without retraining the model. It supplies **private** information the model never saw, such as your policies and your customer's order. It **reduces hallucination** by giving the model the facts, and makes answers **checkable** through citations. And it can **respect permissions**: an employee assistant should only retrieve documents that employee is allowed to read. It is also far cheaper and faster to update than retraining a model: change the document and the next answer changes.

But RAG only moves the problem to retrieval. **If the search returns the wrong passage, the model will confidently answer from the wrong passage.** Common failure modes:

- **Retrieval misses:** the right chunk exists but is not in the top results (vocabulary mismatch, poor chunking, a table split in half).
- **Outdated or conflicting documents:** two versions of the refund policy in the index.
- **Ignoring the context:** the model answers from memory despite being told not to; or it misses facts buried in the middle of long context.
- **Prompt injection:** a retrieved web page or uploaded document contains hidden instructions ("ignore previous instructions and…"). Retrieved text must be treated as data, never as commands.

The fixes are engineering-and-product work: hybrid search (meaning plus keywords), re-ranking, cleaning and versioning the source documents, measuring **retrieval quality separately from answer quality** in evals, and designing the model to **abstain** when retrieval comes back empty.

| Approach | What it changes | Best for | Watch out |
|---|---|---|---|
| **RAG** | What the model *knows* for this answer | Facts that change or are private: policies, catalogues, orders, docs | Answer quality is capped by retrieval quality |
| **Fine-tuning** | How the model *behaves*: style, format, specialised skills | Consistent tone, a fixed output format, a narrow task done at scale | Poor way to add facts; must retrain to update |
| **Long context** | Paste everything into the prompt | Small, bounded material: one contract, one report | Cost and latency grow with every token; accuracy can drop over very long inputs |
| **Tools / APIs** | What the model can *look up or do* live | Real-time data (stock, balance) and actions (book, refund) | Needs permissions, error handling and approvals |

These are not rivals. A production assistant commonly uses a fine-tuned or well-prompted model, RAG for policies, and tools for live order data, all at once.

## Tool use: letting the model act

An LLM on its own can only produce text. It cannot check your order status, book a cab or send an email. **Tool use** (also called **function calling**) bridges this. The developer describes the available tools to the model (name, what it does, which inputs it needs). When the model decides a tool is needed, it replies not with prose but with a structured request. The *application*, not the model, actually runs the tool and hands the result back.

```dia
title: Tool use: the model asks, the application acts
seq(["User", "App", "LLM", "Order system (API)"], [("User", "App", "Where is my order? It's late."), ("App", "LLM", "Question + list of tools: get_order_status(order_id), start_refund(order_id)"), ("LLM", "App", "Call get_order_status(98812)", "A structured request, not an action"), ("App", "Order system (API)", "GET /orders/98812", "App checks the user owns this order"), ("Order system (API)", "App", "Out for delivery, ETA 8 min"), ("App", "LLM", "Tool result"), ("LLM", "App", "'Your order is 8 minutes away with Ravi.'"), ("App", "User", "Reply shown")])
```

That design keeps control where it belongs: the application decides which tools exist, checks permissions, and can require a human to approve risky calls.

## MCP: a common plug for AI tools

Tool use created a new problem. Every AI app (ChatGPT, Claude, Copilot, your own assistant) wanted to connect to every tool (Google Drive, Jira, Slack, Salesforce, GitHub, a company database), and each connection was custom-built. Ten apps and fifty tools meant up to five hundred separate integrations, each with its own format.

The **Model Context Protocol (MCP)** is an open standard that fixes this, the way USB-C replaced a drawer full of chargers. Anthropic introduced it in November 2024; it was adopted across the industry, and in December 2025 it was donated to the Linux Foundation's newly formed **Agentic AI Foundation**, making it vendor-neutral (Linux Foundation and MCP blog, Dec 2025). A tool maker builds **one MCP server**; any AI app that speaks MCP can use it.

```dia
title: Before and after MCP
versus("Before: custom integrations", [("Shape", "Every AI app writes its own connector for every tool: N apps × M tools."), ("Cost", "Duplicated effort; connectors break when either side changes."), ("Result", "Most tools were unavailable to most assistants.")], "After: one standard plug", [("Shape", "Each tool ships one MCP server; each app includes one MCP client: N + M pieces."), ("Cost", "Build once, works with any MCP-compatible app."), ("Result", "Assistants can read files, update tickets, query data across many systems.")], verdict="MCP does for AI tools what USB-C did for chargers: one shape of plug, many devices.")
```

```dia
title: MCP architecture
sub: The host app contains MCP clients; each client talks to one MCP server; each server wraps one system
arch({"h": ("Host AI app", "Claude, ChatGPT, an IDE, your own assistant; contains the LLM", "N"), "c": ("MCP client(s)", "Inside the host; speaks the protocol", "B"), "s1": ("MCP server: Google Drive", "Tools: search, read files", "T"), "s2": ("MCP server: Jira", "Tools: create, update tickets", "T"), "s3": ("MCP server: company DB", "Resources: tables; tools: run approved queries", "T"), "s4": ("MCP server: RAG search", "Tool: search the knowledge base", "G")}, [("h", "c", ""), ("c", "s1", "MCP"), ("c", "s2", "MCP"), ("c", "s3", "MCP"), ("c", "s4", "MCP")], rankdir="LR", wrapch=20)
```

The pieces: the **host** is the AI application the user works in; the **MCP client** inside it handles the conversation with servers; an **MCP server** wraps a system and translates requests ("add today's figures to the latest sales sheet") into that system's own API calls; the **protocol** defines how messages, tool descriptions and results look. Servers can offer **tools** (actions, such as create a ticket), **resources** (data to read, such as files or records) and **prompts** (reusable templates).

MCP is about access, so it raises security questions a PM must own: which servers are trusted, what each may do, whether writes need user approval, and how to stop a malicious document or server from tricking the model into misusing another tool.

| | RAG | MCP |
|---|---|---|
| Purpose | Improve what the model **knows** by supplying relevant information | Extend what the model can **reach and do** in other systems |
| How | Retrieve passages, add them to the prompt, generate | Standard client–server protocol exposing tools, resources and prompts |
| Typical use | Q&A over documents, enterprise search, support answers | Assistants and agents that read and update real systems |
| Relationship | Complementary: a RAG search can itself be exposed as an MCP tool, and an agent can retrieve with one tool and act with another | |

%% article | Technology · Agentic AI | Agents: from answering to doing | What makes an AI system an agent, how the agent loop works, when agents beat simple workflows, and where they go wrong

A chatbot, asked for a recipe with tomatoes, writes a recipe. An **agent** given the goal "keep my kitchen stocked and plan dinners" checks what is in the pantry, plans the week's meals, notices you are out of onions, adds them to your grocery list and, if you have allowed it, places an order on a quick-commerce app. The difference is not a smarter model. It is that the system **plans and takes actions over several steps, using tools, towards a goal**.

**Agentic AI** refers to systems in which a model decides which steps to take and which tools to use to reach a goal, observing the results and adjusting as it goes. Autonomy is a **dial, not a switch**: an agent may suggest every action for approval, act alone on low-risk steps, or run end to end within tight permissions.

```dia
title: Workflow, generative AI, agent
cards([("Rule-based workflow", "Fixed steps written in advance. 'When the inbox exceeds 10,000 emails, send an alert.' Reliable and cheap; cannot handle anything unforeseen."), ("Generative AI (single call)", "Responds to one prompt with one output. 'Write a recipe using tomatoes.' Reactive; a human drives each step."), ("AI agent", "Pursues a goal in a loop: plans, calls tools, checks results, adapts. 'Clean up my inbox: sort by relevance, summarise, draft replies.'")], ncol=3)
```

## The agent loop

```dia
title: How an agent works
loop([("Goal and context", "Task, permissions, relevant memory"), ("Reason and plan", "Model decides the next step"), ("Act", "Call a tool: search, API, code, browser"), ("Observe", "Read the result or error"), ("Check", "Done? Stuck? Needs a human? Otherwise loop")], center="Agent loop", center_desc="Repeats until the goal is met or a stop rule fires", edges=["", "tool call", "result", "decide"])
```

Take a returns agent at a fashion e-commerce company. Goal: "resolve this customer's return request". It reads the chat, calls `get_order` to see the items and dates, calls `get_return_policy` (a RAG search), sees the item is within 30 days, calls `schedule_pickup`, and then asks a human to approve a refund above ₹5,000 before calling `issue_refund`. Five tools, several decisions, one goal.

Agents are typically **specialised**: given a narrow goal and a limited set of tools and permissions. Complex products increasingly combine several (**multi-agent systems**): one agent plans, others search, write code or check the work. Note one correction to a common description: agents do not automatically "learn from experience" like a model being retrained. They improve only if the product is designed to give them memory, feedback and updated instructions, and if someone re-tests them.

## When should you use an agent?

Practitioners' advice, including Anthropic's widely cited guide *Building Effective Agents* (December 2024), is to **use the simplest thing that works**: a single well-prompted call, then a fixed workflow with a few model calls, and only then an agent. Agents earn their cost when the path cannot be scripted in advance.

```dia
title: Four questions before building an agent
cards([("Is the task open-ended?", "If the steps are predictable, a workflow is cheaper, faster and easier to test. Agents suit tasks where the path depends on what is found."), ("Is being wrong cheap or reversible?", "Filing a document in the wrong folder is easily fixed; a wrong medical dose or payment is not. High stakes: keep the AI advisory."), ("Can success be checked?", "Code that must pass tests or a form that must validate gives the agent feedback. No check means errors go unnoticed."), ("Are tools and permissions ready?", "The agent needs reliable APIs, least-privilege access, and approval steps for irreversible actions.")], ncol=2)
```

## What goes wrong

- **Errors compound.** If each step succeeds 95% of the time, a 10-step task succeeds only about 60% of the time (0.95¹⁰ ≈ 0.60). Reliability per step matters enormously; so do checkpoints.
- **Goal misalignment.** A vague goal like "maximise sales" could lead an agent to spam every customer with discounts. Goals need constraints, budgets and forbidden actions spelled out.
- **Latency and cost.** Each loop is one or more model calls; an agent can take minutes and many times the tokens of a single answer. Fine for a background research task, wrong for a checkout page.
- **Security.** An agent that reads the web or emails can be manipulated by injected instructions, and an agent with broad permissions can do broad damage. Least privilege, sandboxing, allow-lists and human approval for sensitive actions are the defences.
- **Accountability.** When an agent makes a mistake, who owns it? Logs of every step, clear escalation paths and a product decision on which actions need a human.

::: words Agent vocabulary
**Tool / function calling:** the model requests an action; the app executes it. **Orchestration:** the code that runs the loop, passes results and enforces limits. **Memory:** information kept across steps or sessions. **Guardrails:** rules that block or check inputs, outputs and actions. **Human-in-the-loop:** a person approves or corrects at chosen points. **Task success rate:** share of tasks completed correctly end to end, the headline agent metric, alongside cost per task, time per task and escalation rate.
:::

## Why agents matter for a PM

For the **product**, agents open up multi-step, cross-app tasks without constant user input: a travel app that re-plans your connection when a flight is delayed; a shopping app that tells your list app when a wishlisted item is back in stock; a support system that actually resolves a return instead of explaining the policy. For the **PM's own work**, agents already update tickets and documents across tools, prepare meeting briefs, draft PRDs and A/B-test ideas from research notes, and, through coding agents such as Claude Code, Codex and Cursor, build working prototypes from a description.

::: key The one-line rule
RAG gives the model knowledge; tools and MCP give it reach; an agent gives it a loop. Add each only when the simpler option fails, and put a human wherever an action is costly or irreversible.
:::

**In the interview.** Expect "What is RAG and why use it?" (open-book exam; current and private knowledge; citations; fails when retrieval fails), "RAG or fine-tuning for a support bot?" (RAG for policy facts, fine-tuning only for tone or format), "What is MCP?" (USB-C for AI tools, host–client–server, tools and resources), "Design an AI agent for X" (goal, tools, permissions, where humans approve, how to measure task success and cost, what happens when a tool fails). A strong line: *"I'd start with a workflow that handles the top three return reasons deterministically, and use an agent only for the long tail, with refunds above a threshold always going to a person."*

::: quiz Check yourself
1. Why is it wrong to call RAG a feature of the LLM? What is it instead?
2. Describe the two phases of RAG and name the step where access control is enforced.
3. Give two ways RAG can still produce a wrong answer, and one fix for each.
4. When would you choose fine-tuning over RAG? When long context?
5. In tool use, who actually executes the action: the model or the application? Why does that matter?
6. What problem does MCP solve? Name its three parts and three things a server can expose.
7. Why does a 10-step agent with 95% per-step accuracy fail about 40% of the time?
8. *(From the LLM chapter)* Why would you run a returns agent at low temperature?
:::
