%% chapter | Product dossier · Investing | Breadth versus intensity | Groww has twice as many active clients as Zerodha. Zerodha makes more than twice the profit. They are two different answers to the same question: who is your investing app really for?

Two phones, one Monday morning. In Indore, a 24-year-old opens Groww after a YouTube video on index funds. She starts a ₹500 monthly SIP, a systematic investment plan that auto-debits every month. It takes four minutes, including KYC. In Mumbai, a full-time trader has Zerodha's Kite open on two screens. He buys and sells Nifty options thirty times before lunch, and each order goes through in a fraction of a second.

Both are "investing apps". But the first user brings **breadth**: millions of small, sticky accounts. The second brings **intensity**: fewer users, each worth a lot of brokerage. Almost every product decision in this dossier follows from which of the two a company has chosen to serve.

## The job, and the market

The investor hires the app to **"grow my savings without being cheated or confused."** The trader hires it to **"execute my trade instantly, cheaply, and never go down when the market moves."** smallcase serves a third job: **"let me invest in an idea (like 'EV makers' or 'dividend stocks') without picking every stock myself."**

```dia
title: Who has India's active investors
sub: NSE active clients by broker, March 2026 (lakh)
src: NSE data via Business Today (Apr 2026). Total 4.57 crore, down 7.1% YoY after SEBI's F&O curbs
bars([("Groww", 129.4, "28.2% share; still adding clients"), ("Zerodha", 68.9, "Lost ~10 lakh in FY26"), ("Angel One", 67.6, "Lost ~8 lakh in FY26"), ("All others", 191.1, "Upstox, ICICI Direct, banks, etc.")], unit="L", fmt="{:,.1f}")
```

Two things happened in the market. First, in October 2024 **SEBI tightened futures and options (F&O) trading**. It raised contract sizes, allowed only one weekly expiry per exchange, and required option premiums to be collected upfront. It acted because its studies found that roughly **9 in 10 individual F&O traders lose money**. Brokers that earned most of their revenue from F&O were hit hardest. Second, retail enthusiasm cooled as markets fell after September 2024, so the number of active clients shrank for the first time in years.

```dia
title: Same industry, two economic engines
sub: FY25 profit per NSE active client (₹ thousand)
src: Company financials FY25; author calculation (FY25 profit ÷ NSE active clients)
bars([("Groww", 14.1, "1.3 Cr clients, many only hold SIPs"), ("Zerodha", 53.6, "Half the clients, each trading far more")], unit="k", fmt="{:,.1f}", hl=[1])
```

```dia
title: Breadth versus intensity
versus("Breadth (Groww)", [("Acquire", "Mutual funds first; 81% organic sign-ups"), ("Earn", "Small revenue from many users, across MF, stocks, F&O, loans"), ("Risk", "Low revenue per user; needs cross-selling")], "Intensity (Zerodha)", [("Acquire", "Traders, via word of mouth and Varsity education"), ("Earn", "₹20 per F&O order from very active users"), ("Risk", "Revenue swings with market mood and SEBI rules")], verdict="In an interview, first ask which user you are optimising for. The right metric, features and guardrails all depend on it.")
```

%% article | Investing · Groww | The first investing app for new India | Groww began with mutual funds for people who had never invested. It now wants to be their broker, lender and wealth manager.

**Who it is for.** First-time investors, often under 30 and increasingly outside the metros. Positioning: *"investing made simple."* Groww began in 2017 as a direct mutual-fund app, added stocks in 2020, then F&O, margin trading, loans, its own asset management company (AMC), and wealth services. It listed on the stock exchanges in November 2025.

**Core loop.** A YouTube video or a friend's referral → download → start a small SIP → the SIP debits every month → the user opens the app to check returns → sees stock prices and "most bought" lists → buys a first stock → trades more often. The SIP is the **anchor habit**. It makes the user open the app every month without any marketing spend.

**First run.** Mobile number → PAN → Aadhaar e-sign → selfie and signature → bank link. It takes minutes and is fully digital. The risky steps are KYC rejections (name mismatches between PAN and bank) and the empty state after sign-up. Groww fills that empty state with "Popular funds" and "Most bought on Groww" so a nervous beginner has somewhere to start.

```dia
title: Groww home (Stocks tab), annotated
sub: Built to calm a beginner and nudge a first action
phone([("Search · Profile", 0.5), ("Tabs: Stocks | Mutual Funds | F&O", 0.5), ("Index ticker: Nifty, Sensex", 0.6), ("Most bought on Groww", 1.3), ("Top gainers / losers", 1.1), ("Products and tools: IPO, ETFs, MTF", 0.9), ("Nav: Explore · Holdings · Orders", 0.6, "#F6D9D7")], [(1, "Products as tabs", "Mutual funds sit one tap from stocks, which makes cross-selling easy."), (3, "Social proof", "A beginner copies what others buy. Watch out: it can encourage herding."), (2, "Market pulse", "One line of context, not a trading terminal."), (5, "Tools as upsell", "IPOs and margin trading are revenue products, placed below the fold."), (6, "Holdings tab", "Checking returns is the monthly habit that brings users back.")])
```

| Feature | User problem | Design choice | Metric it moves |
|---|---|---|---|
| Direct mutual funds, zero commission | "Agents sell me funds with hidden commissions" | Direct plans only; clear expense ratios | First investment, trust |
| SIP with UPI Autopay | "I forget to invest every month" | Mandate set once, debited automatically | SIP persistence (months active) |
| "Most bought" lists | "I don't know where to start" | Social proof on the home screen | First stock purchase |
| Simplified F&O and option chain | "Options screens look like a cockpit" | Fewer numbers, clear profit/loss preview | F&O orders (with guardrails) |
| Margin Trading Facility (MTF) | "I want to buy more than my cash allows" | Pay ~20–25%, Groww funds the rest at interest | Interest income |
| Loans, UPI, wealth, own AMC | "I use five apps for money" | One trusted app for the whole wallet | Products per client |

**Business model.** In Q1 FY27 Groww's operating revenue was **₹1,501 Cr (+66% YoY)** and net profit **₹735 Cr (+94%)**, with **1.30 crore active clients** (Entrackr, Jul 2026). Revenue comes from brokerage (a flat fee per order), interest on the MTF book, AMC fees, and distribution. After SEBI's curbs, F&O fell from about 68% to 57% of revenue, and Groww has been deliberately diversifying since.

```dia
title: How to break down Groww's revenue in an interview
sub: Each term is something a PM can move
src: Structure only; values illustrative
formula([("Active clients", "Placed at least one trade or SIP", "1.3 Cr"), ("Orders per client", "Depends on the stocks vs F&O mix", "~ per month"), ("Revenue per order", "Flat fee, e.g. up to ₹20", "₹ / order"), ("Other income", "MTF interest + AMC fees + loans", "growing")], result="Revenue ≈ clients × orders × revenue per order + other income", ops=["×", "×", "+"])
```

**Growth loops and moat.** About 81% of Groww's users arrive organically, through content, referrals and app-store search. Each new investor tells friends, and each "most bought" list gives the next beginner confidence. The moat is **brand among first-time investors** plus low acquisition cost at scale. Against banks' high-fee broking accounts, Groww also has **counter-positioning**: it charges less and runs a simpler app, and banks cannot match it without cutting their own fee income.

**Metrics.** *North Star:* active investing clients (a trade or SIP in the last 30 days). *Inputs:* KYC-to-first-investment rate within 7 days, SIP persistence at 12 months, share of clients using two or more products, MTF book size. *Guardrails:* F&O losses per retail client, complaints per lakh clients, outage minutes on high-volume days.

**Strengths:** reach, low acquisition cost, product breadth, now profitable. **Weaknesses:** low revenue per user, tempting to push F&O, and a lot of regulatory exposure.

::: key What I would build next at Groww
1. **Loss-aware F&O mode.** *Problem:* most retail option buyers lose money and then leave angry. *Bet:* before each F&O order, show the user's own 90-day realised profit and loss, and offer a cooling-off period after a streak of losses. *Metric:* 12-month retention of F&O users; complaints (guardrail: F&O revenue per user falls only modestly).
2. **Goal-based family investing.** *Problem:* young investors want to invest for parents or children too. *Bet:* linked family accounts with shared goals ("Papa's retirement ₹25L"). *Metric:* SIPs per household; AUM per active client.
3. **Vernacular fund explainer.** *Problem:* fund documents are written in English jargon. *Bet:* an AI explainer in 10 languages ("What does this fund actually own?"). *Metric:* first-investment rate among non-English users.
:::

%% article | Investing · Zerodha | The broker that refuses to gamify | Zerodha built India's most profitable broker with almost no marketing, a spartan app and a habit of warning users not to trade.

**Who it is for.** Serious traders and long-term investors who value speed, reliability and honesty over hand-holding. Positioning: *"the discount broker with the best technology, and no tricks."* Zerodha charges **zero brokerage on equity delivery** (buy-and-hold) and a flat ₹20 on intraday and F&O orders.

**Core loop.** Learn on Varsity, Zerodha's free education site → open an account → trade on Kite → fast, reliable execution builds trust → trade more, recommend it to friends. Zerodha spends almost nothing on ads. Its growth came from traders recommending it to other traders.

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Kite (web and app) | "The app freezes when the market moves" | Minimalist and fast; built in-house | Order latency, uptime |
| Console | "Tax time is painful" | Tax P&L and reports in one place | Retention, support tickets |
| Coin | "I want direct funds with my stocks" | Direct MFs held in the same demat | AUM |
| Varsity | "I don't understand markets" | Free, deep, unbranded education | Quality of new sign-ups |
| Nudges and kill switch | "I overtrade when I'm emotional" | Warnings before risky orders; self-block a segment | Complaints, long-run retention |
| GTT orders and Kite Connect API | "I can't watch the screen all day" | Standing orders; paid API for algo builders | Orders per active trader |

**Business model.** FY26 revenue was flat at about **₹8,500 Cr**, and profit was **₹4,283 Cr** (Entrackr, Aug 2026), still the highest of any Indian broker. Its share of NSE active clients fell to about 15%, but customer assets reached about **₹9 lakh crore, the largest of any broker**. Nithin Kamath now says AUM, not active clients, is the number that matters: *"The money in the trading account can come and go, but AUM typically sticks around."* Margin trading now brings in about 10% of revenue.

**Moat.** Branding: a reputation for honesty that has held up for years. Process power: a lean, in-house technology team running at very low cost. Counter-positioning: it refuses ads and gamification, which rivals depending on F&O volume cannot easily copy. Switching costs: traders' habits and their API code are built around Kite.

**Metrics.** *North Star (as Zerodha now frames it):* customer assets (AUM). *Inputs:* new accounts, AUM per client, MTF book, Coin SIPs. *Guardrails:* uptime on high-volume days, the share of users who trade against a nudge, complaints.

**Strengths:** profit, trust, technology. **Weaknesses:** revenue is still tied to trading activity and SEBI rules. The minimalist app feels intimidating to beginners, which is the segment Groww won.

::: key What I would build next at Zerodha
1. **Portfolio health check.** *Problem:* long-term investors hold overlapping funds and forget to harvest tax losses. *Bet:* a yearly "health report" in Console with one-tap fixes. *Metric:* AUM retention; share of clients acting on suggestions.
2. **Family and HUF accounts under one login.** *Problem:* households manage 3–4 accounts separately. *Bet:* one family view, shared nominee and succession details, and consolidated tax reports. *Metric:* accounts per household; AUM per family. (Guardrail: no loss of privacy between family members who want separate views, such as an adult child who does not want parents to see their trades.)
:::

%% article | Investing · smallcase | Invest in ideas, not stocks | smallcase does not hold your money or your shares. It sells ideas, packaged as baskets, and delivers them through other people's brokers.

**Who it is for.** Investors who want a ready-made portfolio built around a theme or strategy ("Top 100 stocks", "Electric mobility", "Dividend aristocrats") but do not want a mutual fund's fees or lack of visibility. On the supply side, it serves SEBI-registered advisers and research analysts who want to reach investors.

**How it works.** A *manager* (an adviser or analyst) builds a basket of 5–30 stocks with weights. You buy it with one click, and the shares land in **your own demat account** at your own broker. When the manager rebalances, you get a notification and approve the changes. You see every stock you own, which a mutual fund does not show you day to day.

```dia
title: How smallcase sits between brokers and managers
sub: The platform never holds money; the broker executes, the manager supplies ideas
src: smallcase Gateway documentation; simplified
arch({"u": ("Investor", "Picks a basket; approves rebalances", "G"), "app": ("Broker or fintech app", "Zerodha, Upstox, Angel, banks, wealth apps", "B"), "gw": ("smallcase Gateway", "Free SDK: baskets, orders, rebalance flow", "R"), "sc": ("smallcase platform", "Discovery, analytics, subscriptions", "N"), "m": ("Managers", "SEBI RIAs and research analysts", "T")}, [("u", "app", "invests via"), ("app", "gw", "embeds"), ("gw", "sc", ""), ("m", "sc", "publish baskets"), ("sc", "u", "rebalance alerts", "d")], rankdir="TB", ranksep=0.25, wrapch=34)
```

**Business model.** FY25 revenue was **₹106 Cr (+57%)**, close to breakeven, with over 10 million users (company data). Revenue comes from a flat fee (about ₹100) on transactions in free baskets, a share of subscription fees on paid managers' baskets, and fees from partners using the platform. The smart part is **Gateway**, a free software kit that brokers embed in their own apps. Brokers get a ready-made investing product, and smallcase gets distribution without paying for customers. Once a broker has built its flows around Gateway, replacing it is painful. It is **a switching cost disguised as a feature**.

**Moat.** Network effects between managers and investors: more investors attract better managers, and better baskets attract more investors. Switching costs at partner brokers. A cornered resource: years of integration with the order systems of most Indian brokers.

**Metrics.** *North Star:* assets invested through smallcases. *Inputs:* new baskets bought, rebalance acceptance rate, active managers, partner integrations. *Guardrails:* churn after drawdowns, accuracy of performance disclosures, complaints about managers.

::: key What I would build next at smallcase
1. **Pre-approved rebalancing.** *Problem:* many users ignore rebalance alerts, so their portfolios drift from the strategy. *Bet:* let users pre-approve rebalances within limits they set (for example, no single trade over 10%). *Metric:* rebalance completion rate; tracking error against the model portfolio.
2. **Tax-aware rebalancing.** *Problem:* rebalancing can trigger short-term capital gains. *Bet:* show the tax cost of each change and offer a tax-efficient alternative. *Metric:* retention after the first rebalance.
:::

## Comparing the three

| | Groww | Zerodha | smallcase |
|---|---|---|---|
| Core user | First-time investor | Active trader, serious investor | Theme-seeking investor; advisers |
| Anchor habit | Monthly SIP | Daily trading | Rebalance approvals |
| Main revenue | Brokerage + MTF + AMC + loans | Brokerage (F&O) + MTF | Basket fees, subscriptions, partner fees |
| Moat | Brand with beginners, low CAC | Trust, low cost, technology | Two-sided network, Gateway switching costs |
| Main risk | Low value per user; F&O temptation | Revenue tied to trading, SEBI rules | Depends on brokers and market mood |

```dia
title: User sophistication versus revenue per user
sub: Where each player's core user sits (author's judgement)
matrix("User sophistication", "Revenue per user", [("Profitable beginners", "Rare: beginners who trade a lot usually lose"), ("Power users", "Traders and HNIs: Zerodha's home"), ("Mass investors", "Many small SIPs: Groww's base"), ("Idea investors", "Informed but low-frequency: smallcase")], points=[("Zerodha", 0.8, 0.62), ("Groww", 0.25, 0.22), ("smallcase", 0.62, 0.2)])
```

## Likely interview questions

1. **"Groww's F&O revenue falls 30% after a new SEBI rule. What do you do?"** Separate the short term (cost, reassure users) from the long term (MTF, AMC, wealth, loans). Name the trade-off: do not push risky trading to fill the gap.
2. **"Design a feature to stop retail investors from overtrading."** Zerodha's nudges and kill switch are the benchmark. Measure long-run retention and complaints, not orders.
3. **"What should Zerodha's North Star be?"** Weigh active clients against AUM against revenue. AUM matches long-term trust. Active clients can be gamed.
4. **"Should Groww show 'Most bought' lists?"** Social proof helps beginners but encourages herding. Suggest context, such as showing the risk level next to each name.
5. **"How would you grow smallcase's AUM 3x?"** Use distribution (more Gateway partners), supply (better managers) and conversion (pre-approved rebalances).
6. **"Estimate daily orders on Zerodha."** Active clients × share trading daily × orders per trader. Say your assumptions out loud.

::: quiz Recall: investing
1. What is the difference between monetising "breadth" and "intensity"? Give one example of each.
2. Why did SEBI tighten F&O rules in 2024, and which kind of broker did it hurt more?
3. Why is a monthly SIP a good "anchor habit" for an investing app?
4. Explain smallcase Gateway and why it creates switching costs.
5. Why does Nithin Kamath prefer AUM to active clients as a metric?
6. Name two guardrail metrics for an F&O feature.
7. (Payments) Why do UPI apps sell loans and insurance?
:::
