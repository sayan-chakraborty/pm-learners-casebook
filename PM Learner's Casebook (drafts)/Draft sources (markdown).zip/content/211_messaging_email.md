%% chapter | Product dossier · Messaging and email | The apps you open fifty times a day | WhatsApp is India's default way to talk, to sell and increasingly to buy. Telegram is its public, broadcast opposite. Messenger shows the cost of a wrong bundling decision. Gmail shows how an old product gets a new brain.

A kirana owner in Jaipur starts his morning on WhatsApp. There is a voice note from his supplier about the price of oil, a family group full of good-morning images, twelve customer orders typed in Hindi, a UPI payment confirmation, and a message from his bank about a loan offer. He has not opened any other app yet. Across the city, a college student has muted fourteen WhatsApp groups and is on Telegram, downloading last year's exam papers from a channel with 200,000 members.

## The job, and the market

People hire messaging apps for **"talk to the people who matter, instantly, for free, privately."** That job has a special property: the app is only useful if the other person has it too. That is a **direct network effect**, the strongest kind. Businesses now hire the same apps for **"reach my customers where they already are, and let them reply."** Email serves an older, more formal job: **"a permanent, searchable record for work, accounts and anything official."**

```dia
title: How many people use each
sub: Latest reported users, monthly (M)
src: Meta (WhatsApp, 2025); Google (Gmail, Jan 2026); Telegram (Mar 2025). Messenger's standalone figure is no longer disclosed
bars([("WhatsApp", 3000, "India is its largest market: 500M+ users"), ("Gmail", 3000, "Google: '3 billion users rely on Gmail'"), ("Telegram", 1000, "500M daily; India is its biggest download market")], unit="M")
```

```dia
title: Two philosophies of messaging
versus("WhatsApp: private by default", [("Encryption", "End-to-end for every chat; WhatsApp cannot read messages"), ("Scale of groups", "Groups up to ~1,000; Communities join groups"), ("Discovery", "You need a phone number; little public discovery"), ("Money", "Businesses pay per message; ads only in Updates tab")], "Telegram: public by design", [("Encryption", "Cloud chats by default; end-to-end only in 'secret chats'"), ("Scale of groups", "Channels with unlimited followers; groups of 200,000"), ("Discovery", "Usernames, public links, search"), ("Money", "Premium subscriptions, ads in channels, mini apps and crypto")], verdict="WhatsApp optimises for trust between people who know each other. Telegram optimises for reach to people who don't. Each design choice follows from that one decision.")
```

How messaging makes money is the recurring puzzle in this dossier. Users will not pay to chat, and ads inside private conversations feel like someone reading over your shoulder. So each product finds a side door: businesses pay to reach customers (WhatsApp), power users pay for more (Telegram Premium), or the chat feeds a bigger ads business (Messenger inside Facebook). Gmail, older and more formal, can show ads in one tab and sell storage and AI. Keep this in mind: in any messaging interview, a monetisation idea that puts ads inside private chats will be marked down.

%% article | Messaging · WhatsApp | India's operating system for conversation | WhatsApp began with a promise of "no ads, no games, no gimmicks." It now carries Meta's biggest new revenue line: businesses paying to talk to customers.

**Who it is for.** Almost everyone with a smartphone in India, the family, the shopkeeper and the office. Positioning: *"simple, reliable, private messaging."* The product has stayed deliberately plain. The Chats tab has barely changed in a decade, because the job has not changed.

**Core loop.** Receive a message → reply → the other person replies → the thread becomes a habit. Groups multiply the loop: one family group can generate hundreds of messages a day, each one a reason to open the app.

**First run.** Phone number → SMS code → your contacts who already use WhatsApp appear instantly. There is no empty state, because your phone book is the network. This is the reason WhatsApp won: **it borrowed a social graph everyone already had**.

```dia
title: WhatsApp, annotated
sub: The Chats tab stays clean; new business lives in the other tabs
phone([("Search · camera · menu", 0.5), ("Chats list: family, work, shop", 2.4, "#DCEFE0"), ("Business chat with 'Order' / Pay button", 0.7, "#F6E6B8"), ("Meta AI button (floating)", 0.4), ("Updates tab: Status · Channels · ads", 0.6, "#DDE8F0"), ("Nav: Chats · Updates · Communities · Calls", 0.5, "#F6D9D7")], [(0, "Search", "Finds messages, media and business chats."), (1, "Chats stay ad-free", "The core promise. Ads here would break trust."), (2, "Businesses in the same list", "Order, pay and get support in a chat. Meta charges the business per message."), (3, "Meta AI", "An assistant inside the app you already open most."), (4, "Ads live in Updates", "Status ads and promoted Channels, since 2025, away from private chats."), (5, "Communities and Calls", "Groups of groups for schools and societies; free calls.")])
```

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| End-to-end encryption | "Is anyone reading my chats?" | Only sender and receiver hold the keys | Trust, retention |
| Voice notes | "Typing in Hindi on a phone is slow" | Hold to talk; huge in India | Messages per user |
| Groups and Communities | "Our society needs one place for notices" | Groups nested under a Community with admin tools | Group activity |
| Status and Channels | "I want to share with everyone, or follow a creator" | Broadcast features, kept in a separate tab | Updates-tab DAU, ad revenue |
| Business app and platform | Businesses: "My customers are on WhatsApp" | Catalogue, labels, quick replies; paid platform for large firms | Paying businesses |
| Business AI agents | "I can't answer 500 chats a day" | AI that answers customers for the business | 1M+ businesses weekly (Meta) |
| UPI payments and bill pay | "Pay without leaving the chat" | Built on UPI | Payments share (under 1%) |

**Business model.** Consumers pay nothing. Money comes from three places. (1) **Business messaging**: since July 2025, businesses pay **per message** by category, and India has been billed in rupees since January 2026 (Meta's WhatsApp Business pricing pages). (2) **Click-to-WhatsApp ads** on Facebook and Instagram, which open a chat with a business. (3) Since 2025, **ads in the Updates tab** and paid Channel subscriptions. Meta's "other revenue", mostly WhatsApp business messaging, reached **$1 billion in Q2 2026, up 73%** (Meta).

```dia
title: How WhatsApp earns from businesses
sub: Business messaging revenue, India pricing (2026)
src: Meta WhatsApp Business pricing, INR billing from Jan 2026 (approximate rates)
formula([("Businesses messaging", "Banks, airlines, D2C brands, kiranas using the platform", "Growing"), ("Messages sent", "Per customer per month", "e.g. 4"), ("Price by type", "Marketing ~₹0.86; utility or login code ~₹0.115; replies to customers free", "₹ / message")], result="Revenue ≈ businesses × messages × price per message type", ops=["×", "×"])
```

```dia
title: A click-to-WhatsApp purchase
sub: How Meta connects its ads business to WhatsApp
steps([("Sees an Instagram ad", "A saree brand's Reel with 'Send message'", ""), ("Chat opens on WhatsApp", "No website, no login; the chat is the shop", "Meta earns from the ad"), ("AI agent answers", "Sizes, prices, delivery date, in Hindi", "Must hand off to a human when stuck"), ("Order and pay", "Catalogue + UPI payment link or in-chat pay", ""), ("Updates by message", "Order and delivery alerts", "Meta earns per utility message")])
```

**Moat.** Among the strongest in consumer technology: **direct network effects** (everyone you know is here), **switching costs** (years of chats, groups and media), and **habit**. The risks are misinformation spreading through forwards, which WhatsApp limits by capping forwards to five chats, regulators, and the temptation to monetise so hard that users stop trusting it.

**Metrics.** *North Star:* daily active users who send a message. *Inputs:* messages and calls per user, active groups, business conversations per week, Updates-tab reach. *Guardrails:* spam reports, blocks of businesses, forward-limit breaches, the share of users muting business chats.

**2025–26 moves.** Business AI agents went live at scale. Updates-tab ads and Channel subscriptions launched. Per-message pricing and INR billing arrived. In June 2026 **Kunal Shah**, the founder of CRED, was named head of WhatsApp, which signals a push into commerce and payments.

::: key What I would build next at WhatsApp
1. **Spam-proof business inbox for users.** *Problem:* marketing messages from businesses crowd out personal chats. *Bet:* a "Businesses" folder with one-tap unsubscribe and a monthly cap per brand. *Metric:* user blocks of businesses (down); utility-message read rate (guardrail: marketing revenue).
2. **Kirana order book.** *Problem:* shopkeepers take orders in chat and lose track. *Bet:* turn any customer message into an order card with items, total and a UPI request. *Metric:* weekly active small businesses; payments started from chat.
:::

%% article | Messaging · Messenger | A lesson in bundling and unbundling | In 2014 Facebook forced users to download Messenger as a separate app. Twelve years later, Meta is folding it back into Facebook.

**What happened.** Facebook launched chat in 2008, then in 2014 **removed messaging from the Facebook app**, forcing a separate Messenger download. The logic was that a dedicated app would be faster and would let messaging grow on its own, and at first it did. Later Meta planned to merge Messenger, Instagram DMs and WhatsApp behind the scenes. That plan faded, and Messenger was slowly **re-bundled**: the Windows and Mac apps shut in 2025, and **messenger.com closed in April 2026**, redirecting users to facebook.com/messages (Social Media Today).

```dia
title: Messenger's path
src: Meta announcements; press reports
timeline([("2011", "Messenger app launches", "Chat still also inside Facebook"), ("2014", "Forced unbundling", "Chat removed from Facebook app; users made to download Messenger"), ("2016", "Bots and payments", "Businesses and bots inside Messenger"), ("2020", "Cross-app chat with Instagram", "Step towards merging Meta's messaging"), ("2023", "Encryption by default", "End-to-end encryption rolls out"), ("2025–26", "Re-bundling", "Desktop apps and messenger.com shut; chat returns to Facebook")])
```

**The lesson.** Unbundling works when the new app has a daily job strong enough to stand alone. That was true in 2014, when Messenger's chats were very active. Re-bundling makes sense when the separate app's usage is shrinking and the parent app is where the users are. *North Star then:* people sending messages. *Guardrail now:* messages per Facebook DAU must not fall after the merge.

::: key What I would build next at Messenger
**Marketplace conversations first.** *Problem:* most active Messenger threads today are between buyers and sellers on Marketplace. *Bet:* make Messenger inside Facebook the best place to negotiate and close deals, with offers, pickup scheduling and scam warnings. *Metric:* Marketplace conversations that end in a sale.
:::

%% article | Messaging · Telegram | The public messenger | Telegram is part chat app, part broadcast network, part app store. It became profitable in 2024 with a tiny team and no venture capital.

**Who it is for.** People who want to follow large communities and channels: students, traders, news followers, crypto users. It also appeals to people who value large file sharing and cloud sync across devices. Positioning: *"fast, secure, powerful."* It has **over 1 billion monthly users and about 500 million daily**, and India was its **biggest download market in 2025** (Telegram; Business of Apps).

**Core loop.** Join a channel through a public link (exam notes, stock tips, a news source) → get daily posts → join the related discussion group → share links, which brings in more members.

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Channels (unlimited followers) | "I want to broadcast to lakhs of people" | One-way posts; public links; search | Channel subscribers, views |
| Supergroups (up to 200,000) | "Our community is too big for WhatsApp" | Admin tools, topics, slow mode | Group activity |
| Cloud chats and big files | "I switch devices; I share large PDFs and videos" | Messages stored on Telegram's servers; files up to 2 GB (4 GB with Premium) | Multi-device use |
| Bots and mini apps | Developers: "Let me build inside Telegram" | Open bot platform; mini apps with TON payments | Mini-app users |
| Telegram Premium | Power users: "More limits, more features" | Paid tier with bigger limits and extras | 15M subscribers (2025) |

**Business model.** Premium subscriptions (**15 million subscribers** by mid-2025), ads in large public channels, and crypto-related income from the TON blockchain ecosystem. Revenue was **$870 million in H1 2025 (+65%)**, and the company made its first annual profit, $547 million, in 2024 (Telegram, via SQ Magazine).

**Risks.** Weak moderation: piracy of films and courses in India and illegal content globally. Founder Pavel Durov was arrested in France in 2024. Telegram's default chats are not end-to-end encrypted, although many users assume they are.

::: key What I would build next at Telegram India
**Verified educator channels.** *Problem:* students can't tell genuine teachers from pirates and scammers. *Bet:* verified badges plus paid channel subscriptions paid through UPI, with revenue sharing. *Metric:* paid subscribers to verified channels; piracy reports (down).
:::

%% article | Email · Gmail | An old product with a new brain | Gmail is 22 years old and has 3 billion users. In 2026 Google rebuilt it around Gemini, and chose carefully which parts to give away free.

**Who it is for.** Anyone who needs an email address, which is everyone with an Android phone. It is also the home of every bank statement, OTP, ticket and job offer. Positioning: *"email that's organised for you."* For businesses, Gmail is part of **Google Workspace**.

**Core loop.** A notification arrives → open → read, act or archive → search when you need something from years ago. Gmail's historic innovations were **search instead of folders** and 1 GB of free storage when rivals offered 4 MB (2004), then the **Primary / Social / Promotions tabs** (2013), and **Smart Compose** (2018).

```dia
title: Gmail with Gemini, annotated (2026)
sub: AI sits at the top of long threads and inside the compose box
phone([("Search: 'When is my flight to Goa?'", 0.6, "#DCEFE0"), ("AI Overview: summary of this thread", 1.0, "#DDE8F0"), ("Email thread (8 messages)", 1.8), ("Suggested replies", 0.5), ("Help me write · Proofread", 0.5, "#F6E6B8"), ("Nav: Mail · Meet", 0.4, "#F6D9D7")], [(1, "Summaries, free", "Long threads get an AI summary on top. Metric: time to action."), (0, "Ask your inbox (paid)", "Natural-language questions answered from your mail, part of AI Pro and Ultra plans."), (3, "Suggested replies", "One-tap answers in your tone."), (4, "Write and proofread", "Help Me Write is free; advanced Proofread is paid.")])
```

**The 2026 product decision.** In January 2026 Google announced that **AI Overviews for thread summaries, Help Me Write and Suggested Replies are free for everyone**, while **asking questions of your whole inbox and advanced Proofread need a paid Google AI Pro or Ultra plan**. A new **AI Inbox** that ranks important mail was sent to trusted testers (Google blog, Jan 2026). This is a textbook **freemium boundary**: the free features make the product better for all 3 billion users, and the paid features serve power users who get the most value.

**Business model.** Ads in the Promotions tab, Google One storage upgrades (the free 15 GB is shared with Photos and Drive, which drives upgrades), paid AI plans, and Workspace subscriptions for businesses.

**Ecosystem power.** Because Gmail is so big, its rules shape the whole email industry. In 2024 Google required bulk senders to authenticate their mail and offer **one-click unsubscribe**. That was a product decision that improved every Gmail user's inbox and cut spam.

**Metrics.** *North Star:* daily active users who act on an email (reply, archive, click). *Inputs:* search success rate, AI summary usage, spam caught, AI-plan conversion. *Guardrails:* false-positive spam (real mail sent to spam), AI summary errors, privacy complaints.

::: key What I would build next at Gmail
**Life admin inbox for India.** *Problem:* bills, KYC requests, policy renewals and OTP-heavy mail are hard to track. *Bet:* auto-detect due dates and renewals and add them to a "To handle" list with reminders. *Metric:* weekly active users of the list; missed-payment reports (down).
:::

## Comparing the four

| | WhatsApp | Messenger | Telegram | Gmail |
|---|---|---|---|---|
| Core job | Private chat with people you know | Chat with Facebook friends and sellers | Public channels and big groups | Formal, permanent communication |
| Graph | Phone contacts | Facebook friends | Usernames, public links | Email addresses |
| Money | Business messaging, Updates-tab ads | Ads, business messaging | Premium, channel ads, crypto | Ads, storage, AI plans, Workspace |
| Moat | Network effect + habit | Facebook's network | Communities and channels | Ubiquity, search, Android |
| Risk | Over-monetising trust | Irrelevance | Moderation, legal | AI errors, privacy |

```dia
title: Private versus public, personal versus business
sub: Where each product's centre of gravity sits (author's judgement)
matrix("Public reach (broadcast)", "Business and formal use", [("Private, business", "Customer chats, email with your bank"), ("Public, business", "Brand channels, newsletters"), ("Private, personal", "Family and friends chats"), ("Public, personal", "Communities, fan channels")], points=[("Gmail", 0.3, 0.64), ("WhatsApp", 0.22, 0.24), ("Messenger", 0.35, 0.14), ("Telegram", 0.8, 0.22)])
```

## Likely interview questions

1. **"WhatsApp wants to launch in-app video. How would you measure success?"** (IIMA casebook) North Star: daily users watching and sharing. Guardrails: messages per user must not fall, and data usage complaints.
2. **"Should WhatsApp show ads in chats?"** No. Explain the trust cost. Monetise through business messaging and Updates-tab ads instead, which is what Meta chose.
3. **"Design a feature for WhatsApp groups in housing societies."** Communities with notices, polls, payments for maintenance fees, and admin controls. Measure active societies.
4. **"How would you monetise Telegram in India?"** Paid channels via UPI, creator revenue sharing, and verification. Guardrail: piracy.
5. **"Metrics for Gmail's AI summaries."** Adoption, time to action, and user-rated accuracy. Guardrail: errors on important mail (bills, offers).
6. **"Was unbundling Messenger in 2014 right?"** Yes for 2014's usage and speed. Re-bundling now fits a smaller, Marketplace-led use case.

::: quiz Recall: messaging and email
1. Why is a messaging app's network effect called "direct", and why is it so strong?
2. Contrast WhatsApp's and Telegram's choices on encryption, group size and discovery.
3. Write WhatsApp's business-messaging revenue formula.
4. What is a click-to-WhatsApp ad, and how does Meta earn twice from it?
5. What lesson does Messenger's unbundling and re-bundling teach?
6. Which Gmail AI features are free and which are paid, and why draw the line there?
7. (Payments) Why hasn't WhatsApp's distribution translated into UPI share?
:::
