%% chapter | Product dossier · Ride hailing | The marketplace that must work in the next four minutes | Uber leads cabs, Rapido leads bikes and is climbing fast, and Ola shows how a market leader can fall. The fight is now about who drivers work for, not only who riders choose.

Monday, 8:40 a.m., Silk Board junction, Bengaluru. A software engineer is late for a 9:30 meeting. A cab would take 55 minutes and cost ₹420. A bike taxi weaving through traffic would take 25 minutes and cost ₹110. She books the bike. Uber, Ola and Rapido spend most of their product effort on this four-minute window: how long a ride takes to arrive, whether the driver accepts, whether he cancels, and whether the price feels fair.

## The job, and the market

Riders hire ride hailing for **"get me there reliably, at a price I expected, and safely."** Drivers hire it for **"fill my day with paying rides and let me keep as much of the fare as possible."** Unlike food delivery there is no restaurant in between. That makes this a pure **two-sided marketplace**, and it makes the balance between the two sides unforgiving: if a rider waits too long they leave, and if a driver waits too long between rides they log off.

```dia
title: Who leads each type of ride
sub: Approximate share of rides by vehicle type in India, 2025 (%)
src: Industry estimates compiled by Equentis and press reports (2025); shares are approximate and vary by city
stack100([("Cabs", [("Uber", 50), ("Ola", 34), ("Rapido", 14), ("Others", 2)]), ("Autos", [("Uber", 40), ("Ola", 26), ("Rapido", 31), ("Others", 3)]), ("Bike taxis", [("Rapido", 56), ("Others", 44)])], note="Rapido leads bikes and is now the main challenger in autos and cabs; Uber's CEO has called it his biggest competitor in India.")
```

```dia
title: What happens in the first minute of a ride request
sub: Matching is the product; everything else is decoration
seq(["Rider app", "Pricing", "Dispatch", "Driver app"], [("Rider app", "Pricing", "Pickup, drop, vehicle type", "Upfront fare shown before booking"), ("Pricing", "Rider app", "₹ fare + ETA", "Surge if demand exceeds supply nearby"), ("Rider app", "Dispatch", "Confirm booking", ""), ("Dispatch", "Driver app", "Offer to best nearby driver", "Driver sees pickup; may reject"), ("Driver app", "Rider app", "Accepted: name, plate, PIN", "Cancellations spike here")])
```

```dia
title: The liquidity flywheel
sub: Uber's founding logic, which every ride app still runs on
loop([("More riders", "Demand in each area and hour"), ("More drivers join", "Because they earn more per hour"), ("Shorter pickup times", "A driver is always nearby"), ("Lower prices possible", "Drivers are busy, so each ride can cost less"), ("Better experience", "Fast, cheap, reliable")], center="Liquidity", center_desc="a ride within minutes, any time")
```

::: key The big shift of 2025–26: commission versus subscription
Traditionally the app kept **20–30% of each fare** as commission. Rapido charged drivers a **flat daily or monthly subscription** instead (₹5–29 a day or about ₹500 a month depending on city, per Inc42), and let them keep the whole fare. Uber adopted the model for autos in February 2025, and Ola rolled out "zero commission" nationwide in June 2025 (about ₹67 a day). The platform's revenue no longer rises with each ride. It rises with the number of drivers who pay the subscription.
:::

```dia
title: Commission versus subscription, for a driver doing 12 rides a day
sub: Why drivers moved; illustrative ₹300 average fare
src: Illustrative; subscription fee range from Inc42 (2025)
versus("Commission model", [("Platform keeps", "~25% of each ₹300 fare = ₹75 per ride, ₹900 a day"), ("Driver's view", "The more I drive, the more I pay"), ("Platform's view", "Revenue grows with every ride")], "Subscription model", [("Platform keeps", "A flat ~₹30–70 a day, whatever the rides"), ("Driver's view", "Predictable cost; busy days are mine"), ("Platform's view", "Cheaper fares win riders, but revenue no longer grows per ride")], verdict="Subscription wins drivers and lets fares fall 10–15%. It works as long as the platform earns from volume elsewhere: ads, financing, insurance, delivery.")
```

%% article | Ride hailing · Uber | The global benchmark, adapted for India | Uber is profitable worldwide and uses India to test products for the rest of the world: autos, bikes, buses and a subscription for drivers.

**Who it is for.** Riders who value reliability and safety over the lowest price, and business travellers. Positioning: *"go anywhere, get anything."* Globally Uber's quarterly **gross bookings reached $58.0 billion (+22%) in Q2 2026**, with **3.9 billion trips**, **208 million monthly active customers** and **$2.8 billion of adjusted EBITDA**. Trailing free cash flow passed $10 billion (Uber Q2 2026 release). India is one of its largest markets by trips.

**Core loop.** Open → "Where to?" → pick a vehicle type from a list with prices → a driver arrives in minutes → ride → rate → the saved places and payment method make the next booking three taps.

**First run.** Phone number, OTP, and optional payment set-up (cash is allowed in India, which removes a big barrier). The riskiest moment is the **first ride**: a long ETA or a driver cancellation sends the new user to a rival app.

```dia
title: Uber home screen, annotated
sub: One question on the screen: where to?
phone([("Where to?  (search box)", 0.7, "#DCEFE0"), ("Saved: Home · Work · recent", 0.8), ("Tiles: Auto · Moto · Go · Premier · Intercity", 1.0), ("Uber One / promo card", 0.8, "#F6E6B8"), ("Map with nearby cars", 1.6), ("Nav: Home · Services · Activity · Account", 0.5, "#F6D9D7")], [(0, "One question", "Destination first; everything else waits. Metric: time to booking."), (2, "Vehicle choice upfront", "India needs autos and bikes as first-class options. Metric: conversion by price point."), (1, "Saved places", "Most trips repeat; three taps to book."), (4, "Cars on the map", "Signals that supply is nearby, which reassures the rider."), (3, "Membership card", "Uber One raises frequency across rides and Eats.")])
```

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Upfront pricing | "Will the meter cheat me?" | Fixed fare shown before booking | Booking conversion, disputes |
| Ride PIN | "Is this the right car?" | Rider tells a 4-digit PIN to start the trip (India-first) | Safety incidents, wrong pickups |
| Share trip, SOS, RideCheck | "I don't feel safe at night" | Live location to family; alerts on unusual stops | Night-time rides, safety NPS |
| Auto, Moto, Shuttle, Intercity | "A cab is too expensive for this trip" | A mode for every budget and distance | Trips per user |
| Zero-commission autos (2025) | Drivers: "Commission eats my earnings" | Daily subscription | Active auto drivers, ETA |
| Uber One and Uber for Business | "I ride often and want perks"; companies need travel billing | Membership; central billing | Frequency; B2B trips |

**Business model.** Globally Uber earns a take rate on gross bookings, plus advertising, membership and delivery. In India it now combines commission (cabs) with subscription (autos). Its economics depend on **utilisation**: the share of a driver's logged-in time spent carrying a paying rider.

**Moat.** Network effects that are *local*, city by city. Global scale economies in mapping, pricing and safety technology. Brand trust. The weakness is that drivers and riders use several apps at once, and in India a cheaper rival can win a city fast.

**Metrics.** *North Star:* completed trips. *Inputs:* ETA at pickup, request-to-completion rate, active drivers at peak, driver utilisation. *Guardrails:* rider and driver cancellation rates, safety incidents per million trips, driver earnings per hour, surge frequency.

::: key What I would build next at Uber India
1. **Commute passes.** *Problem:* office-goers pay surge prices at 9 a.m. every day. *Bet:* a weekly pass for a fixed route and time, priced below average surge, with guaranteed pickup. *Metric:* weekday trips per pass holder; driver utilisation at peak.
2. **Cancellation-proof matching.** *Problem:* drivers accept and then cancel when they see the drop location or the payment mode. *Bet:* show drop area and payment mode before acceptance, and reward high-completion drivers with priority. *Metric:* driver cancellation rate; ETA.
:::

%% article | Ride hailing · Ola | How a market leader lost its lead | Ola once had more of India's cab market than Uber. By 2026 its revenue had nearly halved and investors had written its value down to a fraction of its peak.

**Who it was for.** Indian riders in every tier of city. Ola launched in 2010 and was India's answer to Uber, with autos, bikes and local payment options early.

**What happened.** Revenue for Ola's ride-hailing business fell **42% to ₹1,171 Cr in FY25**, with a loss of ₹662 Cr (company filings reported in the press). One investor marked the company down to a small fraction of its once-$7 billion-plus valuation, and a loan of about $65 million falls due in December 2026. The causes are worth learning as a pattern:

- **Divided attention.** Leadership time and money went to Ola Electric (scooters, listed separately), Krutrim (AI), and other ventures.
- **Driver trust.** Complaints about payouts and incentives pushed drivers towards rivals. In a two-sided market, losing drivers means losing riders a few weeks later.
- **Service quality.** High cancellation rates and customer-support complaints hurt its reputation with riders.
- **A late response to Rapido.** Ola moved to zero commission in June 2025, after Rapido had already won the loyalty of drivers.

**What it built well.** **Ola Maps**, an in-house mapping stack that replaced Google Maps in 2024 to cut costs, and early work on electric fleets.

::: key What I would build next at Ola (a turnaround plan)
1. **Win back drivers first.** *Problem:* supply is the constraint. *Bet:* guaranteed minimum hourly earnings in five core cities for 90 days, funded by closing weak cities. *Metric:* active drivers at peak; ETA.
2. **Fix the first ride.** *Problem:* returning users had bad experiences. *Bet:* a "no cancellation" guarantee with automatic credit when a driver cancels. *Metric:* 30-day retention of reactivated riders.
:::

%% article | Ride hailing · Rapido | The bike taxi that rewrote the rules | Rapido started with the cheapest possible ride, a seat on the back of a motorbike, then changed how drivers are paid. It is now the challenger everyone copies.

**Who it is for.** Price-sensitive commuters, students and workers in traffic-heavy cities and tier-2 towns. Positioning: *"the fastest, cheapest way through traffic."* Rapido operates in **400+ cities** and raised **$240 million at a $3 billion valuation** in 2026, led by Prosus (Yahoo Finance, 2026).

**Core loop.** A cheap bike ride → saves time in traffic → becomes a daily commute habit → the same user tries Rapido autos and cabs → cheaper fares, because drivers pay no commission, keep users loyal.

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Bike taxi | "Traffic makes cabs slow and expensive" | Two-wheelers are fast and cost a fraction of a cab | Trips per user |
| Driver subscription (no commission) | Drivers: "I lose a quarter of every fare" | Flat daily/monthly fee | Driver supply, fares 10–15% lower |
| Autos and cabs on the same app | "I need a bigger vehicle sometimes" | Cross-sell to existing riders | Share of non-bike trips |
| Ownly (food delivery, 2025) | Restaurants: "Commissions are too high" | Uses Rapido's fleet; lower commission | Orders, rider utilisation |
| Parcel delivery | "I need to send keys across town" | Same bikes, same app | Off-peak utilisation |

**Business model.** Subscription fees from drivers, rather than commission, plus delivery and parcel services. The subscription makes Rapido cheaper for riders, which is **counter-positioning**: Uber and Ola would have to give up their commission income to match it. They partly did.

**Risk.** Bike taxis are illegal in some states or face bans. Karnataka's mid-2025 ban was a serious blow in Rapido's home market. Revenue that does not rise with rides has to be made up elsewhere. Food delivery puts Rapido up against Zomato and Swiggy.

**Metrics.** *North Star:* completed trips per week. *Inputs:* subscribed active drivers, ETA, share of trips outside bikes, trips per rider. *Guardrails:* safety incidents, regulatory status by state, driver churn.

::: key What I would build next at Rapido
1. **Women-safe bike rides.** *Problem:* many women avoid bike taxis for safety. *Bet:* opt-in women drivers, live trip sharing, helmet hygiene kits. *Metric:* share of women riders; safety incidents.
2. **Driver financing.** *Problem:* many drivers want to own an EV bike but lack credit. *Bet:* partner loans repaid through the daily subscription. *Metric:* drivers financed; driver retention at 12 months.
:::

## Comparing the three

| | Uber | Ola | Rapido |
|---|---|---|---|
| Positioning | Reliable, safe, global | Indian, all vehicle types | Cheapest, fastest in traffic |
| Driver model | Commission (cabs) + subscription (autos) | Zero commission (subscription) | Subscription |
| Strength | Brand, technology, profits globally | Maps, EV experience | Bikes, low fares, driver loyalty |
| Weakness | Higher prices | Lost trust, weak finances | Regulation, thin revenue per ride |
| Next frontier | Autonomy (globally), commute products | Survival | Food, parcels, cabs |

```dia
title: Price versus reliability
sub: How riders perceive each app in 2026 (author's judgement)
matrix("Price to rider (low → high)", "Perceived reliability", [("Cheap and dependable", "Where Rapido wants to be"), ("Premium and dependable", "Uber's position"), ("Cheap but risky", "Budget apps, bike taxis in some cities"), ("Costly and unreliable", "The losing corner")], xends=("Low", "High"), points=[("Uber", 0.78, 0.62), ("Rapido", 0.2, 0.56), ("Ola", 0.55, 0.22)])
```

## Likely interview questions

1. **"Uber ride cancellations spiked 20% this week. Diagnose."** (IIMA casebook) Split by who cancelled (rider or driver), city, vehicle type, and payment mode. Check any change in dispatch or pricing. A new fare rule often makes drivers cancel long trips.
2. **"Should Uber move cabs to the subscription model?"** Model driver supply and fare elasticity against lost commission income. Pilot it in one city. Guardrail: ETA and driver earnings.
3. **"Design Ola for school children."** (IIMA) The parent is the customer and the child the user. Think verified drivers, fixed routes, live tracking, and pickup PINs.
4. **"What metric would you use for a ride-hailing marketplace?"** Completed trips, balanced by ETA (rider side) and utilisation (driver side), with cancellation and safety as guardrails.
5. **"How would you launch Rapido in a new tier-2 city?"** Recruit drivers before riders, focus on a few busy corridors to build density, and offer a launch fare.
6. **"Why did Ola lose share?"** Talk about leadership focus, driver trust, service quality and a late response to the rival's pricing model.

::: quiz Recall: ride hailing
1. Why is liquidity the core product of a ride-hailing app? Draw the flywheel from memory.
2. Explain commission versus subscription from a driver's and a platform's point of view.
3. What is counter-positioning, and how did Rapido use it?
4. Name four India-specific features in Uber's app and the problem each one solves.
5. Give three reasons Ola lost its lead.
6. Pick a North Star, two input metrics and two guardrails for a ride-hailing app.
7. (Quick commerce) How is a new dark store's losing phase similar to launching ride hailing in a new city?
:::
