%% chapter | Product dossier · Gaming | Free to play, paid by a few | Zynga went from FarmVille on Facebook to one of the world's biggest mobile-game publishers. Its story is also the clearest lesson in free-to-play economics: most players never pay, and the business works anyway.

A 38-year-old accountant in Chennai plays Toon Blast on the train home. She has played for two years. She has never spent a rupee, but she watches an ad now and then for an extra five moves. Three seats away, a college student has spent ₹2,400 this month on boosters to beat a hard level before his friends. The game is identical for both of them. Its business depends on keeping the accountant happy and playing, because she makes the game feel alive and fills its ad slots, while the student pays most of the bills.

## The job, and how free-to-play works

Casual players hire mobile games for **"a few minutes of satisfying progress when I'm bored or stressed."** Competitive players hire them for **"mastery and beating other people."** A **free-to-play (F2P)** game is free to download and earns from **in-app purchases** (boosters, lives, currency, passes) and **ads** (mostly "rewarded" ads that players choose to watch for a bonus).

```dia
title: The core loop of a casual puzzle game
sub: Toon Blast, Match Factory and Candy Crush all run a version of this
loop([("Play a level", "2–3 minutes; clear goals, limited moves"), ("Win, or nearly win", "Near-misses feel fair and make you retry"), ("Reward and progress", "Stars, coins, a step forward on the map"), ("Meta and social", "Teams, events, leaderboards, decorating"), ("Come back", "Lives refill, daily rewards, new event")], center="Session loop", center_desc="short, repeatable, several times a day")
```

```dia
title: Who pays in a free-to-play game
sub: A typical value pyramid; shares illustrative
src: Illustrative; industry rule of thumb that roughly 2–5% of players ever pay in casual mobile games
pyramid([("'Whales' (well under 1% of players)", "Spend heavily; often a large share of in-app revenue. Must be served ethically, not exploited."), ("Regular payers (1–4%)", "Buy passes and small bundles; respond to events and offers"), ("Ad watchers (many)", "Never pay, but watch rewarded ads for extra moves or lives"), ("Non-paying players (most)", "Make the game feel alive: teams, leaderboards, word of mouth")])
```

The whole business rests on one inequality: **a player's lifetime value (LTV) must exceed the cost of acquiring them (CPI, cost per install)**.

```dia
title: The one formula a games PM must know
sub: Does acquiring a new player pay back?
src: Structure standard in mobile gaming; example values illustrative
formula([("ARPDAU", "Average revenue per daily active user (IAP + ads)", "$0.12"), ("Days active per install", "Sum of retention: D1 × D2 × ... over the player's life", "40 days"), ("Cost per install (CPI)", "Paid marketing cost to get one install", "$3.00")], result="LTV ≈ ARPDAU × days active = $4.80  >  CPI $3.00, so buying players pays back", ops=["×", "vs"])
```

```dia
title: Where players drop off
sub: A typical casual game's retention, illustrative
src: Illustrative benchmarks commonly used for casual mobile games
funnel([("Install", "100", 1.0, ""), ("Day 1 return", "40", 0.4, "First session must be fun in the first 60 seconds"), ("Day 7 return", "18", 0.18, "Needs a reason to return: events, teams"), ("Day 30 return", "8", 0.08, "Long-term players form the paying base"), ("Ever pays", "3", 0.03, "Payers come mostly from long-term players")], hl=[1])
```

## Zynga: from Facebook virality to mobile portfolio

**Who it is for.** Casual and mid-core mobile players worldwide: puzzle fans (Toon Blast, Match Factory, Color Block Jam), word-game players (Words With Friends), football-management fans (Top Eleven), racers (CSR Racing). Positioning: *"connecting the world through games."* It is a **portfolio**: many games, each tuned to a different audience.

```dia
title: Zynga's arc
src: Company history; Take-Two filings; Mobilegamer.biz (2026)
timeline([("2009", "FarmVille on Facebook", "Tens of millions of daily players; viral gifting via friends' feeds"), ("2011", "IPO", "At the peak of Facebook gaming"), ("2012–13", "Decline", "Facebook limits game notifications; players move to mobile"), ("2014–21", "Buy mobile studios", "NaturalMotion (CSR), Small Giant (Empires & Puzzles), Peak (Toon Blast), Rollic"), ("2022", "Take-Two acquires Zynga", "$12.7B deal; Zynga becomes T2's mobile arm"), ("FY26", "Best quarter ever", "Mobile is 49% of Take-Two's $6.7B net bookings")])
```

**Lesson 1: borrowed distribution is rented, not owned.** FarmVille grew on Facebook's **viral channels**: requests to friends ("send me a cow"), feed posts and notifications. When Facebook cut those channels to protect its users' feeds, Zynga's growth collapsed. The same risk applies today to anyone who depends on one platform's algorithm.

**Lesson 2: buy what you cannot build.** Zynga missed mobile at first, then acquired studios with proven hits. Hit rates in mobile games are low, so buying successful games often costs less than building many that fail.

```dia
title: Toon Blast level screen, annotated
sub: Every element is tuned for retention and gentle monetisation
phone([("Moves left: 5 · Goal: 30 balloons", 0.6, "#F6E6B8"), ("Game board (tap cubes to blast)", 2.6, "#DDE8F0"), ("Boosters: hammer, shuffle", 0.5), ("Out of moves? +5 moves (ad or coins)", 0.6, "#F6D9D7"), ("Team chest · event progress", 0.5, "#DCEFE0")], [(0, "Clear goal, few moves", "Tension that resolves in 2–3 minutes. Metric: level completion rate."), (1, "The board", "Easy to learn, hard to master. The first levels are designed to be won."), (2, "Boosters", "Earned in play or bought; a way to buy progress, not to win outright."), (3, "The 'near-miss' offer", "The moment of highest willingness to pay. Guardrail: difficulty spikes that feel unfair."), (4, "Team and events", "Social commitment brings players back daily. Metric: D30 retention.")])
```

| Feature | Player problem | Why designed this way | Metric |
|---|---|---|---|
| Lives that refill over time | Game: "Stop players burning out in one sitting" | Limits play; creates a reason to return later | Sessions per day |
| Rewarded ads | "I'm stuck but won't pay" | Watch an ad for extra moves | Ad ARPDAU, retention of non-payers |
| Teams and team chests | "Playing alone gets boring" | Shared goals and help requests | D30 retention |
| Live events (weekly) | "It feels the same every day" | Limited-time goals and rewards | DAU, spend during events |
| Season / battle pass | "I want steady rewards for playing" | Pay once; earn rewards by playing | Payer conversion, ARPPU |
| Direct-to-consumer web store | Studio: "App stores take up to 30%" | Sell currency on the web after rules on app-store payments eased | Margin per purchase |

**Business model and 2026 results.** In fiscal 2026 (to March 2026), Take-Two reported **record net bookings of $6.7 billion**, with **mobile, mostly Zynga, at $3.3 billion or 49%**. Toon Blast grew over 25%, Color Block Jam 15% and Empires & Puzzles 5%, while 16-year-old Top Eleven had its best quarter ever. Zynga credited **direct-to-consumer web stores** for rising margins and **generative AI** for cutting the cost of making ad creatives (Mobilegamer.biz). CSR 3 and Top Goal are in soft launch, meaning a limited release in a few countries to test retention and monetisation before a global launch.

```dia
title: Where a $10 in-game purchase goes
sub: App store versus the studio's own web store; illustrative
src: Illustrative; standard app-store commission up to 30%; web payment costs typically a few per cent
versus("Bought inside the app", [("Store fee", "Up to $3.00 to Apple or Google"), ("Studio receives", "About $7.00"), ("Pros", "One tap; the easiest purchase")], "Bought on the studio's web store", [("Payment fee", "About $0.30–0.50"), ("Studio receives", "About $9.50"), ("Pros", "Higher margin; direct player relationship; bonus to reward the extra step")], verdict="Moving even a fifth of spending to the web adds several points of margin. That is why every big studio now builds web stores.")
```

**Moat.** **Process power** in live operations (events, offers and difficulty tuning refined over years), a **portfolio** that spreads hit risk, and **scale in user acquisition** (data on which ads bring profitable players). Games themselves have weak moats: players move to the next hit.

**Metrics.** *North Star:* DAU of retained players (D30+). *Inputs:* D1/D7/D30 retention, sessions per day, payer conversion, ARPDAU, ad ARPDAU. *Guardrails:* LTV/CPI above 1, complaints about unfair difficulty or spending, and spending by minors.

## The India angle

India is the world's largest market for game downloads but one of the lowest-spending per player. In August 2025 Parliament passed the **Promotion and Regulation of Online Gaming Act**, which **banned real-money games** (fantasy sports, rummy, poker played for money) and their advertising and payments, while promoting e-sports and casual games (Law.asia). Dream11, MPL and others had to shut their money games, cut staff and end cricket sponsorships. For PM candidates, the product lesson is **regulatory risk**: an entire category's business model can disappear overnight.

::: key What I would build next at Zynga
1. **India-priced passes and ad-first economy.** *Problem:* Indian players rarely pay dollar-level prices. *Bet:* ₹49 weekly passes via UPI on the web store and more rewarded-ad options. *Metric:* India ARPDAU; payer conversion in India.
2. **AI-generated levels tuned per player.** *Problem:* a single difficulty curve makes some players quit and others bored. *Bet:* generate and choose levels to keep each player's win rate in a target band. *Metric:* D30 retention (guardrail: complaints of manipulation, spending by vulnerable players).
:::

## Likely interview questions

1. **"DAU is flat but revenue fell 15%. Diagnose."** Split revenue into IAP and ads, then into payers, conversion and ARPPU. Check for an event ending, price changes, or an app-store policy change.
2. **"Design a new feature for a puzzle game to improve D7 retention."** Teams, daily streaks, a narrative meta. Measure D7 against a holdout group.
3. **"Is it ethical to design near-miss moments?"** Name the trade-off. Suggest guardrails: spending limits, no pay-to-win for minors, transparent odds.
4. **"Should a studio launch globally or soft-launch first?"** Soft launch, to prove retention and LTV/CPI before spending on marketing.
5. **"How would you measure the success of a web store?"** Share of revenue through the web store, margin per purchase, and payer retention. Guardrail: total revenue must not fall because of the extra friction.

::: quiz Recall: gaming
1. Draw the core loop of a casual puzzle game.
2. What must be true of LTV and CPI for paid user acquisition to make sense?
3. Why can a game in which only 3% of players pay still be profitable?
4. What did Zynga learn when Facebook cut game notifications?
5. Why are direct-to-consumer web stores lifting game margins?
6. What did India's 2025 online gaming law ban, and what does it teach about regulatory risk?
7. (Social) How is a Reels feed's retention loop similar to a puzzle game's?
:::
