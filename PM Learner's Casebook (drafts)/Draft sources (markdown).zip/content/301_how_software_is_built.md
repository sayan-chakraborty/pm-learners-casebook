%% chapter | Technology · How software is built | From idea to app store | The life cycle every feature goes through, why most teams moved from Waterfall to Agile, and how Scrum and Kanban actually run week to week

Think about how a house gets built. Someone decides what the family needs (three bedrooms, a ramp for grandmother). An architect draws plans. Masons build. An inspector checks the wiring. The family moves in, and for twenty years someone fixes leaks. Nobody pours the foundation before the plan is agreed, because changing a foundation later is ruinously expensive.

Software goes through the same stages. The difference is that software is far easier to change after it is "built", and that single fact explains most of the arguments about how teams should work.

## The Software Development Life Cycle (SDLC)

The **SDLC** is the sequence of stages every piece of software passes through, from "someone has an idea" to "it is running and being looked after". Take a new one-tap checkout for an e-commerce app.

```dia
title: The seven stages of the SDLC, using a new checkout flow
sub: Every feature passes through these stages; methods differ only in how often and in what size
vsteps([("Requirements", "Decide what the checkout must do: saved UPI handle, one tap, works on 3G, handles failed payments.", "PM owns this. Vague requirements are the top cause of rework."), ("Analysis", "Check feasibility, dependencies and risks: does the payment partner support saved mandates? What about fraud?", "Engineering and PM together; find the blockers now."), ("Design", "UX designs the screens; engineers design the system: which services, what data, which APIs.", "Cheapest place to change your mind."), ("Development", "Engineers write and review the code, usually in small pieces merged daily.", "PM answers questions fast so nobody guesses."), ("Testing", "QA and automated tests check it works: happy path, failures, old phones, slow networks.", "Defects found here cost more than defects found in design."), ("Deployment", "Release to users, often gradually: 1% first, then 10%, then everyone.", "Watch the metrics; have a rollback plan."), ("Maintenance", "Fix bugs, update for new OS versions, improve based on data.", "Most of a product's lifetime cost lives here.")], hl=[0])
```

::: words Words to know
**Requirement / spec / PRD:** the written description of what to build and why. **QA:** quality assurance, the testing function. **Deployment / release:** putting new code in front of users. **Rework:** redoing work because something was misunderstood or changed. **Technical debt:** shortcuts taken to ship faster that make later changes slower, like skipping a proper foundation to finish sooner.
:::

**Why a PM cares.** Knowing the stages tells you when each decision must be made and who must be in the room. Lock the "what" before engineers start writing code, involve legal before design if payments or personal data are involved, and bring customer support in before launch, not after. The later a mistake is found, the more it costs to fix.

```dia
title: The later you find a mistake, the more it costs
sub: Relative cost of fixing the same defect, by the stage where it is found (illustrative)
src: Illustrative; the pattern is widely reported in software engineering studies, exact multiples vary
cols([("Requirements", 1), ("Design", 3), ("Development", 7), ("Testing", 15), ("After release", 60)], notes=[(4, "Users hit it, support calls, hotfix, lost trust")])
```

## Waterfall: finish each stage before starting the next

**Waterfall** runs the SDLC once, in strict order. Requirements are fully written and signed off, then the whole design is done, then all the code, then all the testing, then one big release. Water only flows downhill; going back up is hard.

```dia
title: Waterfall: one pass, in strict sequence
steps([("Requirements", "Everything written and signed off up front", ""), ("Design", "Full design of every screen and system", ""), ("Build", "All features coded", ""), ("Test", "Testing starts only now", "Defects surface late"), ("Release & maintain", "One big launch", "Users see it for the first time")], hl=[3])
```

Waterfall is not stupid. It fits work where requirements truly are fixed and mistakes after release are catastrophic or impossible to patch: a satellite, the software in a pacemaker, a bank's migration to a new core system with a regulatory deadline, a fixed-price government contract. ISRO cannot push a hotfix to a lander that is already on the Moon.

Its weaknesses show up whenever the world moves during the project:

- **Low adaptability.** A problem found in testing may send you back to design, and everything after it has to be redone.
- **Late delivery.** Users see nothing until the end, so competitors can ship first and you learn nothing from real users for months.
- **Risk piled up at the end.** Because testing comes last, the project looks fine until suddenly it does not.

## Agile: build a little, show it, learn, repeat

**Agile** runs the whole SDLC in small loops, usually one to four weeks long, and ships working software at the end of each loop. Instead of one giant bet, you place many small ones and adjust after each.

The idea was written down in the *Agile Manifesto* (2001) by seventeen software developers. It values:

- **Individuals and interactions** over processes and tools
- **Working software** over comprehensive documentation
- **Customer collaboration** over contract negotiation
- **Responding to change** over following a plan

The items on the right still matter; the items on the left matter more. The principles that follow from this: deliver valuable software early and continuously; welcome changing requirements, even late; release frequently (every few weeks, often daily in practice today); keep technical quality high because messy code slows every later change; maximise the work *not* done; and reflect regularly on how to improve.

A useful picture: Waterfall builds a car wheel by wheel and hands you the car at the end. Agile hands you a skateboard, then a scooter, then a bicycle, then a car. Each version is usable, and you learn from how people use it. (This image comes from designer Henrik Kniberg.)

```dia
title: Waterfall versus Agile, delivering "get me across town"
versus("Waterfall", [("Month 1", "A wheel. Useless alone."), ("Month 3", "A chassis. Still useless."), ("Month 6", "A car, finally. If the user wanted a scooter, too late.")], "Agile", [("Week 2", "A skateboard. Crude, but it moves."), ("Week 6", "A scooter. Feedback: needs to carry bags."), ("Month 4", "A car with a big boot, shaped by real use.")], verdict="Agile lowers risk by putting something usable in users' hands early and learning from it.")
```

### Scrum: Agile in fixed-length sprints

**Scrum** is the most common way teams practise Agile. Work happens in **sprints**, fixed time-boxes of one to four weeks (two is typical in Indian startups).

```dia
title: One Scrum sprint
sub: A two-week loop that repeats all year
loop([("Sprint planning", "Team picks the top backlog items it can finish this sprint and sets a sprint goal"), ("Build", "Design, code and test in small pieces; a 15-minute daily scrum surfaces blockers"), ("Sprint review", "Demo working software to stakeholders; gather feedback"), ("Retrospective", "What went well, what did not, one thing to change next sprint"), ("Backlog refinement", "PM reorders and details upcoming work using what was learned")], center="Sprint", center_desc="1–4 weeks, ends in a usable increment", edges=["commit", "demo", "reflect", "reprioritise", "next sprint"])
```

**Roles.** The **Product Owner** decides what is built and in what order, and owns the backlog. The **Scrum Master** protects the process and removes blockers; they are a coach, not a manager. The **Developers** (engineers, designers, testers) decide *how* to build it and commit to what they can finish. In most Indian product companies the PM plays the Product Owner role, while the engineering manager or a senior engineer covers what a Scrum Master would do.

::: words Scrum and backlog vocabulary
**Product backlog:** the ranked list of everything the product might do. **Sprint backlog:** the slice committed for this sprint. **User story:** a requirement written from the user's side, "As a first-time user, I want to pay with UPI without typing my ID, so that checkout is faster". **Acceptance criteria:** the checks that prove a story is done ("works when the UPI app is not installed"). **Story points:** a relative estimate of effort, not hours. **Velocity:** points completed per sprint, used for forecasting. **Definition of Done:** the shared bar every item must meet (tested, reviewed, documented). **Epic:** a big piece of work split into many stories.
:::

### Kanban: a continuous flow with limits

**Kanban** comes from Toyota's factories, where a card (*kanban* means "signboard" in Japanese) signalled that a station needed more parts. In software, every task is a card on a board, moving left to right. There are no sprints: work is pulled whenever capacity frees up.

```dia
title: A Kanban board for a payments support team
sub: The WIP limit on each column is the rule that makes Kanban work
steps([("Backlog", "All incoming requests, ranked by priority", ""), ("To do", "Next items, ready to start", "Limit 5"), ("In progress", "Being worked on right now", "WIP limit 3: finish before starting more"), ("Review / test", "Code review, QA check", "Pile-up here = bottleneck"), ("Done", "Released and verified", "Track time from start to done")], hl=[2])
```

The key rule is the **work-in-progress (WIP) limit**: only so many cards may sit in a column. If "In progress" is full, nobody starts something new; they help finish what is stuck. This exposes bottlenecks (cards piling up in "Review" means you need more reviewers) and shortens **cycle time**, the time a task takes from start to done. Kanban suits teams whose work arrives unpredictably: support engineering, bug triage, operations, a trust-and-safety queue.

| Aspect | Waterfall | Agile (Scrum / Kanban) |
|---|---|---|
| Flow | Linear, one pass through each stage | Iterative, many small loops |
| Flexibility | Changes are costly and disruptive | Changes welcomed, even late |
| Delivery | One release at the end | Frequent small releases |
| Customer involvement | At the start and the end | Continuous feedback |
| Risk | Concentrated at the end | Spread out, found early |
| Testing | After all building is done | Inside every sprint, often automated |
| Documentation | Heavy and detailed | Just enough to be clear |
| Best for | Fixed, well-understood scope; hardware; regulated migrations | Evolving requirements; consumer apps; anything with uncertainty |

```dia
title: Where real projects sit
sub: Most companies mix both: Agile for product work, Waterfall-like gates for regulated or hardware pieces
scale("Waterfall fits", "Agile fits", [("Lunar lander software", 0.05, "Cannot patch after launch"), ("Core-banking migration", 0.25, "Fixed regulatory deadline, fixed scope"), ("New UPI feature in an app", 0.6, "Spec from NPCI is fixed, the UX is not"), ("Growth experiments", 0.9, "Weekly tests, most will fail")], lnote="Requirements known, change is expensive", rnote="Requirements uncertain, change is cheap")
```

**Contrasting case.** Agile done badly becomes "no plan and constant churn": the backlog is reshuffled daily, stories are half-written, and the team never finishes anything. Agile does not mean no documentation or no deadlines. It means short planning horizons with real commitments inside each one.

::: key The one-line rule
Waterfall bets that you know what to build; Agile bets that you will learn what to build. Choose based on how certain the requirements are and how expensive a change after release would be.
:::

**In the interview.** "Agile or Waterfall for X?" is really a question about uncertainty and cost of change. A strong line: *"For the app's new onboarding I'd run two-week sprints and ship behind a feature flag, because we don't yet know what users will respond to. For the RBI-mandated change to how we store card data, the scope is fixed by regulation and the deadline is hard, so I'd plan it end to end up front, with Agile-style checkpoints inside."* Trap: saying "Agile is always better". Also be ready for "What does a PM do in sprint planning?" (brings a ranked, well-written backlog and the *why*; negotiates scope, not estimates) and "How do you handle an urgent request mid-sprint?" (assess impact; swap something out rather than silently adding; protect the sprint goal unless the issue is severe).

%% article | Technology · UX design | Design thinking: find the right problem before the right screen | How good product teams understand users, frame problems, and test ideas cheaply before engineers write code

PhonePe, Google Pay and BHIM all run on the same UPI rails, set by the same NPCI rules. Yet in April 2026 PhonePe alone processed about 47% of UPI transactions (startupfeed.in, April 2026), while NPCI's own BHIM app remains a small player. Same technology, same price (free), very different adoption. A large part of the difference is **user experience (UX)**: how easy, clear and trustworthy the product feels at every step, from scanning a QR code to seeing "Payment successful" with a satisfying tick.

**UX design** is the practice of shaping a product so it is useful, usable and pleasant for the people who use it. The most widely taught approach to it is **design thinking**.

## Design thinking in five stages

Design thinking is a user-centred, iterative way of solving problems. Its five stages (Stanford d.school's version) are **Empathise, Define, Ideate, Prototype, Test**, sometimes abbreviated EDIPT. "Iterative" matters: teams loop back when a test reveals that the problem was framed wrongly.

```dia
title: The five stages of design thinking
sub: Worked example: a grocery app sees older users abandon checkout
steps([("Empathise", "Watch 10 users over 55 shop on the app at home; read support tickets", "Observe, don't just ask"), ("Define", "Frame the problem: they fear paying for the wrong items", "One clear problem statement"), ("Ideate", "Many ideas: voice order, cart photo review, call-back option", "Go wide before narrowing"), ("Prototype", "Clickable Figma mock of a picture-based cart review", "Cheap and fast, not pretty"), ("Test", "5 users try it; 4 complete checkout, 1 still confused", "Learn, then loop back")], hl=[1])
```

### Empathise: understand the user in their context

Start with secondary research (market reports, app reviews, competitor apps) and a **competitive analysis** to spot gaps. Then go to the users. Interviews tell you what people *say*; observation and usability studies show what they *do*; surveys tell you *how many* feel something; analytics tell you *where* they drop off. The richest insights usually come from watching someone use the product in their real setting: a kirana owner updating stock on a cheap phone while serving customers will not behave like a tester in an air-conditioned office.

### Define: turn a pile of notes into one sharp problem

After twenty interviews you may have three hundred observations. The **KJ method** (named after Japanese anthropologist Jiro Kawakita) is a structured form of **affinity mapping** that turns them into themes.

```dia
title: Affinity mapping with the KJ method
sub: From 300 sticky notes to five insights
steps([("Capture", "One observation or quote per sticky note: 'I call my son before paying'", "Write what you saw, not your interpretation"), ("Group", "Silently cluster notes that feel related; move notes freely", "Let groups emerge; don't start with categories"), ("Label", "Name each cluster with the insight it reveals: 'Payment feels irreversible'", "A label is a sentence, not a word"), ("Rank", "Vote on which clusters matter most for the goal", "Frequency × severity")], hl=[2])
```

From the insights you build **personas**: fictional but research-based portraits of key user types, with demographics, goals, pain points, behaviours and context of use. A **primary persona** is the main target user ("Asha, 58, retired teacher in Nagpur, uses WhatsApp daily, shops online twice a month with her son's help"). A **secondary persona** has additional needs you should also serve (her son, who sets up the account). A **negative persona** is someone you are deliberately *not* designing for (a bulk buyer running a small shop), which is as useful as the primary one because it stops scope creep.

Then write a **problem statement** from the user's point of view: *[User] needs a way to [need] because [insight].* For example: "A first-time online shopper over 55 needs a way to check exactly what she is paying for, because she fears money cannot be recovered once it leaves her account." Teams often reframe it as a "How might we…" question to open up ideation: "How might we make paying feel reversible?"

### Ideate: go wide, then narrow

Generate many ideas without judging them first. Common techniques:

```dia
title: Four ideation techniques
cards([("Brainstorming", "Group generates ideas fast; no criticism until the end; build on others' ideas."), ("Mind mapping", "Put the problem in the centre; branch out into causes, users, channels, solutions."), ("Crazy 8s", "Fold paper into eight; sketch eight different solutions in eight minutes. Forces variety."), ("SCAMPER", "Prompts: Substitute, Combine, Adapt, Modify, Put to other use, Eliminate, Reverse.")], ncol=4)
```

Then prioritise. A simple way is to plot ideas on user value versus effort and start with the high-value, low-effort corner.

```dia
title: Prioritising ideas by value and effort
sub: Grocery checkout ideas from the example above
matrix("Effort to build", "Value to the user", [("Quick wins: do first", "High value, low effort"), ("Big bets: plan carefully", "High value, high effort"), ("Fill-ins: if time allows", "Low value, low effort"), ("Money pits: avoid", "Low value, high effort")], points=[("Photo cart review", 0.3, 0.8), ("Call-back option", 0.25, 0.6), ("Voice ordering", 0.8, 0.7), ("AR shelf view", 0.85, 0.2)])
```

### Prototype: make it real enough to learn from

A **prototype** is a cheap, tangible version of an idea, built to test an assumption before paying for real engineering. **Fidelity** is how close it looks and behaves to the final product.

```dia
title: Prototype fidelity: match it to the question you are asking
scale("Low fidelity", "High fidelity", [("Paper sketch", 0.05, "Minutes. Tests the idea and flow"), ("Wireframe", 0.3, "Hours. Tests layout and content"), ("Clickable mock (Figma)", 0.6, "Days. Tests navigation and copy"), ("Coded prototype", 0.92, "Weeks. Tests performance and real data")], lnote="Cheap to throw away; users give honest feedback", rnote="Realistic, but teams get attached to it")
```

### Test: watch people use it

In a usability test you give users a task ("buy these three items and pay") and watch silently, asking them to think aloud. Five users typically uncover most of the big problems in a design (Jakob Nielsen's widely cited rule of thumb). Use A/B or multivariate tests once the product is live and you have traffic (see the chapter on AI product quality for how A/B testing works).

A faster check, done by experts rather than users, is a **heuristic evaluation** against **Nielsen's 10 usability heuristics**. Learn these with examples; they are the vocabulary of UX critique in interviews.

```dia
title: Nielsen's 10 usability heuristics, with examples you know
src: Jakob Nielsen, Nielsen Norman Group (1994, updated 2020)
cards([("1. Visibility of status", "Tell users what is happening. UPI apps show 'Processing, do not press back'."), ("2. Match the real world", "Use the user's words and icons: ₹, 'Cash on delivery', vernacular options."), ("3. User control", "Easy exits and undo. Gmail's 'Undo send'; cancel order within 60 seconds."), ("4. Consistency", "Same word for same thing. Never mix 'Add to cart' and 'Add to basket'."), ("5. Error prevention", "Stop mistakes before they happen: UPI shows the payee's bank name before you pay."), ("6. Recognition over recall", "Show options instead of making users remember: recent payees, autocomplete."), ("7. Flexibility & efficiency", "Shortcuts for experts: 'Reorder' button, UPI Lite for small payments without PIN."), ("8. Minimalist design", "Show only what matters now. Google's home page; a one-field login."), ("9. Help recover from errors", "Say what went wrong and what to do: 'Payment failed, ₹349 will be refunded in 48 hours'."), ("10. Help and documentation", "Short, searchable, in context: a '?' next to the confusing field.")], ncol=2)
```

::: key The three lenses every product must pass
Great products are **desirable** (users want it), **feasible** (we can build it with our technology and team) and **viable** (it makes business sense). Design thinking protects desirability; engineering checks feasibility; the business case checks viability. A PM is responsible for the overlap.
:::

## Customer journey maps: the whole experience, not one screen

A delivery app can have a beautiful checkout and still lose the customer, because the order arrived 25 minutes late and support took two days to reply. A **customer journey map** is a timeline of everything one type of customer does, thinks and feels while trying to reach one goal, across every channel. It stops teams from optimising a single screen while the real pain sits elsewhere.

```dia
title: Journey map: a hostel student ordering dinner on a food app
sub: Current state; the feeling curve shows where the experience breaks
journey(["Feels hungry", "Browses", "Chooses & pays", "Waits", "Receives", "After"], rows=[("Doing", ["Opens app at 10 pm", "Scrolls, filters by price", "Applies coupon, pays by UPI", "Watches rider on map", "Meets rider at gate", "Rates, maybe complains"]), ("Thinking", ["Cheap and fast?", "Too many options", "Did the coupon apply?", "Why is he going away?", "Food is cold", "Is it worth reporting?"]), ("Touchpoint", ["Push notification", "Home feed, search", "Cart, payment page", "Tracking screen", "Rider, packaging", "Rating, chat support"]), ("Pain points", ["-", "Filters reset on back", "Coupon terms unclear", "ETA jumps 25 → 40 min", "Gate entry rules", "Bot loops, no human"]), ("Opportunity", ["Late-night value picks", "Keep filters", "Show savings upfront", "Explain the delay", "Hostel gate drop points", "One-tap refund for cold food"])], curve=[3, 3, 3, 1, 2, 2])
```

A good map has six parts: the **actor** (one persona), the **scenario and goal**, the **phases**, the **actions and touchpoints**, the **thoughts and emotions**, and the **pain points and opportunities**. It is built from evidence, not imagination: interviews give goals and emotions; product analytics give drop-offs; support tickets and reviews give recurring friction and the customer's own words; observation shows workarounds nobody mentions; operational data (actual versus promised ETA) shows where the service itself fails.

Two kinds exist. A **current-state map** documents today's experience and is used to diagnose friction and prioritise fixes. A **future-state map** describes the experience you intend to build and is used to align teams around a redesign. The practical rule: **one actor and one scenario per map**. A student, a restaurant owner and a rider have different journeys; a map that tries to cover everyone guides nobody.

**Why a PM cares.** Journey maps show where friction is frequent and severe, give product, design, operations, marketing and support one shared story, and let you attach a metric to each stage (search-to-menu conversion, payment success rate, actual-minus-promised ETA, first-response time).

**Contrasting case.** Design thinking is overkill when the problem is already well understood and measurable, such as speeding up a slow API, or when regulation dictates the flow, as with a KYC step. Then you optimise, rather than re-empathise.

**In the interview.** Design questions ("Design a pharmacy app for elderly users", "Improve Google Maps for two-wheeler riders") are secretly design-thinking questions. Structure the answer the same way: pick one persona and say why; name the goal; walk the journey and find the biggest pain; propose two or three solutions and prioritise; say how you would prototype and what metric would prove it worked. Strong line: *"Before solutioning, I want to pick one user. Elderly users who order refills for chronic conditions have the most frequent, highest-stakes journey, so I'll design for them first and treat caregivers as a secondary persona."* Name a heuristic when critiquing a screen ("this violates recognition over recall") and it signals real UX literacy.

::: quiz Check yourself
1. Name the seven SDLC stages in order and, for each, one thing the PM does.
2. Give one project where Waterfall is the right choice and explain why in terms of certainty and cost of change.
3. What is a WIP limit, and what does a pile of cards in the "Review" column tell you?
4. Who decides *what* gets built in Scrum, and who decides *how*?
5. Walk through the KJ method's steps. Why should labels be sentences?
6. Pick three of Nielsen's heuristics and give an Indian app example of each, one good and one violated.
7. Why should a journey map cover only one actor and one scenario?
8. *(From the orientation chapter)* In the restaurant model, which component is the "waiter", and which layer of the stack does it belong to?
:::
