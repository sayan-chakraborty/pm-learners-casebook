%% chapter | Technology · Orientation | The map before the territory | What actually happens when you tap "Place order", and the one picture of a software product that every later chapter hangs on

It is 8:47 pm on a Friday in Bengaluru. You open Zomato, search "biryani", pick a restaurant, pay by UPI and watch a little rider icon crawl towards your building. The whole thing takes ninety seconds of your attention. Behind it, a few dozen pieces of software in several data centres, your bank, NPCI, the restaurant's tablet and the rider's phone have all talked to each other, most of them more than once.

You will never be asked to build any of this. You will be asked, every week, to make decisions that depend on it: "Can we promise delivery in 20 minutes?", "Why did checkout break during the sale?", "Is it cheaper to build or buy search?", "Should the AI assistant be allowed to issue refunds?" This Part gives you enough of a mental model to ask good questions, understand the answers, and hold your own in an interview when the conversation turns technical.

## A restaurant is a good model of a software product

Engineers use strange words for ordinary ideas. Almost every idea in system design has a twin in a busy restaurant, and once you see the twin, the word stops being scary.

```dia
title: The restaurant model of a software product
sub: Each everyday role maps to a real component you will meet in this Part
analogy([("You, the diner, reading the menu and ordering", "Client (the app or browser)", "The part the user sees and touches. It asks for things; it does not cook."), ("The waiter who takes your order to the kitchen", "API", "A fixed way of asking for something and getting an answer back. The menu is its documentation."), ("The kitchen that cooks", "Server / backend", "Computers that run the business rules: price the cart, check stock, assign a rider."), ("Separate stations: tandoor, desserts, billing", "Microservices", "Small independent services, each owning one job, each deployable on its own."), ("The storeroom and the order register", "Database", "Where the truth is kept: menus, users, orders, payments."), ("Popular dishes kept warm at the pass", "Cache", "Copies of frequently asked-for data kept close so answers come back instantly."), ("The host who seats guests across sections", "Load balancer", "Spreads incoming requests across many identical servers so none is swamped."), ("The dispatch counter where packed orders wait", "Message queue", "Holds work until the next step is free, so spikes do not crush the kitchen."), ("Franchise kiosks near every metro station", "CDN", "Copies of images and videos stored near users so they load fast."), ("The guard at the gate checking IDs", "Authentication and authorisation", "Who are you, and what are you allowed to do?")])
```

Keep this table in your head. When an engineer says "the cache hit rate dropped so the database fell over", you can translate: the warm dishes ran out, so every order went back to the storeroom, and the storeroom could not cope.

## The layered view: nine questions every product answers

A second way to see a product is as a stack of layers. Each layer answers one question. A problem in any layer shows up to the user as the same thing: the app is slow, wrong or down. Part of a PM's job during an incident or a design review is to work out which layer the question really belongs to.

```dia
title: The layered view of a modern software product
sub: Top row is closest to the user; each layer answers one question
src: Adapted and extended from IIM Ahmedabad, Product Mindset 2026-27
layers([("Experience", "How do users interact? Screens, buttons, feedback", "The Zomato app, the website, a WhatsApp chatbot"), ("Edge & delivery", "How is content made fast everywhere?", "Food photos served from a CDN server in your city"), ("Security & access", "Who are you and what may you do?", "OTP login; a restaurant can edit only its own menu"), ("Integration (APIs)", "How do parts talk cleanly?", "App asks the order service to create an order"), ("Application logic", "What business rules run?", "Surge fee, coupon rules, which rider to assign"), ("Async & real-time", "How are spikes and live events handled?", "Order events queued; rider location pushed live"), ("Data", "Where is truth stored, and read fast?", "Orders in a database, menus in a cache, search index"), ("Delivery & runtime", "Where does code run and scale?", "Containers on AWS that add machines at dinner time"), ("Reliability & observability", "How is health measured and protected?", "Alert fires when payment success drops below 98%")])
```

You will hear specific product names attached to these layers. You do not need to know how to use any of them, only which layer they belong to, so you can place them when they come up.

| Layer | Names you will hear | What the name tells you |
|---|---|---|
| Experience | React, Next.js, Swift (iOS), Kotlin (Android), Flutter | Which toolkit the screens are built with |
| Integration | REST, GraphQL, gRPC, OpenAPI/Swagger, Postman, Kong, Apigee | How services expose and document their APIs |
| Application logic | Java/Spring Boot, Node.js, Go, Python/Django | Language and framework the backend is written in |
| Data | PostgreSQL, MySQL, MongoDB, Cassandra, Redis, Elasticsearch | Relational database, document store, wide-column store, cache, search index |
| Async & real-time | Kafka, RabbitMQ, Amazon SQS, WebSockets | Queues and streams for events; live two-way connections |
| Delivery & runtime | Docker, Kubernetes, AWS Lambda | Packaging code into containers; running and auto-scaling them |
| Reliability | SLOs, error budgets, Prometheus, Grafana, Datadog | How health is defined, measured and graphed |
| Security | OAuth 2.0, JWT, IAM, WAF, Vault | Login standards, access tokens, permissions, firewalls, secret storage |
| Edge | Cloudflare, Akamai, Fastly, CloudFront | Content delivery networks and edge computing |

::: key The one idea to carry through this Part
Every technical choice is a trade between **speed for the user, cost for the company, reliability, and how fast the team can ship**. Engineers can tell you the options and their prices. Only the PM can say which trade the user and the business want. That is why PMs need to understand the technology, not to build it.
:::

## How to use the rest of this Part

Each concept follows the same pattern: an everyday example first, then how it works with a diagram, then the terms, then where it breaks, then why a PM cares, then how it comes up in interviews.

```dia
title: What is in Part III
sub: Chapters build on each other; system design is the longest
cards([("How software is built", "SDLC, Waterfall, Agile, Scrum, Kanban, design thinking, UX heuristics, journey maps"), ("The internet and APIs", "DNS, IP, TCP/UDP, HTTP/HTTPS, CDNs, REST, webhooks, WebSockets, rate limits"), ("System design", "Databases, caching, scaling, queues, microservices, CAP, reliability, security, releases"), ("Design it at a PM level", "UPI payment, food-delivery tracking, WhatsApp-style messaging, worked end to end"), ("Cloud", "IaaS, PaaS, SaaS, deployment and pricing models, data residency, cloud bills"), ("Data and ML", "Types of learning, training, neural networks, recommenders, when to use AI"), ("LLMs", "Tokens, transformers, temperature, model types, prompting"), ("RAG, MCP and agents", "Grounding models in your data, connecting tools, agent loops and their risks"), ("AI product quality", "A/B tests, evals, precision and recall, guardrails, human-in-the-loop, cost per task"), ("Platform economics", "Network effects, two-sided pricing, multihoming, switching costs"), ("Blockchain, IoT, AR/VR", "What each is for, how it works, and when not to use it"), ("Low-code, trust, brand lift", "LCNC and vibe coding, security-resilience-governance, measuring campaigns")], ncol=3)
```

::: try Think first
Before reading on, write down what you think happens between tapping "Pay ₹349" and seeing "Order placed". List every system you think is involved. You will redo this exercise in the system-design chapter and compare.
:::

::: quiz Check yourself
1. In the restaurant model, what are the "waiter", the "dispatch counter" and the "dishes kept warm at the pass"?
2. Name the nine layers of a software product and the question each one answers.
3. An engineer says "we moved the menu reads to Redis". Which layer changed, and what should the user notice?
4. Which four things does almost every technical choice trade off against each other?
5. Kafka, Kubernetes and Cloudflare: place each in its layer.
:::
