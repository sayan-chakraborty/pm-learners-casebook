%% chapter | Product dossier · Grocery and quick commerce | Ten minutes, and the bill for it | Quick commerce is India's fastest-growing retail format. In mid-2026 the leader turned its first profit, the challengers were cutting back, and Amazon arrived with patient capital.

It is 10:52 p.m. A student in Gurugram realises there is no milk for the morning and, more urgently, no charger for his laptop. He opens Blinkit, adds both, and pays ₹1,340. At 11:03 a rider is at the door. Somewhere within two kilometres, a **dark store**, a small warehouse closed to walk-in shoppers, packed the order in under two minutes.

In three years this format went from a pandemic experiment to about **$11.3 billion of annual order value in FY26**, up from $1.6 billion in FY23 (analyst estimates cited by Business Standard, Jul 2026). Quick commerce now sells chargers, cosmetics and toys as well as groceries, and it has forced Amazon, Flipkart and even Myntra to promise delivery in minutes.

## The job, and the market

Customers hire quick commerce for **"I need this now, and I don't want to plan."** It replaces the walk to the kirana store and the monthly supermarket trip. Brands hire it for **"shelf space and ads in front of the most valuable urban shoppers."** That second job is where much of the profit comes from.

```dia
title: Who wins the quick-commerce order
sub: Share of order value among the top three, FY26 (%)
src: Analyst estimates cited by Business Standard (Jul 2026); excludes Flipkart Minutes, Amazon Now, BB Now, JioMart
stack100([("FY26", [("Blinkit", 52), ("Zepto", 27), ("Swiggy Instamart", 21)])], note="Blinkit alone did ₹17,132 Cr of order value in Apr–Jun 2026, +86% YoY (Eternal Q1 FY27).")
```

```dia
title: What a dark store is, in everyday terms
analogy([("A kirana store with no customers inside", "Dark store", "2,500–4,000 SKUs in a 3,000–4,000 sq ft unit, laid out for pickers, not shoppers"), ("A cricket fielder placed where the ball usually goes", "Demand-based stocking", "Each store stocks what its 2–3 km radius buys most, predicted by data"), ("A relay team", "Picker → packer → rider", "Order picked in ~2 minutes; rider leaves immediately; most of the 10 minutes is the ride"), ("Rent paid whether or not anyone orders", "Fixed cost per store", "A new store loses money until orders per day rise; density decides everything")])
```

```dia
title: Where the money goes on a ₹500 quick-commerce basket
sub: ₹ per order for a mature store, illustrative
src: Illustrative; calibrated to Blinkit and Instamart disclosures (margins near breakeven, inventory loss ~1.8% of order value)
waterfall([("Product margin / commission", 85, "~17% of basket"), ("Ads from brands", 20, "~4% of order value"), ("Customer fees", 15, "Delivery, handling, small cart"), ("Last-mile rider", -42, "The ride is most of the 10 min"), ("Store ops and rent", -38, "Pickers, rent, power"), ("Wastage and loss", -9, "Expired and damaged stock"), ("Discounts", -18, "Offers to win users"), ("Payments, support", -8, "")], total="Contribution", takeaway="Ads and a bigger basket turn a loss into a profit. A ₹300 basket with the same fixed costs loses money.")
```

```dia
title: Why a new dark store loses money for months
sub: Contribution margin by months since opening, illustrative cohort
src: Illustrative shape; Eternal says a steady-state store does ~₹11 lakh of order value a day
linechart({"Contribution margin %": [-18, -12, -8, -5, -2, 0, 2, 3, 4]}, ["M1", "M2", "M3", "M4", "M6", "M8", "M10", "M12", "M18"], unit="%", ymin=-20, notes=[("Contribution margin %", 5, "Breakeven when orders per day cover rent and staff")])
```

That curve explains the headlines of 2025–26. A company that opens hundreds of stores at once reports bigger losses even while every older store is improving. When expansion slows, the same company suddenly "turns profitable". Always ask an interviewer **what share of stores are less than six months old**.

%% article | Quick commerce · Blinkit (the benchmark) | The leader that chose infrastructure over discounts | Blinkit is not on the ISB list, but every quick-commerce answer is measured against it.

**Why it leads.** Blinkit had **2,443 dark stores**, **31.8 million monthly customers**, and **₹8.27 lakh of order value per store per day** in Q1 FY27. It posted its **first adjusted EBITDA profit, ₹102 Cr** (Eternal shareholder letter, Jul 2026). Its bet is infrastructure, not discounts. It now spends about ₹2.5 Cr to build each store, up from ₹1 Cr, on bigger stores with more products. It has also moved to a **first-party (1P) inventory model**: Blinkit buys and owns the stock rather than hosting third-party sellers. This became possible after Eternal restructured to be Indian-owned and controlled, since India's FDI rules stop foreign-owned e-commerce firms from holding inventory. Owning inventory gives better margins and more control over availability, but Blinkit now carries the risk of unsold stock (inventory losses were 1.8% of order value).

```dia
title: Blinkit cart and bill, annotated
sub: The last screen before payment is where trust is won or lost
phone([("Delivery in 11 minutes", 0.5, "#DCEFE0"), ("Cart items with +/– buttons", 1.5), ("You might also need: charger, curd", 1.0), ("Bill: items, delivery, handling, small-cart fee", 1.2, "#F6E6B8"), ("Tip for rider · Feeding India donation", 0.6), ("Pay ₹1,340 (UPI preselected)", 0.6, "#F6D9D7")], [(0, "The promise, repeated", "The ETA is shown again at checkout to justify paying now. Metric: cart-to-order rate."), (2, "Last-second add-ons", "Impulse items raise basket size, the most important lever. Metric: AOV."), (3, "Fee lines", "Small fees add up. Hidden or surprise fees are a 'drip pricing' dark pattern. Guardrail: complaints."), (5, "One-tap pay", "Saved UPI keeps drop-off near zero."), (4, "Optional extras", "Must be opt-in, not pre-ticked, to stay on the right side of dark-pattern rules.")])
```

**The lesson for interviews.** Blinkit shows that quick commerce can be profitable, but only when stores are **dense, mature and full of high-margin products and ads**. Its guardrails are the ones to quote: inventory loss %, fill rate (share of items ordered that are in stock), delivery time, and fee complaints.

%% article | Quick commerce · Zepto | The fastest-growing challenger that ran into its cash | Zepto was built to be faster and leaner than everyone. In 2026 it had to pause its IPO and cut back its café.

**Who it is for.** Young urban households and students who value speed and variety. Positioning: *"groceries and more in 10 minutes"*, with a sharper, younger brand than Blinkit. Zepto was founded in 2021 by two Stanford dropouts and grew faster than any Indian consumer company of its time.

**Core loop.** A late-night need → Zepto opens to a fast, image-heavy home screen → order → delivered in about 10 minutes → the next unplanned need goes to Zepto too. **Zepto Pass**, its membership, adds free delivery and member prices to lock in frequency.

```dia
title: Zepto home, annotated
sub: A store built for impulse, not for a list
phone([("Delivery in 8 mins · Address", 0.5, "#DCEFE0"), ("Search bar with rotating hints", 0.5), ("Category tiles: fruits, dairy, beauty, electronics", 1.3), ("Ad banner: brand launch", 0.9, "#F6E6B8"), ("Zepto Café · Super Saver tabs", 0.6), ("Bestsellers near you", 1.2), ("Nav: Home · Categories · Cart", 0.5, "#F6D9D7")], [(0, "ETA is the headline", "Speed is the brand. Showing 8 minutes turns a need into an order."), (3, "Brand-paid banner", "Ads are a large profit line; brands bid for the top slot."), (2, "Categories beyond grocery", "Beauty and electronics carry higher margins than milk. Metric: AOV and margin mix."), (5, "Local bestsellers", "Stocked for this area's demand. Metric: fill rate."), (4, "Sub-brands as tabs", "Café and Super Saver target different occasions and price points.")])
```

| Feature | User problem | Design choice | Metric |
|---|---|---|---|
| 10-minute promise | "I forgot something" | Dense dark stores, picking in ~2 minutes | Delivery time, order frequency |
| Zepto Pass | "Fees add up" | Membership with free delivery and member prices | Orders per member, churn |
| Zepto Café | "I want a coffee or snack with my groceries" | Kitchens inside dark stores | Attach rate (scaled back in 2025–26) |
| Super Saver | "It's cheaper at DMart" | Value range with larger packs | AOV, price-sensitive users |
| Ads platform for brands | Brands: "I need visibility where shoppers are" | Sponsored listings and banners | Ad revenue as % of GOV |

**Business model and 2026 reality.** FY26 revenue was about **₹22,623 Cr**, with a **net loss of ₹5,905 Cr** and an adjusted EBITDA loss of about ₹79 per order (Indian Retailer; Business Standard, Jul 2026). In July 2026 Zepto **put its IPO on hold** and chose to raise about ₹1,000 Cr privately at around $4.5 billion, well below the ~$7 billion it was valued at in late 2025. Dark-store expansion slowed, and **Zepto Café cut stores and menu items** (Business Standard, Sep 2026). Zepto has had the highest orders per store in the industry. Its problem is not demand but **the cash needed to reach maturity** across a young store network.

**Moat.** Operational speed (process power) and a young brand. Weaker than Blinkit on density and parent-company cash. Easy multi-homing: most users also have Blinkit.

**Metrics.** *North Star:* orders per week from repeat customers. *Inputs:* orders per store per day, AOV, fill rate, share of mature stores. *Guardrails:* contribution per order, cash burn per month, inventory loss.

::: key What I would build next at Zepto
1. **Planned-basket mode.** *Problem:* the monthly grocery shop still goes to DMart or BigBasket. *Bet:* a "monthly list" that delivers in a chosen slot at lower cost, using spare rider capacity in the afternoon. *Metric:* AOV of planned orders; rider utilisation off-peak.
2. **Store-level P&L cockpit for brands.** *Problem:* brands cannot see which stores sell their products. *Bet:* self-serve store-level sales and ad results. *Metric:* ad revenue per brand; brand retention.
:::

%% article | Quick commerce · Swiggy Instamart | Bigger baskets, fewer users, first breakeven | Instamart chose profit over size in 2026. It dropped four million unprofitable users and pushed basket size to the highest in the industry.

**Who it is for.** Swiggy's food customers first, and increasingly families doing larger top-up shops. Positioning: *"everything for your home, in minutes"*, with a standalone Instamart app alongside the Swiggy app.

**Core loop.** A Swiggy food user sees Instamart in the same app → tries it → Swiggy One gives free delivery on both → the household's grocery top-ups move to Instamart.

| Feature | User problem | Design choice | Metric |
|---|---|---|---|
| Megapods (larger dark stores) | "They never have what I need" | 10,000+ SKUs in bigger stores | Fill rate, AOV |
| Maxxsaver-style basket offers | Swiggy: "Small baskets lose money" | Discounts unlocked above a basket value | AOV (about ₹700) |
| Swiggy One | "Separate fees for food and groceries" | One membership for both | Cross-category users |
| 400+ brand partnerships | "I want premium and new brands" | Exclusive launches, bundles | Margin mix, ad revenue |

**Business model.** Q1 FY27 GOV was **₹7,907 Cr** with contribution margin at **+0.2% of GOV**, after breakeven in May 2026. The margin had been at −5.6% as recently as Q4 FY25. There are **1,171 dark stores in 131 cities**, and over 45% of stores are contribution-positive. Swiggy deliberately **shed over 4 million unprofitable users** (Inc42, Jul 2026). Adjusted revenue per order is about ₹108.

**Strengths and weaknesses.** Shared fleet and membership with food, and the highest AOV in the industry. But it is number three by share, has fewer stores than Blinkit, and its parent is still loss-making.

::: key What I would build next at Instamart
1. **"Cook tonight" bundles.** *Problem:* users decide on dinner and then hunt for ten ingredients. *Bet:* recipes from Swiggy's food data turned into one-tap ingredient carts. *Metric:* AOV; cross-use of food and Instamart.
2. **Household restock predictions.** *Problem:* running out of staples. *Bet:* "You usually buy atta every 18 days; add it?" *Metric:* repeat orders; share of planned items.
:::

%% article | Grocery · BigBasket | The scheduled-grocery pioneer that had to become fast | BigBasket taught India to buy vegetables online. Quick commerce then made its core promise feel slow.

**Who it is for.** Families who buy fresh produce and do a large weekly shop, and who value quality and range. Owned by the **Tata group** since 2021 and linked to the **Tata Neu** app and loyalty points.

**What changed.** BigBasket built India's best supply chain for fresh produce around next-day delivery slots. As Blinkit and Zepto made 10 minutes normal, it moved its whole consumer business to **BB Now**, delivering in 15–30 minutes, by August 2024. It also runs **BB Daily** (morning milk subscriptions) and a B2B arm, and it is testing quick food.

**Business model.** FY26 revenue was **₹10,498 Cr (+6%)** and the consolidated loss widened **59% to ₹3,192 Cr** (MediaNama, Sep 2026). The consumer arm lost ₹3,073 Cr on ₹8,223 Cr of revenue. Advertising revenue grew 19% to ₹242 Cr. Parent Tata Digital lost ₹4,974 Cr, about 64% of it from BigBasket (Inc42).

**Moat and weakness.** It has real **process power** in fresh-produce sourcing and quality. The weakness is that it arrived late to speed, grew only 6%, and has a weaker app habit than the leaders.

::: key What I would build next at BigBasket
1. **"Freshness guarantee" as the brand.** *Problem:* quick-commerce produce quality is inconsistent. *Bet:* farm-date labels and no-questions replacement on fruit and vegetables. *Metric:* share of orders with fresh items; complaint rate.
2. **Tata Neu household bundle.** *Problem:* Tata's customers are spread across many apps. *Bet:* BB Daily plus BB Now plus NeuCoins as one household plan. *Metric:* households with two or more Tata services.
:::

%% article | Quick commerce · Amazon Fresh and Amazon Now | The patient giant | Amazon is using India as its global test lab for delivery in minutes, backed by Prime and a balance sheet no startup can match.

**Who it is for.** Amazon's existing customers, especially **Prime members**, who already trust Amazon for everything else. **Amazon Fresh** offers scheduled grocery slots in many cities. **Amazon Now** is its delivery-in-minutes service, launched in Bengaluru in 2025.

**The strategy.** Andy Jassy said on his June 2026 India visit that Amazon Now orders had **"doubled every quarter since launch"** and that Prime members **triple their shopping frequency** after they start using it. The plan is to go from 15+ cities to **300+ cities**, with micro and urban fulfilment centres stocking groceries, beauty, fashion and electronics (Outlook Business, Jun 2026). Amazon's advantages are the Prime base, supplier relationships, an ads business that already knows what each shopper buys, and the ability to lose money for years.

**Risk.** Amazon arrives late in cities where Blinkit and Zepto have density. It has a history of pausing India experiments. And quick commerce's fixed costs punish anyone without scale.

::: key What I would build next at Amazon Now
1. **Prime "Now" pass inside Prime.** *Problem:* Prime members don't think of Amazon for a 10-minute need. *Bet:* free minutes-delivery for Prime above a basket value. *Metric:* Now orders per Prime member; Prime renewal rate.
2. **Scheduled plus instant in one cart.** *Problem:* a user wants milk now and a microwave tomorrow. *Bet:* one checkout that splits delivery speeds automatically. *Metric:* AOV; cross-category orders.
:::

## Comparing the players

| | Blinkit | Zepto | Instamart | BigBasket | Amazon Now |
|---|---|---|---|---|---|
| Stores | 2,443 | Fewer, highest orders per store | 1,171 | BB Now network | Scaling to 300+ cities |
| Latest economics | Adj. EBITDA +₹102 Cr (Q1 FY27) | FY26 loss ₹5,905 Cr | CM +0.2% | FY26 loss ₹3,192 Cr | Not disclosed |
| Edge | Density, 1P margins, ads | Speed, orders per store | AOV, shared fleet | Fresh supply chain | Prime, capital, ads |
| Main risk | Store capex, inventory | Cash runway | Scale gap | Slow growth | Late to density |

```dia
title: Assortment versus speed promise
sub: Where each format sits (author's judgement)
matrix("Speed promise", "Assortment", [("Scheduled supermarket", "Wide range, delivered in slots: Amazon Fresh"), ("The prize", "Wide range in minutes: megapods, Blinkit's big stores"), ("Kirana", "Narrow range, walk-in"), ("Classic quick commerce", "2,500–4,000 SKUs in 10 minutes")], points=[("Amazon Fresh", 0.15, 0.62), ("BigBasket", 0.4, 0.58), ("Blinkit", 0.82, 0.58), ("Instamart", 0.68, 0.24), ("Zepto", 0.88, 0.2)])
```

## Likely interview questions

1. **"Blinkit's AOV fell from ₹525 to ₹518 in a quarter. Is that bad?"** Not necessarily. New users and new cities have smaller baskets. Split the change by cohort and category before judging.
2. **"How many dark stores does a city of 50 lakh people need?"** Serviceable households × order frequency ÷ orders one store can handle per day. Then check that each store sits within a 2–3 km radius.
3. **"Should Zepto keep Zepto Café?"** Compare its contribution per order with the lift it gives grocery frequency. Kill it if it is only adding cost.
4. **"Design a feature to increase basket size without discounts."** Options include complete-the-recipe carts, bundles, and a free-delivery threshold. Guardrail: users must not feel manipulated.
5. **"Why is Amazon a threat even though it is late?"** Prime frequency, ads data, capital, and existing supplier terms.
6. **"Delivery times went up by 2 minutes in Pune. Diagnose."** Check picking time against riding time, rider supply at peak, store stock-outs forcing substitutions, and new stores still learning demand.

::: quiz Recall: quick commerce
1. What is a dark store, and why does a new one lose money for months?
2. Name the three biggest cost lines on a quick-commerce order and the two biggest revenue lines beyond product margin.
3. Why did Blinkit's shift to a 1P inventory model need a change in who owns Eternal?
4. What did Instamart give up to reach contribution breakeven?
5. What is "drip pricing", and where on a checkout screen does it appear?
6. Give three reasons Zepto paused its IPO in 2026.
7. (Food delivery) Why does density matter even more in quick commerce than in food delivery?
:::
