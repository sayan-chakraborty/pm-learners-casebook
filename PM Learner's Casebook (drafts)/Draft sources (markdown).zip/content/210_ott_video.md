%% chapter | Product dossier · OTT video | Subscriptions, ads and cricket | Netflix proved streaming can be very profitable. JioHotstar proved India's version runs on cricket, bundles and ads. Prime Video uses shows to sell Prime. Three business models for one screen.

A Sunday evening in May 2026, an IPL match in its last over. Across India, hundreds of millions of people are watching on phones: on a bus in Lucknow, in a hostel in Kota, at a dhaba in Punjab. Each of them could choose Hindi, Tamil, Telugu or Bhojpuri commentary. Every ad break is sold to the second. The next morning many of the same viewers will open Netflix or Prime Video for a series. Their evening swaps a live, ad-funded, mass event for private, subscription-funded content, and the two businesses could hardly be more different.

## The job, and the market

Viewers hire streaming for **"entertain me tonight, with something I'll like, without hunting for it."** Sports fans hire it for **"let me watch the match live, everywhere."** Advertisers hire the ad-supported tiers for **"reach at TV scale, targeted like digital."** In India, telecom operators also hire OTT apps for a job of their own: **"give customers a reason to buy a bigger recharge."**

```dia
title: Four ways to pay for streaming
sub: Most services now mix two or more
cards([("SVOD: subscription", "Pay monthly, no ads. Netflix's original model. Revenue = subscribers × price."), ("AVOD: ads", "Free to watch, paid by advertisers. YouTube; much of JioHotstar."), ("Hybrid: cheaper plan with ads", "Netflix and Prime Video now run ads by default in many markets, with a paid ad-free option."), ("Bundle", "Included with something else: a Jio recharge, Amazon Prime, a broadband plan. The partner pays.")], ncol=4)
```

Streaming spent a decade chasing subscribers at a loss, then switched to profit in 2022–23. Netflix led the change. It cracked down on password sharing in 2023, launched a cheaper ad-supported plan, and stopped reporting subscriber numbers in 2025 to focus attention on revenue and profit.

```dia
title: Netflix's operating margin, from growth to profit
sub: Operating income as % of revenue
src: Netflix annual reports; 2025 approximate; 2026 is the company's target (Q2 2026 letter)
linechart({"Operating margin %": [18.3, 20.9, 17.8, 20.6, 26.7, 29.5, 31.5]}, ["2020", "2021", "2022", "2023", "2024", "2025", "2026 target"], unit="%", ymin=10, notes=[("Operating margin %", 3, "Password-sharing crackdown and ads plan")])
```

India is the hardest market for this playbook. Indians watch a lot of video but pay little for it: YouTube is free, cricket comes bundled with a mobile recharge, and a Netflix Premium plan costs more than many households' monthly mobile bill. So in India, streaming services earn much less per user than they do in the US, and they rely far more on ads, bundles and cricket. Keep this in mind for any India pricing question.

%% article | OTT · Netflix | The subscription machine | Netflix's product is not a show. It is the confidence that there will always be something good to watch, found in under a minute.

**Who it is for.** Paying households worldwide, and in India mostly urban, English-comfortable viewers who value series and films over live sports. Positioning: *"entertain the world."* In India it cut prices in 2021 to add a **mobile-only plan from ₹149 a month**, a product built for India's phone-first viewers.

**Core loop.** Open → a personalised home screen → press play within seconds → watch → finish a series → the algorithm suggests the next one → renew next month. The whole product aims at one outcome: **no month without something you want to watch**, because that is when people cancel.

**First run.** Sign up (plan choice, then payment), then pick a few titles you like so recommendations can start. The riskiest time is the **first 30 days**. A new member who doesn't find a show they love in the first weeks is the most likely to cancel.

```dia
title: Netflix home screen, annotated
sub: Every row and every image is personalised
phone([("Profile picker (who's watching?)", 0.6), ("Hero: big trailer, autoplay", 1.5, "#DDE8F0"), ("Continue watching", 0.7, "#DCEFE0"), ("Top 10 in India today", 0.8), ("Because you watched...", 0.8), ("New and popular · Games", 0.6, "#F6E6B8"), ("Nav: Home · New & Hot · My Netflix", 0.5, "#F6D9D7")], [(0, "Profiles", "Separate histories for each family member keep recommendations accurate."), (1, "Autoplay hero", "Sells one title hard. The artwork is chosen per user: different users see different images."), (2, "Continue watching", "The most-used row. Unfinished series predict renewal."), (3, "Top 10", "Social proof: what India is watching today."), (4, "'Because you watched'", "Explains the recommendation, which builds trust in it."), (5, "New formats", "Games, video podcasts, and from 2026 short-form clips.")])
```

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Personalised rows and artwork | "Too much choice; nothing to watch" | Each row and each thumbnail is chosen for you | Time to first play, hours per member |
| Profiles | "My kid's cartoons ruin my suggestions" | Separate histories per viewer | Recommendation accuracy |
| Downloads | "My internet is bad on the train" | Watch offline | Mobile-plan retention |
| Paid sharing (2023) | Netflix: "100M+ households watch without paying" | Extra-member fee; household detection | Revenue per account, sign-ups |
| Ads plan | "It's too expensive" | Cheaper plan with ads | New members, ad revenue |
| Live events, games, short-form | "I want more reasons to open Netflix" | Adds daily or weekly habits beyond series | Engagement, retention |

**Business model.** 2026 revenue guidance is **$51.0–51.4 billion** at a **31.5% operating margin**. Q2 2026 revenue was $12.56 billion (+13%) and advertising is expected to roughly double to **about $3 billion** in 2026 (Netflix Q2 2026). Netflix bid for Warner Bros. in December 2025, then **withdrew in February 2026** when Paramount Skydance made a higher offer. That decision kept Netflix a builder rather than a buyer of content.

```dia
title: Where a subscription rupee goes
sub: A ₹199/month plan after GST, using Netflix's global cost structure; illustrative
src: Illustrative; cost shares approximated from Netflix's reported cost structure
waterfall([("Net subscription", 169, "₹199 minus 18% GST"), ("Content amortisation", -74, "Shows and films, spread over years"), ("Streaming, payments, other", -20, ""), ("Marketing", -12, ""), ("Technology", -12, ""), ("G&A", -7, "")], total="Operating profit", takeaway="Content is the main cost. A new member adds almost pure profit, because the shows are already paid for.")
```

**Moat.** **Scale economies** in content: a $15–18 billion annual content budget spread over hundreds of millions of households, so the cost per member is low. **Data** on what the world watches. **Branding**. Global rights to its originals (a **cornered resource**: *Squid Game* exists only on Netflix).

**Metrics.** *North Star:* hours of satisfied viewing per member. *Inputs:* time to first play, completion rate, share of members watching a new release in 30 days, ads-plan reach. *Guardrails:* monthly churn, price-increase churn, ad load on the ads plan.

::: key What I would build next at Netflix India
1. **Cricket-free evenings made easy.** *Problem:* during IPL season Netflix viewing in India drops. *Bet:* "match-length" picks (films under 2 hours, one-episode stories) promoted at match times to non-cricket viewers. *Metric:* hours per member during IPL months; churn in April–May.
2. **Regional-language original slate with subtitles in 10 languages.** *Problem:* growth outside English-speaking metros is slow. *Bet:* more Tamil, Telugu and Malayalam originals with strong subtitles. *Metric:* non-metro sign-ups; share of viewing in regional languages.
:::

%% article | OTT · JioHotstar | India's giant, built on cricket and bundles | JioHotstar combines Disney's Hotstar with Reliance's JioCinema. It reaches more than half a billion Indians a month and runs the world's largest live-streaming events.

**Who it is for.** Mass India: cricket fans, TV-serial families, regional-language viewers, and Jio customers who get it bundled with a recharge. Positioning: *"everything Indians watch, in every language."* It was formed by the 2024 merger of Viacom18 and Star India into **JioStar**, and JioHotstar launched in February 2025.

**Core loop.** Cricket (IPL, ICC events) pulls in huge audiences → viewers discover serials, films and Disney/HBO content in the same app → bundled or cheap plans keep them → ad revenue from live sport and entertainment pays for rights → more rights.

```dia
title: JioHotstar during a live IPL match, annotated
sub: Built for 50 million-plus people watching the same moment
phone([("Live video (vertical or landscape)", 2.4, "#DDE8F0"), ("Language: Hindi · Tamil · Telugu · ...", 0.5, "#DCEFE0"), ("Camera angles · key moments", 0.6), ("Scorecard · fantasy stats", 0.7), ("Sponsor overlay / ad break", 0.5, "#F6E6B8"), ("More: highlights, serials, Tadka", 0.8)], [(1, "Language choice", "Regional commentary widened the audience; regional viewing grew 33%."), (0, "Vertical viewing", "Phone-first design; most viewers watch on mobile."), (2, "Key moments", "Late joiners catch up without leaving live."), (4, "Ads sold per second", "Live sport is the most valuable ad inventory in India."), (5, "What to watch after", "Cross-sell from cricket to serials is the retention engine.")])
```

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Multi-language commentary | "I want the match in my language" | 10+ language feeds | Reach outside Hindi markets |
| Scale engineering | "It buffers at the big moment" | Built for tens of millions watching at once | Peak concurrency, buffering % |
| Cheap plans and Jio bundles | "I won't pay ₹500 a month" | Low-priced mobile plans; included in Jio recharges | Paid subscriptions |
| Tadka (short-form micro-content) | "I have five minutes" | Vertical short videos and micro-dramas | 100M users in two months |
| Disney, HBO, NBCU libraries + TV serials | "Something for everyone at home" | One app for the family | Watch time outside cricket |

**Business model.** Q1 FY27 (Apr–Jun 2026, with IPL) JioStar revenue was **₹10,946 Cr (+14%)** and operating EBITDA ₹933 Cr. JioHotstar averaged **530 million monthly active users**. IPL 2026 reached **700 million on digital** and 1.2 billion across TV and digital (JioStar via BestMediaInfo, Jul 2026). Revenue comes from advertising (especially sports), subscriptions (many through Jio bundles) and TV distribution.

**Moat.** **Cornered resource**: exclusive cricket and major studio rights. **Scale economies** in streaming technology and ad sales. **Distribution**: Jio's hundreds of millions of telecom customers. The main risk is **rights costs**: it paid a very high price for cricket, and if ad markets weaken, those costs remain.

**Metrics.** *North Star:* monthly active viewers (reach), with watch time as a close second. *Inputs:* cricket-to-entertainment conversion, paid subscriptions, ad fill rate at peak, regional watch time. *Guardrails:* buffering rate at peak, ad frequency complaints, subscription churn after IPL.

::: key What I would build next at JioHotstar
1. **Post-IPL retention path.** *Problem:* millions of subscribers join for the IPL and leave in June. *Bet:* during the season, build each fan a personalised "after IPL" watchlist of serials and films, and offer a discounted renewal on the final day. *Metric:* 60-day post-season retention.
2. **Shoppable ads during matches.** *Problem:* advertisers pay for reach but want sales. *Bet:* tap-to-buy from ads via JioMart and brand stores, with UPI. *Metric:* ad revenue per thousand viewers; conversion.
:::

%% article | OTT · Amazon Prime Video | The show that sells the shipping | Prime Video is not really a standalone business. It is one of the reasons people pay for Prime and stay.

**Who it is for.** Amazon Prime members in urban India who want Indian originals (*Panchayat*, *Mirzapur*, *The Family Man*) plus Hollywood. Positioning: *"part of Prime."* The Prime annual fee in India is ₹1,499, which includes shipping, music and video, and costs less than many standalone OTT plans.

**What changed in 2025.** From **17 June 2025**, Prime Video India shows **ads by default**. An ad-free add-on costs **₹129 a month or ₹699 a year** (afaqs!, 2025). Amazon's pitch to advertisers is different from JioHotstar's: not mass reach, but **ads matched to real shopping data**, with sales measured on Amazon.

**Core loop.** Prime member → watches a hit original → associates Prime with value → renews Prime → shops more on Amazon → Amazon earns from shopping and ads → funds more originals.

```dia
title: Why Amazon spends on shows it could sell for more
sub: Prime Video's job is to make Prime renew
loop([("Hit original show", "Panchayat, Mirzapur, local films"), ("Prime feels worth it", "Video + shipping + music"), ("Prime renewals", "Fewer members lapse"), ("More shopping", "Prime members shop more often"), ("Retail and ad profits", "Now including ads inside Prime Video")], center="Prime flywheel", center_desc="video pays back through retail")
```

**Moat.** The **Prime bundle** (switching cost: an annual fee already paid), Amazon's **shopping data** for ads, and a deep balance sheet. Weaknesses: less live sport than JioHotstar, a smaller share of viewing time than YouTube or JioHotstar, and some user annoyance at ads being switched on by default.

**Metrics.** *North Star:* Prime members who stream monthly. *Inputs:* originals' reach in the first 30 days, streaming days per member, ad-free add-on uptake. *Guardrails:* Prime renewal rate, ad complaints, cancellations blamed on ads.

::: key What I would build next at Prime Video
**"Shop the scene."** *Problem:* viewers want the kurta or the sofa they see on screen. *Bet:* pause-to-shop with Amazon listings, labelled clearly as ads. *Metric:* retail GMV attributed to Prime Video; ad-free upgrade rate (as a guardrail).
:::

## Comparing the three

| | Netflix | JioHotstar | Prime Video |
|---|---|---|---|
| Model | Subscription + ads plan | Ads + cheap subscriptions + Jio bundle | Part of Prime; ads by default |
| Hero content | Global originals | Cricket, serials, regional | Indian originals, films |
| India audience | Urban, English-comfortable | Mass, every language | Prime households |
| Moat | Content scale, data, brand | Sports rights, Jio distribution | Prime bundle, shopping data |
| Risk | Slow growth in India | Rights costs, post-IPL churn | Ad backlash, less live content |

```dia
title: Live versus on-demand, mass versus premium
sub: Where each service's core offer sits (author's judgement)
matrix("Share of live and sports content", "Price per viewer (premium)", [("Premium library", "Paid, on-demand: Netflix"), ("Premium live", "Paid sports-first services"), ("Mass library", "Free or bundled on-demand: YouTube, MX"), ("Mass live", "Cricket at massive scale: JioHotstar")], points=[("Netflix", 0.15, 0.66), ("Prime Video", 0.25, 0.56), ("JioHotstar", 0.84, 0.2)])
```

## Likely interview questions

1. **"Netflix subscriptions in India declined this quarter. Diagnose."** (IIMA casebook) Split into sign-ups and churn. Check pricing, the release calendar, IPL clashes, payment failures, and competitors' launches.
2. **"How should Netflix price in India?"** (IIMA) Consider mobile plans, elasticity by segment, bundles with telcos, and ads versus a price cut.
3. **"Design a feature to retain JioHotstar subscribers after the IPL."** Use content bridges, personal watchlists, and a pause option instead of cancel.
4. **"Prime Video added ads by default. How do you measure success?"** Ad revenue and advertiser return on spend, against guardrails of Prime renewal and cancellations.
5. **"What should Netflix's North Star be now that it doesn't report subscribers?"** Engagement (hours per member) and revenue. Explain why hours predict churn.
6. **"Estimate peak concurrent viewers for an India–Pakistan match."** Smartphone users × cricket fans × share watching live × share on JioHotstar at the peak moment.

::: quiz Recall: OTT
1. Name the four ways streaming is paid for and one example of each.
2. Why did Netflix's operating margin jump after 2023?
3. What is Prime Video's real job inside Amazon?
4. Give JioHotstar's moat in three words, and its biggest risk.
5. Why is a new subscriber almost pure profit for Netflix?
6. Pick a North Star and two guardrails for Prime Video's ads launch.
7. (Cloud) What does streaming an IPL final need from cloud infrastructure?
:::
