%% chapter | Product dossier · E-commerce | Selection, trust and the festive sale | Flipkart owns Bharat and the big sale. Amazon owns Prime households and the flywheel. Myntra shows how a focused vertical can out-earn both. All three are now being squeezed by zero-commission rivals and ten-minute delivery.

October, 11:59 p.m. Three million people in India have Flipkart open, thumbs hovering, waiting for the Big Billion Days sale to start at midnight. A phone they have watched for weeks will drop by ₹8,000 with a bank card offer, an exchange bonus for their old phone, and a no-cost EMI. By 12:10 a.m. several models are sold out. For many Indian households this sale *is* e-commerce: a planned, once-a-year purchase of the phone, the TV or the fridge. The 2026 edition begins on 9 October.

## The job, and the market

Shoppers hire e-commerce for **"the widest choice at the best price, delivered to my door, with easy returns if it goes wrong."** Sellers hire it for **"customers across India I could never reach from my shop."** In India, trust is part of the job. Cash on delivery (COD), easy returns and brand guarantees exist because many buyers still worry about getting a fake or broken product.

```dia
title: India's e-commerce market, FY25
sub: Share of gross merchandise value (GMV) and monthly active users, approximate
src: ICICI Securities via Entrackr (2026). Market ~$70B GMV in FY25; smartphones are 30–40% of GMV
bars([("Flipkart", 55, "50–60% of GMV; 220–240M MAU"), ("Amazon India", 27.5, "25–30% of GMV; ~150M MAU"), ("Meesho", 10, "~10% of GMV; ~200M MAU, zero commission")], unit="%", fmt="{:.0f}")
```

Three rules shape Indian e-commerce and appear in almost every interview answer.

1. **Foreign-owned marketplaces cannot own inventory.** India's FDI rules make Amazon and Walmart-owned Flipkart act as *marketplaces*: independent sellers own the stock, and the platform charges fees. This is why "seller" programmes and seller fees matter so much in India.
2. **Returns and COD are costly.** A cancelled COD order sent back to the warehouse (**RTO**, return to origin) costs shipping both ways and earns nothing.
3. **Ads are now a major profit line.** E-commerce and retail media were worth about **₹22,000 Cr in 2025, 23% of India's digital ad spend, up 50%** (FICCI-EY, Mar 2026). Sponsored listings earn money on every search.

```dia
title: The marketplace, explained
sub: Who does what in a typical Amazon or Flipkart order
steps([("Seller lists", "Independent seller owns stock; pays referral and fulfilment fees", ""), ("Customer finds it", "Search ranking and sponsored ads decide what is seen", "Ads vs relevance trade-off"), ("Order and pay", "UPI, card, EMI or cash on delivery", "COD raises return risk"), ("Fulfilment", "Stored in platform warehouse or shipped by seller", ""), ("Delivery and returns", "Last-mile partner; returns go back to the seller", "Returns can erase the margin")], hl=[4])
```

%% article | E-commerce · Amazon | The flywheel company | Amazon runs the same loop everywhere: more selection and lower prices bring more customers, which bring more sellers. In India it adds Prime, ads and now delivery in minutes.

**Who it is for.** Urban and metro households, especially **Prime members** who want reliability, fast delivery and genuine products. Positioning: *"Earth's most customer-centric company."* Globally Amazon's **Q2 2026 revenue was $200.6 billion (+20%)**. AWS grew 37% and advertising 26% (Amazon Q2 2026 results).

**Core loop.** This is the famous flywheel Jeff Bezos sketched on a napkin in 2001.

```dia
title: The Amazon flywheel
sub: Every part speeds up the next; lower costs keep it spinning
loop([("Selection", "More sellers, more products"), ("Customer experience", "Find it, trust it, get it fast"), ("Traffic", "More shoppers visit and return"), ("Sellers", "Sellers go where shoppers are"), ("Lower cost structure", "Scale spreads fixed costs"), ("Lower prices", "Savings passed to customers")], center="Growth", center_desc="Bezos's 2001 napkin sketch")
```

**First run.** Browsing needs no login, and search works immediately. The login comes at checkout, where saved addresses and UPI make repeat purchases fast. For new users the key moment is the **first delivery**: arriving on the promised date is what makes them trust Amazon.

```dia
title: Amazon.in app home, annotated
sub: Search, Prime and speed compete for the top of the screen
phone([("Search bar + Alexa for Shopping mic", 0.6, "#DCEFE0"), ("Tabs: Amazon · Amazon Now · Fresh", 0.5), ("Deals banner (sale / bank offers)", 1.0, "#F6E6B8"), ("Keep shopping for... (history)", 1.0), ("Sponsored products carousel", 1.0, "#F6E6B8"), ("Buy again · Amazon Pay", 0.8), ("Nav: Home · You · Cart · Menu", 0.5, "#F6D9D7")], [(0, "Search is the product", "Most purchases start with a typed query. The AI assistant answers questions like 'best phone under ₹20k'."), (2, "Bank-offer banners", "Card and EMI offers decide big-ticket purchases in India."), (1, "Speed as a tab", "Amazon Now puts delivery in minutes one tap from the main store."), (4, "Sponsored slots", "Ads earn on every scroll. Guardrail: sales per search must not fall."), (3, "Personal history", "Picks up where the user left off; raises return visits.")])
```

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Prime (full, Lite, shopping-only plans) | "Delivery fees and waits" | Free fast delivery plus video and music; cheaper tiers for India | Prime members, orders per member |
| Alexa for Shopping (formerly Rufus) | "Which one should I buy?" | AI answers product questions from reviews and specs | Search-to-purchase conversion |
| Reviews and A-to-Z guarantee | "Is it genuine? What if it breaks?" | Social proof plus a refund promise | First-order conversion, returns |
| Sponsored Products | Sellers: "Nobody sees my listing" | Pay-per-click ads inside search results | Ad revenue per search |
| Amazon Now (2025) | "I need it in minutes" | Micro fulfilment centres in cities | Prime frequency (3x for users) |
| Zero referral fee under ₹1,000 (2026) | Sellers: "Fees kill low-price items" | Removed for 12.5 crore products | New sellers, low-price selection |

**Business model.** In India, Amazon earns referral and fulfilment fees from sellers, advertising, Prime fees and payments. From **16 March 2026** it removed referral fees on items under ₹1,000 across 1,800+ categories, following Flipkart and responding to Meesho (YourStory, Mar 2026). The fee income it gives up is expected to come back through more selection, more orders and more ads.

**Moat.** Scale economies in logistics and technology. Branding: trust in genuine products and returns. Switching costs through Prime: once you have paid for the year, you shop where the benefits are. And the data behind the ads business.

**Metrics.** *North Star:* purchases by active customers per month (or Prime members' annual spend). *Inputs:* selection (in-stock listings), delivery promise accuracy, search conversion, Prime sign-ups. *Guardrails:* return rate, counterfeit complaints, the share of search results that are ads, seller fee burden.

::: key What I would build next at Amazon India
1. **Vernacular voice shopping for Bharat.** *Problem:* new internet users find text search hard. *Bet:* Alexa for Shopping in Hindi, Tamil and Bengali, with voice answers and product videos. *Metric:* first purchases by non-English users; conversion rate.
2. **"Delivery speed you choose" pricing.** *Problem:* users pay for speed they do not need, and Amazon pays for it too. *Bet:* let users pick "in minutes", "tomorrow" or "in 4 days, save ₹20". *Metric:* delivery cost per order; order frequency.
:::

%% article | E-commerce · Flipkart | India's own marketplace, still waiting to list | Flipkart wins on phones, value and the festive sale. It is also building fintech, quick commerce and a value app, and it has pushed its IPO further out.

**Who it is for.** Value-conscious buyers across Bharat, first-time online shoppers, and anyone buying a smartphone. Positioning: *"India's own"* e-commerce, with the biggest sale of the year. Flipkart has been owned by Walmart since 2018.

**Core loop.** A big-ticket purchase in a sale (a phone, with EMI and exchange offer) → a positive delivery experience → the user returns for fashion and household items → Flipkart Pay Later and the co-branded card increase buying power → the next sale.

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| Big Billion Days | "I wait all year for the best price on a phone or TV" | Sale events with bank offers and early access for members | Sale-period GMV, new users |
| Exchange offers and no-cost EMI | "I can't afford ₹25,000 at once" | Old phone value + instalments | Conversion on high-value items |
| Vernacular app and voice search | "I don't read English comfortably" | Hindi and regional-language shopping | Tier-2/3 user share |
| Shopsy | "I want very low prices" | A separate value app with low-price sellers | Users from Meesho's segment |
| Flipkart Minutes | "I need it now" | Quick commerce from dark stores | Frequency, share of wallet |
| super.money | "I pay by UPI anyway" | Flipkart's own UPI app with cashback | UPI share (~1.7%), data on spending |

**Business model.** FY25 revenue was **₹20,493 Cr (+14%)** with a loss of ₹1,494 Cr (company filings). In November 2025 Flipkart dropped commission on goods under ₹1,000, which it said would cut sellers' costs by about 30% in that price range. It moved its holding company back to India (a "reverse flip") in March 2026 ahead of a listing that has now slipped, possibly to 2028. Several senior leaders left in 2025–26.

**Moat.** Brand and scale in smartphones and large appliances. Exclusive phone launches. Walmart's backing. Its weaknesses are growth slower than the market, losses, and competition from both value marketplaces (Meesho) and quick commerce for the everyday purchases that build frequency.

```dia
title: Flipkart versus Amazon: two strategies for one market
versus("Flipkart", [("Customer", "Value-seeking, Bharat, sale-driven"), ("Hero category", "Smartphones and appliances"), ("Loyalty", "Sales, EMI, exchange offers, Flipkart Black"), ("New bets", "Shopsy, Minutes, super.money")], "Amazon India", [("Customer", "Metro, Prime households"), ("Hero category", "Everything, delivered reliably"), ("Loyalty", "Prime: shipping + video + music"), ("New bets", "Amazon Now, Alexa for Shopping, Bazaar")], verdict="Flipkart wins big moments; Amazon wins everyday habit. Both now fight quick commerce for the habit and Meesho for the price.")
```

**Metrics.** *North Star:* annual transacting users. *Inputs:* purchases per user outside sale periods, share of GMV from non-phone categories, Pay Later users, Minutes orders. *Guardrails:* return and RTO rate, seller satisfaction, sale-day uptime.

::: key What I would build next at Flipkart
1. **"Sale-proof" price trust.** *Problem:* users suspect prices are raised before a sale and then "discounted". *Bet:* show the 90-day price history on every sale item. *Metric:* sale conversion; complaints about fake discounts.
2. **Phone lifecycle programme.** *Problem:* users buy a phone every 2–3 years and forget Flipkart in between. *Bet:* protection plan + repair + guaranteed buy-back value, with reminders to upgrade. *Metric:* repeat phone purchases; protection attach rate.
:::

%% article | E-commerce · Myntra | The vertical that became a profit machine | Myntra, owned by Flipkart, sells one thing (fashion and beauty) to one kind of customer. In FY25 its profit rose eighteen-fold.

**Who it is for.** Fashion-conscious shoppers aged about 18–35, in metros and, increasingly, in smaller cities: more than 70% of Myntra's new customers in 2025 came from outside the metros. Positioning: *"India's fashion destination"*, mid-to-premium and brand-led, distinct from Flipkart's value focus.

**Core loop.** Discover (feed, creators, trends) → try (size help, try-on) → buy → return if it does not fit → come back for the next occasion. Fashion is visual and driven by occasions, so Myntra works like a **media product** as well as a store: it gives users a reason to browse even when they do not need anything.

```dia
title: Myntra product page, annotated
sub: The page's job is to prevent a return before the order is placed
phone([("Image gallery + video", 1.8), ("Brand · price · discount", 0.5), ("Size chart + 'Fits true to size' (from returns)", 0.8, "#DCEFE0"), ("Try-on / similar styles", 0.7), ("Delivery by date · M-Now 30-min badge", 0.5, "#F6E6B8"), ("Wishlist · Add to bag", 0.5, "#F6D9D7")], [(0, "Many images", "Fashion is judged by eye; more angles mean fewer surprises."), (2, "Size advice from data", "Fit feedback from past buyers cuts size-related returns. Metric: return rate."), (1, "Discount shown clearly", "Fashion shoppers are deal-driven; sale events like EORS matter."), (4, "Speed on some items", "M-Now delivers fashion in about 30 minutes in 10 cities."), (5, "Wishlist as intent", "Wishlists feed price-drop alerts and sale reminders.")])
```

| Feature | User problem | Why designed this way | Metric |
|---|---|---|---|
| EORS (End of Reason Sale) | "I wait for sales to buy brands" | Twice-yearly sale; 2026 edition from 29 May | Sale GMV, new users |
| Size and fit advice | "It won't fit and I'll have to return it" | Fit data from past buyers and returns | Return rate |
| M-Now (30-minute fashion) | "I need an outfit for tonight" | Dark stores with ~10,000 styles in 10 cities | Occasion orders, frequency |
| FWD and creator content | Gen Z: "I discover fashion on Instagram" | Trend feed and a creator programme inside the app | Sessions per user |
| Brand ads | Brands: "I need visibility at launch" | Sponsored listings and banners | Ad revenue (+28% in FY25) |

**Business model.** FY25 operating revenue was **₹6,043 Cr (+18%)** and net profit **₹548 Cr, up 18-fold** (Inc42). Revenue came from marketplace fees (₹2,052 Cr), logistics services charged to sellers (₹2,919 Cr) and **advertising (₹915 Cr, +28%)**. Ads are the main driver of profit growth.

```dia
title: Where the money goes on a ₹1,000 fashion order
sub: ₹ per order, illustrative; returns are the line that makes fashion hard
src: Illustrative; revenue mix direction from Myntra FY25 filings (Inc42)
waterfall([("Commission and fees", 180, "From the brand or seller"), ("Logistics fees", 50, "Charged to seller"), ("Ads", 40, "Brand pays for visibility"), ("Forward shipping", -80, ""), ("Returns", -60, "Reverse pickup, re-check"), ("Discounts", -35, "Platform share of sale offers"), ("Payments, tech, support", -35, "")], total="Contribution", takeaway="Cutting return rates by a few points is worth more than most new features.")
```

**Moat.** Brand relationships (exclusive labels and launches), a clear fashion identity, and fit data that improves with every return. It is also protected from being a pure price competitor because it sells brands, not commodities.

**Metrics.** *North Star:* net GMV after returns. *Inputs:* monthly transacting users, orders per user, AOV, return rate, ad revenue per brand. *Guardrails:* customer NPS on returns, delivery promise accuracy, ad load in the feed.

::: key What I would build next at Myntra
1. **Occasion planner.** *Problem:* shoppers buy for weddings, festivals and trips, and search one item at a time. *Bet:* an "occasion" mode that builds a full look within budget with delivery by a date. *Metric:* items per order; conversion of occasion sessions.
2. **Fit profile you carry across brands.** *Problem:* sizes differ by brand. *Bet:* a personal fit profile that translates your size for every brand. *Metric:* size-related returns; first-purchase conversion with new brands.
:::

## Comparing the three

| | Amazon India | Flipkart | Myntra |
|---|---|---|---|
| Core customer | Metro, Prime households | Value-seeking, Bharat, phones | Fashion-conscious, 18–35 |
| Loyalty engine | Prime | Sales, EMI, exchange | Sales (EORS), content |
| Profit drivers | Seller fees, ads, Prime | Seller fees, ads, fintech | Fees, logistics, ads |
| Speed bet | Amazon Now | Flipkart Minutes | M-Now |
| Main threat | Quick commerce, Meesho | Meesho, quick commerce, IPO delay | Returns, Instagram-native brands |

```dia
title: Category breadth versus price positioning
sub: Where each player sits (author's judgement)
matrix("Price positioning (value → premium)", "Category breadth", [("Everything, cheap", "Meesho, Shopsy, Amazon Bazaar"), ("Everything, trusted", "Amazon, Flipkart"), ("Niche, cheap", "Value fashion sites"), ("Niche, premium", "Myntra, Nykaa")], xends=("Value", "Premium"), points=[("Meesho", 0.15, 0.62), ("Flipkart", 0.45, 0.6), ("Amazon", 0.7, 0.66), ("Myntra", 0.72, 0.22)])
```

## Likely interview questions

1. **"Cart additions have declined 10% on Amazon. Diagnose."** (IIMA casebook) Is the fall in sessions, product views or add-to-cart rate? Check prices, stock, a UI change, and competitor sales.
2. **"Amazon wants to cut Prime's price. Should it?"** (IIMA casebook) Look at elasticity by segment, the cost of benefits, and cannibalisation. Test a cheaper tier instead of cutting the main price.
3. **"How would you reduce returns on Myntra?"** Target size-related returns first with fit data, better images and reviews. Guardrail: conversion rate.
4. **"Should Flipkart compete with Meesho on price?"** Shopsy lets it compete without cheapening the main brand. Watch seller quality and fraud.
5. **"What should Amazon measure for Alexa for Shopping?"** Conversion after an assistant session versus search alone, and answer accuracy. Guardrail: returns on assistant-led purchases.
6. **"Design Big Billion Days for a first-time user from a small town."** Pre-sale education, EMI eligibility checks, a vernacular walkthrough and COD trust signals.

::: quiz Recall: e-commerce
1. Why must Amazon and Flipkart run marketplaces rather than own inventory in India?
2. Draw Amazon's flywheel from memory and explain the role of "lower cost structure".
3. What is RTO, and why does cash on delivery raise it?
4. Which revenue line drove Myntra's profit growth in FY25?
5. Why did Amazon and Flipkart remove fees on low-priced items in 2025–26?
6. Give Myntra a North Star and two guardrails, and explain why returns are central.
7. (Quick commerce) How is Amazon Now's strategy different from Zepto's?
:::
