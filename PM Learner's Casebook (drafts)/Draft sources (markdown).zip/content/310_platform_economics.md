%% chapter | Technology · Platform economics | Why the big get bigger | Network effects, two-sided pricing, switching costs and multihoming: the economic forces that explain how digital platforms grow, compete and sometimes dominate

Imagine you launch a food-delivery app in Pune with a genuinely better design than Swiggy and Zomato. Restaurants will not list with you because you have no customers. Customers will not download you because you have no restaurants. Riders will not join because there are no orders. Your better app is irrelevant. This is the central fact of platform economics: **for a platform, the product is largely the other people on it.**

A **digital platform** creates value by connecting groups who want to interact: buyers and sellers (Flipkart, Meesho), riders and drivers (Uber, Rapido), diners, restaurants and delivery partners (Zomato, Swiggy), viewers and creators (YouTube), users and advertisers (Google, Instagram), app users and developers (Apple's App Store). Three forces shape how they grow and compete: **network effects, differentiation and switching costs, and multi-sided pricing.**

## Network effects: more users, more value per user

A **network effect** exists when each user gets more value as more users join. A telephone is useless if you own the only one. WhatsApp is valuable because everyone you know is on it.

```dia
title: The cross-side network effect flywheel
sub: The engine behind marketplaces from Airbnb to Swiggy
loop([("More diners", "Order more often, in more areas"), ("More orders per restaurant", "Listing becomes worth it"), ("More restaurants", "Wider choice, more cuisines"), ("More orders per rider", "Riders earn more per hour; faster delivery"), ("Better experience", "Choice + speed attract more diners")], center="Network effects", center_desc="Each side makes the platform more valuable for the other", edges=["", "", "", "", ""])
```

Network effects come in different kinds, and the kind decides how defensible a platform is.

```dia
title: Two dimensions of network effects
matrix("Scale of the effect: local → global", "Side: same-side → cross-side", [("Cross-side, local", "Buyers and sellers must be in the same city. Uber, Ola, Swiggy, Urban Company: must win city by city, rivals can attack one city at a time."), ("Cross-side, global", "Supply is valuable to users everywhere. Airbnb hosts, YouTube creators, App Store developers: a lead compounds worldwide."), ("Same-side, local", "Value from peers nearby. Nextdoor-style community apps, local classifieds, a college's group chats."), ("Same-side, global", "Value from peers anywhere. WhatsApp, Instagram, LinkedIn, multiplayer games.")], points=[("Swiggy", 0.2, 0.6), ("Airbnb", 0.8, 0.6), ("WhatsApp", 0.8, 0.14)])
```

- **Same-side** effects: value rises as more *peers* join (Instagram is better when your friends are on it).
- **Cross-side** effects: value rises as more of the *other* side joins (more Airbnb hosts attract more guests, and vice versa).
- **Local** effects are confined to a geography or segment. They are more contestable: Uber faces a strong local rival in almost every country it enters, because a driver in Pune does nothing for a rider in Jakarta.
- **Global** effects travel: a new host in Goa makes Airbnb more attractive to travellers in London.

A third kind, **data network effects**, arises when more usage improves the product itself: more Google Maps users mean better live traffic data, which means better ETAs for everyone.

Network effects follow an **S-curve**. Early on, value grows slowly because there are too few users to matter; that is the **cold start**. Past a **critical mass**, each new user adds noticeably to everyone's value and growth feeds on itself. Eventually the benefit saturates; the millionth restaurant in Mumbai adds little. Network effects can also turn **negative** through congestion: too many sellers make search noisy, too many riders idle and earn less, too many members spam a group.

```dia
title: The S-curve of network value
sub: Value to each user as the network grows (illustrative)
linechart({"Value per user": [2, 3, 5, 9, 18, 34, 52, 64, 70, 72]}, ["1k", "5k", "20k", "50k", "1L", "2L", "5L", "10L", "20L", "50L"], notes=[("Value per user", 1, "Cold start: subsidise"), ("Value per user", 4, "Critical mass: growth feeds itself"), ("Value per user", 8, "Saturation: congestion risk")])
```

## Differentiation: what makes users pick you

Sustainable differentiation lives **in the customer's perception**, not in internal process improvements. If Uber builds a new algorithm that improves cab availability but riders cannot tell the difference between Uber and Ola, Uber has not differentiated itself.

```dia
title: Two kinds of differentiation
versus("Horizontal: different, not better", [("Idea", "Serves different tastes or identities."), ("Examples", "Reddit's niche communities; a job board only for designers; a gaming-first chat app versus a work chat app."), ("Effect", "Creates loyal segments; limits the size of each.")], "Vertical: objectively better", [("Idea", "Everyone agrees it is better: lower search cost, more trust, better matches, faster delivery."), ("Examples", "Faster delivery, verified sellers, easy returns, better search."), ("Effect", "Wins broad share, but rivals can often copy it.")], verdict="Platforms usually win on vertical quality and trust, then cement the lead with horizontal community and identity.")
```

Two levers dominate:

**The cost of convergence.** Copying a digital product's core features is cheap. Instagram launched Stories in 2016, a near-copy of Snapchat's signature feature, and quickly overtook it. If a rival can copy your advantage in a quarter, it is not an advantage. Late entrants win by differentiating on something hard to copy (supply, community, trust, a niche) rather than fighting a pure scale war.

**Switching costs.** Raise the real cost of leaving (time, money, convenience, lost benefits) by making staying genuinely better, not by trapping users with dark patterns.

```dia
title: Healthy switching costs a platform can build
cards([("Reputation and history", "A seller's 4.8 rating from 12,000 reviews, a driver's track record: not portable to a rival."), ("Workflow integrations", "Catalogues, APIs, payments, logistics, invoicing built around the platform: painful to rebuild elsewhere."), ("Loyalty and financial hooks", "Memberships (Swiggy One, Flipkart Plus), fast payouts, working-capital loans to sellers: benefits that accrue over time."), ("Social graphs", "Followers, groups, message history: your community lives here."), ("Personalisation and saved data", "Preferences, addresses, playlists, watch history that make the experience better the longer you stay.")], ncol=3)
```

## Pricing in multi-sided markets

On a platform, the right price for one side depends on the other side. Platforms set **asymmetric prices**: they usually **subsidise the side that is more price-sensitive or that attracts the other side**, and **charge the side that values access more**. Google search is free to users; advertisers pay. Most payment apps are free to consumers; merchants or other revenue lines pay. Food-delivery apps charge restaurants a commission and charge diners delivery and platform fees, with the balance shifting over time.

The split changes over the life cycle: heavy subsidies at launch to cross the cold start (the cashback wars of India's early UPI and wallet days, first-ride-free offers), then a gradual taper as network effects take over. Regulation can fix one side's price: in India, merchant fees (MDR) on most UPI payments have been set at zero since January 2020, which is one reason UPI apps monetise through lending, ads and other services instead of per-payment fees.

## Competition: multihoming, bottlenecks and tipping

**Multihoming** means using several competing platforms at once. Many Indian restaurants list on both Swiggy and Zomato; many drivers keep Uber, Ola and Rapido open; shoppers compare prices across apps. Where users *and* suppliers multihome easily, rivalry stays active and take rates stay in check.

A **competitive bottleneck** arises when one side is locked in. iPhone owners effectively single-home on Apple's App Store, so developers who want to reach them have no alternative; that is how Apple could charge up to 30% commission for years, a level that would be hard to sustain with several competing app stores on the same phone. That power is now under regulatory pressure in several jurisdictions.

**Expectations and tipping.** Users join the platform they expect others to join. That can stall a launch (nobody wants to be first) or accelerate dominance once momentum builds and the market "tips" to one player. Announcing supply commitments, exclusive partnerships or big user numbers is partly about shaping expectations.

```dia
title: How contestable is the market?
scale("Easy to contest", "Winner takes most", [("Ride-hailing in a city", 0.22, "Drivers and riders multihome; local effects"), ("Food delivery", 0.4, "Restaurants multihome; users are price-sensitive"), ("E-commerce marketplace", 0.55, "Scale in logistics and trust helps"), ("Messaging (WhatsApp)", 0.8, "Groups are hard to move"), ("Mobile app store", 0.97, "Locked to one store")], lnote="Multihoming, local effects, low switching costs", rnote="Single-homing, global effects, high switching costs")
```

## Strategic issues every platform PM faces

**The launching problem.** How do you overcome the cold start? Options: subsidise one side; seed supply yourself (early Reddit founders posted content under many accounts; marketplaces often recruit the first sellers by hand); start with a **single-player utility** that is useful before any network exists (OpenTable gave restaurants reservation software first; Instagram's filters were worth using even with no followers); or launch in a tight niche and expand (Facebook started with one college). Expect to burn cash until critical mass.

**Surplus and value capture.** In a competitive market, value is split between consumers and producers. Platforms use **price discrimination** (auctions for ad slots, personalised offers, tiered seller fees) to capture more of it. Strong network effects raise users' willingness to pay, which increases total value, and a powerful, well-governed platform can claim a large share of it. Push too hard and suppliers leave or regulators step in.

**Marketplace or reseller?** A pure **marketplace** connects third-party sellers; it scales breadth with little capital and earns a take rate. A **reseller** or **hybrid** model buys inventory and sells it; it controls quality, speed and margin on selected lines but ties up capital. In India, rules on foreign direct investment allow foreign-owned e-commerce firms to operate only as marketplaces, not inventory-led retailers, which shapes how Amazon and Flipkart structure their businesses.

**Platform leakage.** Once a customer finds a good electrician through Urban Company, why not call him directly next time and skip the fee? Platforms prevent leakage by making on-platform transactions **strictly safer or better**: payment protection, escrow, insurance or warranty on the job, dispute resolution, verified professionals, loyalty benefits.

::: key The one-line rule
A platform's value is the network, not the app. Win by crossing critical mass on the hardest side first, pricing each side for the value it gets and the value it brings, and making it genuinely better to stay and transact on-platform.
:::

**Contrasting case.** Not every digital business has strong network effects. A calculator app, a single-brand D2C store or most SaaS tools gain little when other people join. Claiming "network effects" for them in an interview is a red flag; say "economies of scale" or "brand" instead.

**Why a PM cares.** Platform economics decides which side to prioritise in the roadmap (usually the scarce side), which metrics matter (liquidity: the share of searches that end in a transaction; fill rate; time to match), how to price, and where the defensible moat is. It also tells you when a feature war is pointless: if both sides multihome, a copied feature changes little.

**In the interview.** "How would you launch a new marketplace in a city?" (pick the hard side, seed supply, narrow the geography to reach density, single-player value, subsidise with an exit plan), "Why does Uber struggle to be profitable in some cities?" (local, cross-side effects; multihoming drivers and riders; price competition), "Is Instagram's moat network effects or something else?" (same-side global effects plus creator supply, data and habit), "Should Zomato raise restaurant commissions?" (multihoming, restaurants' alternatives such as ONDC and direct ordering, elasticity, leakage risk). A strong line: *"In a two-sided market, I'd first ask which side is scarce. Growth spend on the abundant side is wasted until the scarce side is fixed."*

::: quiz Check yourself
1. Distinguish same-side from cross-side, and local from global, network effects, with one Indian example of each.
2. Sketch the S-curve and label cold start, critical mass and saturation. What is a negative network effect?
3. Why was Uber's internal algorithm improvement not 'differentiation'? What is the cost of convergence?
4. Name four healthy switching-cost levers, and one dark pattern you would avoid.
5. Why do platforms subsidise one side, and how does the subsidy change over time?
6. Explain multihoming and a competitive bottleneck using food delivery and app stores.
7. Give three ways to solve the cold-start problem.
8. *(From the AI chapter)* An AI feature makes a marketplace's search better for every user as more people use it. What kind of network effect is that?
:::
