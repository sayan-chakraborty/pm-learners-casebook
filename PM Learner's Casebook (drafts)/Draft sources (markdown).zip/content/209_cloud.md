%% chapter | Product dossier · Cloud | Renting the world's computers by the second | AWS, Microsoft Azure and Google Cloud run most of the internet you use. You do not need to be an engineer to understand what they sell, how they make money, and why AI has made their race the most expensive in business history.

A Bengaluru start-up appears on *Shark Tank India* on a Monday night. Within ten minutes, traffic to its app is fifty times normal. In 2006 that would have crashed the website: the company owned four servers in a rented rack, and buying more took weeks. Today its cloud provider notices the surge, starts forty more servers in seconds, and shuts them down at midnight when the traffic fades. The start-up pays for exactly those two hours. That is the cloud: **computers, storage and software rented over the internet, by the second, and paid for like electricity.**

## Explain it like I'm not an engineer

```dia
title: The cloud in everyday terms
analogy([("Using the power grid instead of running your own diesel generator", "Cloud computing", "Rent computing power from a provider instead of owning servers; pay for what you use"), ("A hotel room versus buying a flat", "Pay-as-you-go versus capital expenditure", "No big upfront cost; you can check out any time. Long stays are cheaper with a commitment (reserved capacity)"), ("A bank locker in many cities", "Regions and availability zones", "Data centres in Mumbai, Hyderabad and elsewhere; copies in separate buildings so one fire does not take you down"), ("Moving house with all your furniture", "Data gravity and egress fees", "Moving large amounts of data out of a cloud is slow and costs money, which keeps customers in place"), ("Hiring a cook versus buying a meal kit versus ordering in", "IaaS, PaaS, SaaS", "How much of the work the provider does for you")])
```

```dia
title: What the cloud sells, layer by layer
sub: Higher layers do more of the work for you and cost more per unit
layers([("AI services", "Rent AI models and GPUs: call Gemini, GPT or Claude through an API", "A bank's chatbot built on Bedrock or Vertex AI"), ("SaaS: software", "Finished software you just log into", "Gmail, Microsoft 365, Salesforce"), ("PaaS: platforms", "Managed databases, serverless functions: no servers to manage", "A start-up's database on Amazon RDS"), ("IaaS: infrastructure", "Raw virtual computers, storage and networking", "Renting 40 servers for a Shark Tank night"), ("Physical layer", "Data centres, chips, power, undersea cables", "AWS's Mumbai and Hyderabad regions")])
```

```dia
title: What the cloud does when you open a food app at 8 p.m.
sub: Five services from one provider, used in under a second
src: Simplified; typical architecture for a consumer app
steps([("Find the server", "DNS turns the app's address into the nearest data centre", ""), ("Serve images fast", "A CDN sends menu photos from a nearby city", "Slow images lose orders"), ("Share the load", "A load balancer spreads millions of requests across servers", ""), ("Add servers at peak", "Auto-scaling adds servers at dinner, removes them at 11 p.m.", "Pay only for peak hours"), ("Read the data", "A managed database returns your address and past orders", "One slow query slows everyone")], hl=[3])
```

**How a cloud company makes money.** Customers pay per unit used: per hour of a server, per gigabyte stored, per million AI tokens processed. Large customers sign **multi-year commitments** in return for discounts. Those commitments become the provider's **backlog**, revenue it is contracted to earn later. The cost side is dominated by **capital expenditure** on data centres, chips and power. That is why the AI boom has pushed the big three to spend tens of billions of dollars a quarter.

## The market

```dia
title: Who rents out the world's computers
sub: Share of global cloud infrastructure spending, Q2 2026 (%)
src: Synergy Research Group, Q2 2026 (via 16IDC / The Register). Market $143.4B in the quarter, +43% YoY, the fastest growth in eight years
stack100([("Q2 2026", [("AWS", 28), ("Microsoft Azure", 20), ("Google Cloud", 15), ("Everyone else", 37)])], note="'Everyone else' includes Alibaba, Oracle and fast-growing 'neoclouds' such as CoreWeave. Generative-AI cloud services grew 165% YoY.")
```

```dia
title: How fast each is growing
sub: Latest quarterly revenue growth, year on year (%)
src: Amazon Q2 2026; Microsoft FY26 Q4 (Apr–Jun 2026); Alphabet Q2 2026. Google Cloud includes Workspace
bars([("AWS", 37, "$42.2B quarter; fastest growth in 18 quarters"), ("Azure", 43, "Passed $100B annual revenue in FY26"), ("Google Cloud", 82, "$24.8B quarter; $514B backlog")], unit="%", hl=[2])
```

AI changed the race. Before 2023, the contest was about moving companies' existing software to the cloud. Now it is also about who can supply the **GPUs and AI chips** to train and run models, and who has the best models on their platform. The smallest of the three is growing fastest because of that shift.

%% article | Cloud · Amazon Web Services (AWS) | The one that invented the category | AWS began by renting out Amazon's own spare infrastructure. Twenty years later it is the largest cloud and most of Amazon's profit.

**Who it is for.** Start-ups and enterprises that want the widest set of building blocks: from Indian start-ups like Swiggy and Zepto to banks and governments. Positioning: *"the broadest and deepest set of cloud services."* It was first to market in 2006 with S3 (storage) and EC2 (rentable servers), and it has kept the start-up community's loyalty since.

**Core loop.** A start-up gets free credits → builds on AWS → grows → its bill grows with it → AWS's scale lets it cut prices and add services → more start-ups choose AWS. This is the same flywheel as Amazon retail, applied to computing.

**First run.** Create an account with a card, get a free tier (small servers and storage free for a year) and, for start-ups, credits through AWS Activate. The console is powerful but overwhelming, with 200+ services. That is AWS's classic weakness for newcomers, now being softened with AI assistants.

| Service | What it does in plain words | Problem it solves | Metric it moves |
|---|---|---|---|
| EC2 | Rent virtual computers by the second | "I need servers now, not in six weeks" | Compute usage |
| S3 | Store any amount of files cheaply, forever | "Where do I keep 10 crore photos?" | Stored data (it attracts other services) |
| RDS, DynamoDB | Databases AWS runs and backs up for you | "I don't want to hire a database admin" | Managed-service revenue |
| Lambda (serverless) | Run a bit of code only when something happens | "I don't want idle servers" | Developer adoption |
| CloudFront | Copies content close to users | "The video loads slowly in Patna" | Latency, data transfer |
| Bedrock, Trainium | Choose among AI models (including Anthropic's Claude); Amazon's own AI chips | "I want AI without building a model" | AI revenue, cost per token |

**Business model.** AWS's **Q2 2026 revenue was $42.2 billion, up 37%**, its fastest growth in 18 quarters (Amazon Q2 2026). It earns most of Amazon's operating profit. It has committed to large investments in India's cloud regions this decade.

**Moat.** **Switching costs** (data gravity, egress fees, engineers trained on AWS). **Scale economies** in buying chips, power and land. **Ecosystem**: thousands of partners and certified engineers. Its risk is **reliability at scale**. A major outage in AWS's US-East region in October 2025 took down many popular apps for hours, a reminder that concentration is a risk for customers too.

**Metrics.** *North Star:* consumption revenue from active customers. *Inputs:* new active accounts, net revenue retention, services per customer, backlog. *Guardrails:* availability (minutes of downtime), cost-per-unit trends, security incidents.

::: key What I would build next at AWS India
1. **"Cost copilot" for start-ups.** *Problem:* Indian start-ups routinely overspend on idle servers. *Bet:* an assistant that finds waste each week and applies fixes with one click. *Metric:* retention of start-up accounts after credits expire (guardrail: short-term revenue dip).
2. **DPDP-ready compliance kit.** *Problem:* India's data-protection rules add consent and data-residency work. *Bet:* ready-made templates for consent logs, data mapping and breach reporting. *Metric:* regulated-industry customers onboarded.
:::

%% article | Cloud · Microsoft Azure | The enterprise's default | Azure wins where companies already run on Microsoft, and it won early access to OpenAI's models. That combination made it the second-largest cloud.

**Who it is for.** Large enterprises and governments already using Windows servers, Active Directory, Office and Teams. Positioning: *"the cloud for the enterprise you already are."* Azure is sold by Microsoft's huge enterprise sales force, often together with Microsoft 365 licences.

**Core loop.** A company uses Microsoft 365 → signs an enterprise agreement → moves its Windows and SQL servers to Azure (discounts for existing licences) → adds Azure OpenAI and Copilot → more of its spending goes to Microsoft.

| Product | Plain words | Problem it solves | Metric |
|---|---|---|---|
| Azure Virtual Machines and SQL | Rent servers and databases; bring your existing Microsoft licences | "We run on Windows; moving should be easy" | Migrations, consumption |
| Azure Arc (hybrid) | Manage your own servers and Azure from one place | "Some data must stay on our premises" | Regulated-industry wins |
| Azure OpenAI / AI Foundry | OpenAI's and other models with enterprise security | "We want GPT, but inside our compliance rules" | AI consumption |
| Microsoft 365 Copilot | AI assistant in Word, Excel, Teams | "Help my employees work faster" | Paid seats (30M+) |

**Business model.** Azure grew **43%** in the April–June 2026 quarter and **passed $100 billion of annual revenue** in fiscal 2026. Microsoft Cloud revenue was **$59.3 billion** in the quarter (Microsoft, Jul 2026). Its partnership with OpenAI was restructured in 2025: Microsoft keeps a large stake, and OpenAI committed to buy a very large amount of Azure capacity.

**Moat.** **Bundling and switching costs**: identity (Active Directory), Office, Teams and Azure are sold as one relationship. **Branding** with CIOs, whose line is *"nobody gets fired for buying Microsoft."* The risk is **dependence on OpenAI** and the cost of AI capacity.

**Metrics.** *North Star:* Azure consumption revenue. *Inputs:* enterprise migrations, AI services consumption, Copilot seats, share of customers using 3+ Azure services. *Guardrails:* capacity shortfalls (customers waiting for GPUs), gross margin on AI services.

::: key What I would build next at Azure
**Copilot usage-to-Azure bridge.** *Problem:* companies buy Copilot seats but cannot connect their own data safely. *Bet:* a guided "connect your data" flow that sets up search and permissions on Azure in a day. *Metric:* Copilot weekly active seats; Azure AI consumption per Copilot customer.
:::

%% article | Cloud · Google Cloud | The data-and-AI specialist that became the fastest grower | Google Cloud was a distant third for years. Its own AI chips and Gemini models turned it into the fastest-growing cloud of 2026.

**Who it is for.** Data-heavy digital companies, media firms, retailers, and AI builders, including AI labs. Positioning: *"the cloud built by the company that invented modern AI."* Its engineering reputation, BigQuery data warehouse and TPUs are the draws.

| Product | Plain words | Problem it solves | Metric |
|---|---|---|---|
| BigQuery | Ask questions of huge data sets in seconds, no servers to manage | "Our analysts wait hours for reports" | Data stored and queried |
| Vertex AI and Gemini | Build with Google's models and others | "We want AI built on our own data" | AI consumption |
| TPUs | Google's own AI chips, rentable | "GPUs are scarce and expensive" | AI capacity revenue |
| Workspace | Gmail, Docs, Meet for businesses | "Collaboration tools" | Seats (reported inside Google Cloud) |

**Business model.** Q2 2026 revenue was **$24.8 billion, up 82%**, with a **backlog of $514 billion** and a record **15% market share** (Alphabet Q2 2026; Synergy). The backlog comes from large multi-year AI capacity contracts. Google also announced a large AI data-centre hub in Visakhapatnam, India, in 2025.

**Moat.** **Cornered resource**: its own chips (TPUs) and frontier models (Gemini). **Scale economies** inherited from running Search and YouTube. The weaknesses are a smaller enterprise sales force and partner network than Microsoft's.

**Metrics.** *North Star:* consumption revenue. *Inputs:* backlog conversion to revenue, AI customers, BigQuery active users. *Guardrails:* capacity delivery on time, customer concentration (a few AI labs are a big share).

::: key What I would build next at Google Cloud India
**Indic-language AI starter packs.** *Problem:* Indian enterprises want chatbots in 10+ languages. *Bet:* ready templates for support, collections and sales in Indian languages on Gemini, priced per resolved conversation. *Metric:* Indian enterprise AI customers; cost per resolution.
:::

## Comparing the three

| | AWS | Azure | Google Cloud |
|---|---|---|---|
| Positioning | Broadest services, builders' choice | Enterprise default, Microsoft bundle | Data and AI specialist |
| Share (Q2 2026) | 28% | 20% | 15% |
| Growth | +37% | +43% | +82% |
| AI edge | Bedrock (many models), Trainium chips | OpenAI partnership, Copilot | Gemini, TPUs |
| Main moat | Scale, ecosystem, switching costs | Bundling, enterprise relationships | Chips + models (cornered resource) |
| Main risk | Losing the AI narrative; outages | OpenAI dependence; capacity | Enterprise reach; customer concentration |

```dia
title: Control versus convenience
sub: The trade-off every company makes when choosing how to use the cloud
scale("Full control, more work", "Less work, less control", [("Own data centre", 0.05, "Maximum control; big capex"), ("IaaS servers (EC2, VMs)", 0.32, "You manage the software"), ("Managed databases, serverless", 0.62, "Provider runs the plumbing"), ("SaaS and AI APIs", 0.92, "Just use it; pay per seat or token")], lnote="Chosen by banks with strict rules, or at huge scale", rnote="Chosen by start-ups that want speed")
```

## Likely interview questions

1. **"Explain cloud computing to your grandmother."** Use the power-grid or hotel analogy, then one concrete example (IRCTC Tatkal traffic at 10 a.m.).
2. **"You are PM for a cloud database. What is your North Star?"** Active databases with real usage, or consumption revenue. Guardrails: availability and cost per query.
3. **"Why is Google Cloud growing fastest?"** AI demand, own chips (TPUs), Gemini and large backlog contracts, starting from a smaller base.
4. **"Should a start-up go multi-cloud?"** Usually not early. It adds complexity. It makes sense at scale, for bargaining power with providers or to satisfy regulators.
5. **"How would you price a new AI service?"** Per token or per outcome, with committed-use discounts. Watch gross margin against GPU cost.
6. **"AWS had a major outage. You're the PM. What now?"** Communicate first, then root cause, then a customer credit policy, then design changes that stop one region's failure from spreading.

::: quiz Recall: cloud
1. Explain IaaS, PaaS and SaaS with one everyday analogy and one example each.
2. What is "data gravity", and how does it create switching costs?
3. What is a backlog, and why does Google Cloud's matter?
4. Give one reason each for AWS's, Azure's and Google Cloud's advantage in AI.
5. Why does cloud growth require such large capital expenditure?
6. Place three kinds of customers on the control-versus-convenience scale.
7. (Social) How does Meta's AI spending relate to the cloud race?
:::
