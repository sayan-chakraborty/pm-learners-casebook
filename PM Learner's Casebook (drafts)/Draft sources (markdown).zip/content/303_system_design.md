%% chapter | Technology · System design | Building for a million people at 10 am | The building blocks engineers use to make products fast, reliable and affordable at scale, explained with the trade-offs a PM has to call

At 9:59 am, IRCTC is quiet. At 10:00 am, Tatkal booking opens for AC classes and a large share of the day's most wanted seats are fought over in the next few minutes. IRCTC's own data shows the highest booking volume consistently falls in the first 15 minutes, and on 7 September 2026 it set a record of **20,06,353 tickets in a single day**, after roughly doubling capacity with new servers (Business Today, Sep 2026). A system that is perfectly comfortable at 9:59 has to survive a wall of traffic one minute later, without selling the same berth twice.

That is the whole of system design in one scene: **many users, spiky demand, data that must stay correct, and a budget**. This chapter explains the building blocks engineers use, one at a time, with the question each one answers and the trade-off each one forces. The next chapter puts them together in three worked designs.

```dia
title: The building blocks, and the question each one answers
sub: Keep this map in mind; each block gets its own section below
arch({"c": ("Users' apps", "Phones and browsers", "L"), "cdn": ("CDN", "Is the static stuff near the user?", "T"), "lb": ("Load balancer", "Which server takes this request?", "B"), "app": ("App servers (many)", "Stateless copies; add more at peak", "B"), "cache": ("Cache", "Can we answer without the database?", "G"), "db": ("Database + replicas", "Where is the truth kept safely?", "N"), "q": ("Queue", "Can this wait a few seconds?", "M"), "w": ("Workers", "Send SMS, email, invoices", "M"), "obs": ("Monitoring", "Is it healthy right now?", "Y")}, [("c", "cdn", "images, video"), ("c", "lb", "API calls"), ("lb", "app", ""), ("app", "cache", "read"), ("cache", "db", "on a miss", "d"), ("app", "db", "write"), ("app", "q", "later tasks"), ("q", "w", ""), ("app", "obs", "metrics", "d")], rankdir="TB", nodesep=0.25, ranksep=0.35)
```

## How fast is fast? An intuition for latency

Before the blocks, one intuition. Computers do some things unimaginably fast and others painfully slowly, and good design is mostly about avoiding the slow things. Stretch time so that one nanosecond becomes one second, and the differences become human.

```dia
title: If one nanosecond were one second
sub: Typical operation times (order of magnitude), rescaled to human time
src: Based on 'latency numbers every programmer should know' (Jeff Dean, Peter Norvig), updated orders of magnitude; illustrative
analogy([("Reading from the CPU's own cache: 1 ns", "1 second", "Glancing at a note in your hand"), ("Reading from memory (RAM): ~100 ns", "About 2 minutes", "Walking to the next room for a file. Caches like Redis live here."), ("Reading from an SSD: ~100 µs", "About a day", "Ordering the file from another city. A database read that misses memory."), ("Round trip inside one data centre: ~0.5 ms", "About 6 days", "One service calling another. Ten such calls add up."), ("Seek on an old spinning disk: ~10 ms", "About 4 months", "Why databases work hard to avoid disk reads"), ("Round trip Mumbai to US East: ~200 ms", "About 6 years", "Why servers and CDNs must be near Indian users")], lt="Real operation", rt="Stretched time")
```

On the user's side, the classic research-based thresholds still hold: about **0.1 second** feels instant, about **1 second** keeps the user's flow of thought, and past about **10 seconds** you lose their attention (Jakob Nielsen, *Usability Engineering*, 1993). Google reported in 2016 that 53% of mobile site visits were abandoned when a page took longer than three seconds to load.

::: words Latency terms you will hear in reviews
**Latency:** time to answer one request. **Throughput:** requests handled per second (RPS or QPS; TPS for transactions). **p50 / p95 / p99:** the latency that 50%, 95% or 99% of requests beat. An average hides pain: if p50 is 200 ms but p99 is 4 seconds, one user in a hundred waits four seconds, and your heaviest users make the most requests, so they hit it most often. **Latency budget:** the total time allowed for a screen, split across the services it calls.
:::

**Why a PM cares.** You set the budget. "Search results in under 300 ms at p95 on 4G" is a requirement engineers can design for; "make it fast" is not. Every extra service call, round trip or heavy image spends from that budget.

## Databases: where the truth lives

A restaurant keeps two kinds of records. The **order register** must be exact: every bill numbered, every payment matched, nothing lost. The **ideas board** in the kitchen, with notes on what customers liked, can be messy and change shape every week. Databases come in the same two broad kinds.

**Relational (SQL) databases** store data in tables with fixed columns, like a set of linked spreadsheets: a `users` table, an `orders` table, a `restaurants` table, joined by IDs. You query them with **SQL** (Structured Query Language). Examples: PostgreSQL, MySQL, Oracle. Their superpower is correctness, summed up as **ACID**:

```dia
title: ACID, explained with a ₹500 bank transfer
cards([("Atomicity", "All or nothing. Debit Asha ₹500 and credit Ravi ₹500 both happen, or neither does. No money vanishes halfway."), ("Consistency", "Rules always hold. A balance can never go below zero if the rules say so; a broken rule cancels the transaction."), ("Isolation", "Simultaneous transactions don't trip over each other. Two people booking the last berth: only one wins."), ("Durability", "Once confirmed, it stays confirmed, even if the power fails one second later.")], ncol=4)
```

**Non-relational (NoSQL) databases** relax the fixed structure, and often some consistency, in exchange for flexibility and easy scaling across many machines. They come in several shapes:

```dia
title: The main kinds of NoSQL store, and what they are good at
cards([("Key-value", "Look up a value by a key, extremely fast. Sessions, carts, counters. Redis, DynamoDB."), ("Document", "Store flexible JSON-like records; fields can vary. Product catalogues, user profiles. MongoDB."), ("Wide-column", "Huge volumes of writes spread across many machines. Chat messages, event logs, IoT readings. Cassandra."), ("Graph", "Data that is mostly relationships. Social graphs, fraud rings, 'people you may know'. Neo4j."), ("Search index", "Full-text search with typo tolerance and ranking. Product search. Elasticsearch, OpenSearch."), ("In-memory", "Everything in RAM for sub-millisecond reads; used as a cache or for live leaderboards. Redis, Memcached.")], ncol=3)
```

| | SQL (relational) | NoSQL (non-relational) |
|---|---|---|
| Shape | Tables with a fixed schema | Flexible: key-value, documents, columns, graphs |
| Strength | Strong consistency, transactions, complex queries and joins | Scale-out across many machines, fast simple lookups, flexible fields |
| Weakness | Harder to spread across many machines; schema changes need planning | Weaker guarantees; complex queries and joins are harder |
| Use it for | Payments, orders, inventory, bookings, anything involving money | Feeds, chat history, catalogues with varied fields, sessions, analytics events |

Real products use several at once, each for what it does best. That is called **polyglot persistence**. A food-delivery app might keep orders and payments in PostgreSQL, restaurant menus in a document store, the search box on Elasticsearch, live rider locations in Redis, and every tap event in a data warehouse for analytics.

### Indexes: the index at the back of the book

Finding every order by customer 55821 in a table of a billion orders by reading every row would take minutes. An **index** is like the index at the back of a textbook: a sorted list that points straight to the right pages. Queries on indexed columns become thousands of times faster. The price: every new row must also update the index, so writes get a little slower and storage grows. A surprising number of "the app got slow" incidents end with "someone added a query on a column without an index".

### Replication: photocopies in every branch

A single database is a **single point of failure**: if that machine dies, the business stops. **Replication** keeps live copies on other machines. Usually one **primary** accepts all writes and streams changes to several **replicas**, which serve reads. If the primary fails, a replica is promoted.

```dia
title: Primary–replica replication
sub: Writes go to one place; reads are spread across copies
arch({"app": ("App servers", "Order service", "B"), "p": ("Primary database", "Accepts every write", "N"), "r1": ("Replica 1", "Serves reads; standby for failover", "C"), "r2": ("Replica 2 (other zone)", "Survives a data-centre fire", "C")}, [("app", "p", "writes"), ("p", "r1", "copies changes"), ("p", "r2", "copies changes"), ("app", "r1", "reads", "d"), ("app", "r2", "reads", "d")], rankdir="LR")
```

The catch is **replication lag**. Copies take a few milliseconds to seconds to catch up. That is why you sometimes change your delivery address, go back a screen, and still see the old one for a moment: your write went to the primary, your read came from a replica that had not caught up. Good products hide this ("read your own writes" from the primary for a few seconds after a change).

### Sharding: splitting the phone directory into volumes

Replication makes copies of the *same* data. When the data itself is too large, or there are too many writes for one machine, you **shard** (or partition) it: split the data into pieces, each on its own machine. Like splitting a city's phone directory into volumes A–F, G–M, N–S and T–Z.

```dia
title: Sharding orders by customer ID
sub: A router sends each request to the machine that holds that customer's data
arch({"r": ("Shard router", "Looks at customer ID, picks the shard", "B"), "s1": ("Shard 1", "Customers 0–24 million", "N"), "s2": ("Shard 2", "Customers 25–49 million", "N"), "s3": ("Shard 3", "Customers 50–74 million", "N"), "s4": ("Shard 4 (hot!)", "A celebrity or bulk buyer lands here", "R")}, [("r", "s1"), ("r", "s2"), ("r", "s3"), ("r", "s4", "", "r")], rankdir="TB", wrapch=16)
```

The design choice is the **shard key**. Shard by customer and "show this customer's orders" is fast, but "all orders for restaurant X" must ask every shard. Pick badly and you get a **hot shard**: one machine overloaded while others idle, like the queue for the volume containing "Sharma" and "Singh". Sharding is powerful and painful; teams postpone it until they must.

**Why a PM cares.** Database choices shape which features are cheap and which are expensive. "Show all orders across all restaurants for a city, live" might be trivial or might need a new analytics pipeline, depending on how the data is stored. Ask before you promise it.

## Caching: keep the popular dishes warm

A busy dhaba does not cook dal from scratch for every order. It keeps a big pot hot, because most customers order it. A **cache** keeps copies of frequently requested data in fast memory so most requests never reach the slower database.

```dia
title: How a read-through cache answers a request
sub: The goal is a high hit rate; 95% is common for menus and product pages
steps([("Request arrives", "App needs the menu for restaurant 4521", ""), ("Check the cache", "Is the menu in Redis? If yes: a hit, answer in ~1 ms", "Hit: fast and cheap"), ("On a miss, ask the DB", "Read from the database, ~5–50 ms", "Miss: slower, costs DB capacity"), ("Store a copy", "Put the menu in cache with a time-to-live (TTL), e.g. 5 minutes", "TTL = how stale you can tolerate"), ("Next request", "Served from cache until TTL expires or the menu changes", "Invalidate on edit")], hl=[3])
```

Caches exist at every layer: in your browser, on the CDN edge, in the app servers' memory, in a shared store like Redis, and inside the database itself. The hard part is **invalidation**: making sure a changed price or an out-of-stock item is not served from a stale copy. An old engineering joke says there are only two hard things in computer science, cache invalidation and naming things.

A second danger is the **stampede** or **thundering herd**. If a popular cache entry expires at the exact moment a million people ask for it, all million requests fall through to the database at once. Hotstar's engineers faced this during cricket: a big wicket sends millions of viewers back to the home screen at the same second. Their defences included multi-level caching, adding random **jitter** to retries and **exponential back-off** in the app, so requests spread out instead of arriving in one wave (systemdesign.one, on Hotstar's 2019 IPL scaling).

**Why a PM cares.** Caching is the cheapest performance win, but it trades **freshness for speed**. You decide the tolerance: a restaurant rating can be 10 minutes stale; stock in a 10-minute grocery app should be seconds fresh; a payment status must never come from a stale cache.

## Load balancing and scaling

When one server cannot handle the traffic, you have two options, and the difference is one of the most-asked PM interview concepts.

```dia
title: Vertical versus horizontal scaling
versus("Vertical: scale up", [("Analogy", "Replace your delivery van with a bigger truck."), ("How", "Buy a bigger machine: more CPU, more memory."), ("Good", "Simple; no code changes; fine for databases up to a point."), ("Limits", "There is a biggest machine; it is expensive; still one point of failure; upgrading often needs downtime.")], "Horizontal: scale out", [("Analogy", "Add more vans, and a dispatcher to share the orders."), ("How", "Run many identical, ordinary servers behind a load balancer."), ("Good", "Nearly unlimited; if one dies, others carry on; add or remove servers by the hour."), ("Limits", "Servers must be stateless; data layer gets harder; more moving parts.")], verdict="Modern consumer apps scale app servers horizontally and scale databases carefully, often both ways.")
```

A **load balancer** is the dispatcher, or the host at a busy restaurant seating guests across sections. It sits in front of the servers, sends each request to one that has capacity (in turn, **round robin**; to the one with the fewest active connections; or by the user's region), runs **health checks** every few seconds, and stops sending traffic to any server that fails them. For this to work, app servers must be **stateless**: they keep nothing about the user in their own memory between requests (sessions live in a shared cache or a token), so any server can handle any request.

**Auto-scaling** adds servers when load rises and removes them when it falls, so you pay for dinner-time capacity only at dinner time. But new servers take time to start (tens of seconds to minutes). For a spike that arrives in seconds, that is too slow. Hotstar learned this during IPL: rather than rely on auto-scaling, it **pre-warmed** capacity ahead of big matches based on forecasts from past traffic, and built its own scaling logic because the standard tools reacted too slowly (systemdesign.one, 2023). IRCTC faces the same at 10 am daily. Predictable spikes should be scaled for *in advance*.

## Queues and asynchronous processing: the token system

At a busy bank branch you take a token and sit down. The counter serves tokens in order at the speed it can manage, and the crowd does not crush the clerk. A **message queue** does this for software. One part of the system (the **producer**) drops a task in the queue and moves on; another part (the **consumer** or worker) picks tasks up when it has capacity.

```dia
title: What happens synchronously versus asynchronously when you place an order
sub: The user waits only for the part that must be instant; everything else is queued
seq(["App", "Order service", "Queue", "Workers"], [("App", "Order service", "Place order", "User waits while it validates, charges and saves the order: must succeed now"), ("Order service", "App", "Order placed! (~1 s)"), ("Order service", "Queue", "Events: send SMS, email invoice, notify restaurant, update loyalty points", "Drop and move on"), ("Queue", "Workers", "Workers pick up tasks at their own pace", "A slow email provider no longer slows checkout")])
```

Queues give you three things. **Speed for the user**, because slow tasks happen after the response. **Spike absorption**, because a burst of 50,000 orders waits in the queue instead of overwhelming the invoice service. **Resilience**, because if the SMS provider is down, messages wait and are retried rather than lost; tasks that fail repeatedly go to a **dead-letter queue** for humans to inspect. The price is that things become **eventually** done rather than instantly done, and the user experience must say so honestly: "Your refund has been initiated", "Booking under process".

A related tool is an **event stream** such as Kafka: a durable log of everything that happened ("order placed", "rider assigned", "payment failed") that many services can read independently. Analytics, fraud detection and notifications can all react to the same events without the order service knowing they exist.

## Monolith or microservices?

A **monolith** is one big application that does everything: login, catalogue, cart, payments, notifications, all in one codebase and deployed as one unit. **Microservices** split it into many small services, each owning one job and its own data, talking through APIs or events.

```dia
title: Monolith versus microservices
sub: One big kitchen versus a food court of specialised counters
versus("Monolith", [("Good", "Simple to build, test and deploy early on; one codebase to understand; fast calls inside one program."), ("Bad", "As the team grows, everyone steps on each other; one bug can crash everything; must scale the whole thing even if only search is busy."), ("Fits", "Startups, small teams, a new product finding its fit.")], "Microservices", [("Good", "Teams own services end to end and ship independently; scale only the busy parts; a failure can be contained."), ("Bad", "Many network calls (latency, failures); harder debugging; data spread across services; needs strong tooling and on-call culture."), ("Fits", "Large organisations with many teams and uneven load, like Swiggy, Flipkart, Uber.")], verdict="Most companies should start as a well-organised monolith and split out services when team size or scaling pain demands it.")
```

A useful observation called **Conway's law** says systems end up mirroring the communication structure of the organisation that builds them. Microservices are as much an organisational choice (small, autonomous teams) as a technical one. When a PM hears "that needs changes in four services owned by three teams", that is the cost of microservices showing up in the roadmap.

## Consistency versus availability (CAP in plain words)

Imagine a bank with two branches, in Mumbai and Pune, keeping copies of the same ledger and phoning each other after every transaction. One day the phone line is cut. A customer walks into the Pune branch and wants to withdraw ₹10,000. The Pune clerk has two choices:

- **Refuse until the line is back**, because the Mumbai branch may have already paid this customer. The ledger stays correct, but the customer is turned away. That is choosing **consistency**.
- **Pay out anyway** and reconcile later. The customer is served, but the two ledgers may now disagree. That is choosing **availability**.

The **CAP theorem** (Eric Brewer, 2000) formalises this: when a distributed system suffers a network **partition** (P), which in real networks will happen, it must choose between **consistency** (C, everyone sees the same, latest data) and **availability** (A, every request gets an answer). You cannot have both during the split. Even without failures there is a quieter version of the same trade: waiting for all copies to agree adds latency.

```dia
title: Which way should each feature lean?
sub: The same app makes different choices for different data
scale("Prefer consistency (correct or nothing)", "Prefer availability (answer now, fix later)", [("UPI debit & credit", 0.05, "Never double-debit"), ("Last Tatkal berth", 0.15, "Never sell a seat twice"), ("Stock in a dark store", 0.35, "Brief oversell is fixable, costly"), ("Rider location on map", 0.7, "A 5-second-old dot is fine"), ("Like counts", 0.8, "Small lags unnoticed"), ("Feed", 0.97, "Something beats nothing")], lnote="Refuse or wait rather than be wrong", rnote="Show slightly stale data rather than an error")
```

**Strong consistency** means every read sees the latest write. **Eventual consistency** means copies will agree soon, typically within seconds, if no new changes arrive. Most large products are eventually consistent almost everywhere and strongly consistent exactly where money, inventory or safety is involved.

::: key The one-line rule
When the network splits, choose between being right and being responsive. Money and scarce inventory choose right; feeds, counts and locations choose responsive. Naming which data belongs where is a product call.
:::

## Reliability: designing for things to break

Every car has a spare tyre, and planes have two engines, because parts fail. At scale, something is *always* failing: a disk, a server, a network link, a whole data centre. Reliable systems assume this.

**Redundancy** means having more than one of everything that matters: several app servers, replicated databases, servers in more than one **availability zone** (separate data centres in the same region), and for critical systems, more than one region. The enemy is a **single point of failure (SPOF)**, any component whose loss stops everything.

**Availability** is usually stated in "nines". Each extra nine cuts allowed downtime by ten times, and typically costs much more to achieve.

```dia
title: What each level of availability actually allows
sub: Maximum downtime per year
src: Arithmetic: (1 − availability) × 525,600 minutes
bars([("99% ('two nines')", 5256, "≈ 3.7 days a year"), ("99.9%", 525.6, "≈ 8.8 hours a year, 43 min a month"), ("99.95%", 262.8, "≈ 4.4 hours a year"), ("99.99%", 52.6, "≈ 53 minutes a year, 4 min a month"), ("99.999% ('five nines')", 5.3, "≈ 5 minutes a year")], unit=" min", fmt="{:,.0f}", hl=[3])
```

Three terms are often confused:

```dia
title: SLI, SLO, SLA: measure, target, promise
sub: Example: a payments API
pyramid([("SLA: Service Level Agreement", "A contract with customers, with penalties. 'Monthly availability ≥ 99.9% or we refund 10% of fees.' Set looser than the SLO."), ("SLO: Service Level Objective", "The internal target. '99.95% of payment requests succeed within 2 seconds, measured over 30 days.'"), ("SLI: Service Level Indicator", "The measurement itself. 'Share of payment requests that returned success in under 2 s.'")])
```

The gap between 100% and the SLO is the **error budget**. At 99.95%, you may "spend" about 22 minutes of failure a month. While budget remains, teams ship features quickly; when it is spent, they freeze risky launches and fix reliability. This turns the eternal "features versus stability" argument into a number both PM and engineers agreed on in advance. It comes from Google's Site Reliability Engineering (SRE) practice.

**Graceful degradation** means that when part of the system is struggling, the product gets simpler instead of going dark. Hotstar's "panic mode" switched off non-essential features such as personalised recommendations during extreme load so the stream itself kept playing, and streams drop to a lower bitrate rather than stop. A food app under stress can hide "similar restaurants" and keep checkout working. The PM's job is to decide in advance what is **core** (must never break) and what is **nice to have** (can be switched off).

A few more defences you will hear about:

- **Timeouts:** stop waiting for a slow service after a fixed time instead of hanging forever.
- **Retries with exponential back-off and jitter:** try again after 1 s, then 2 s, then 4 s, with a little randomness. Retrying immediately and in unison creates a **retry storm** that finishes off a struggling service.
- **Circuit breaker:** like the fuse in your house. If a dependency keeps failing, stop calling it for a while and use a fallback, so one broken service does not drag others down.
- **Disaster recovery:** backups and a second region, measured by **RPO** (how much data you can afford to lose, e.g. the last 5 minutes) and **RTO** (how long until you are back, e.g. 1 hour).

## Observability: the dashboard of the car

You would not drive at night without a speedometer, fuel gauge and warning lights. **Observability** is how engineers see inside a running system.

```dia
title: The three pillars of observability, and the four golden signals
cards([("Metrics", "Numbers over time: requests per second, error rate, p95 latency, CPU. Cheap to store; power dashboards and alerts.", "#006BA2"), ("Logs", "A diary line for each event: 'order 98812 payment failed: bank timeout'. Detailed; used to investigate.", "#006BA2"), ("Traces", "One request's journey across every service it touched, with time spent in each. Finds the slow link.", "#006BA2"), ("Latency", "How long requests take (watch p95/p99)."), ("Traffic", "How much demand there is."), ("Errors", "How many requests fail."), ("Saturation", "How full the system is: CPU, memory, queue length.")], ncol=4)
```

The four golden signals come from Google's SRE book. On top of these, product teams add **business health metrics** that often catch problems before technical ones do: orders per minute, payment success rate, login success rate, compared with the same minute last week. If orders drop 30% at 8 pm on a Friday, something is broken even if every server looks green.

When something does break, companies run an **incident** process: detect, declare severity, communicate (status page, support scripts), mitigate (roll back, switch off the feature, fail over), then write a **blameless postmortem** that asks "what about the system allowed this?" rather than "who did it?". PMs usually own customer communication and the decision on what to switch off.

## Security basics every PM should know

Security failures are product failures: they break the user's trust in one day. You need five ideas.

**Authentication (AuthN) versus authorisation (AuthZ).** A hotel front desk checks your ID (authentication: *who are you?*) and gives you a key card that opens only your room and the gym (authorisation: *what may you do?*). Login is authentication; "this restaurant owner can edit only their own menu" is authorisation. Stronger authentication uses a second factor (OTP, authenticator app) or **passkeys**, which replace passwords with cryptographic keys stored on your phone. **"Sign in with Google"** uses the **OAuth** standard: like giving a valet a key that starts the car but cannot open the boot, the app gets limited, revocable access without ever seeing your Google password.

**Encryption in transit and at rest.** HTTPS protects data moving across the network; encryption at rest protects data stored on disks and backups. Passwords are never stored at all, only a one-way **hash** of them, so even a stolen database does not reveal them. In India, RBI's card-on-file **tokenisation** rules (effective October 2022) mean merchants store a token in place of your actual card number.

**The most common holes.** The OWASP Top 10, maintained by the Open Worldwide Application Security Project, lists the most frequent web-application risks. In plain words:

```dia
title: The web's most common security holes, in plain words
src: Based on OWASP Top 10 categories; examples illustrative
cards([("Broken access control", "Change order ID 98812 to 98813 in the URL and see a stranger's address. The most common serious flaw.", "#E3120B"), ("Injection", "Typing code into a search box that the server runs against the database."), ("Security misconfiguration", "A storage bucket of customer KYC files left publicly readable."), ("Vulnerable components", "Using an old open-source library with a known hole."), ("Authentication failures", "No limit on OTP attempts, so bots can guess all 10,000 codes."), ("Cryptographic failures", "Sensitive data sent or stored without proper encryption.")], ncol=3)
```

**Abuse at the front door.** A **DDoS** (distributed denial-of-service) attack floods you with junk traffic from thousands of machines; CDNs and specialised services absorb it. **Rate limiting** and **bot detection** stop credential stuffing (trying leaked passwords), OTP bombing and scalping (the IRCTC Tatkal problem). A **WAF** (web application firewall) filters malicious requests.

**Least privilege and data minimisation.** Give every person and service the minimum access needed, and do not collect data you do not need. India's **Digital Personal Data Protection Act, 2023**, with its Rules notified in November 2025 and obligations phasing in over roughly 18 months, makes consent, purpose limitation, breach reporting and deletion legal requirements, not just good practice.

**Why a PM cares.** Security is a trade against friction. An OTP on every login is secure and annoying; no OTP is smooth and dangerous. Good products use **risk-based** friction: step-up checks only for a new device, a large transfer or a changed bank account.

## Shipping safely: releases and feature flags

Back-end code on your own servers can be changed several times a day. Mobile apps cannot. A new Android or iOS version must be built, reviewed by Google or Apple (usually within a day or two, occasionally longer), downloaded by users, and some users will not update for months. A bug in the app on people's phones cannot simply be rolled back.

Teams therefore ship mobile apps on a **release train**: a fixed cadence (often weekly or fortnightly) where whatever is ready boards the train, and whatever is not waits for the next one, instead of delaying the whole release.

```dia
title: A typical fortnightly mobile release train
sub: Illustrative cadence; each stage is a gate where a PM can stop the train
steps([("Code freeze", "Features merged behind flags; branch cut for release", "Late features take the next train"), ("QA & beta", "Automated tests, manual regression, internal and beta users", "Watch crash-free rate"), ("Store review", "Submit to Google Play and App Store", "Usually 1–2 days; plan launches around it"), ("Staged rollout", "Play: release to a % of users. iOS phased: 1%, 2%, 5%, 10%, 20%, 50%, 100% over 7 days", "Pause if crashes rise"), ("Flip the flags", "Turn features on server-side for chosen users", "Decoupled from the app release")], hl=[3, 4])
```

The most powerful tool here is the **feature flag**: a switch in the code, controlled from a server, that decides whether a feature is on or off for a given user. With flags you can:

- **Decouple deploy from release:** the code ships in the app on Monday, the feature turns on for users on Thursday when marketing is ready.
- **Roll out gradually:** 1% of users, then 10%, then 50%, watching metrics at each step; this is also how A/B tests are run.
- **Kill switch:** turn off a misbehaving feature in seconds, without a new app release.
- **Target:** enable for one city, beta users, or employees first (**dogfooding**).

On the server side, the equivalents are **canary releases** (send 1–5% of traffic to the new version and compare its error rate with the old one), **blue-green deployments** (run old and new side by side and switch traffic over, with instant switch-back) and **CI/CD** (continuous integration and delivery: every code change is automatically built and tested, and can be deployed within minutes).

The cautionary tale is **CrowdStrike, 19 July 2024**. A faulty content update to its security software was pushed to all customers at once, crashing about **8.5 million Windows machines** worldwide (Microsoft's estimate), grounding flights and disrupting hospitals and banks, including in India. A staged rollout to a small percentage first would have caught it within minutes. The lesson for PMs: **every change should reach a small group before it reaches everyone**, including "just a config update".

::: key The one-line rule for releases
Separate *shipping code* from *turning features on*. Put every meaningful change behind a flag, roll it out gradually while watching a small set of health metrics, and know in advance which metric would make you switch it off.
:::

## In the interview

System-design questions for PMs are not coding tests. Interviewers want to see that you can reason about **scale, failure and trade-offs** and translate them into product decisions. Strong candidates:

- **Ask about scale and shape of demand first.** "How many users, how spiky? IPL final or a normal Tuesday?" Scale changes the answer.
- **Separate the must-be-correct from the can-be-stale.** "Seat inventory needs strong consistency; the seat map can be cached for a few seconds and re-checked on booking."
- **Name the failure modes and the degraded experience.** "If the recommendation service is down, we show trending items, not an error."
- **Tie every technical choice to a user or business outcome.** "Moving images to a CDN should cut p95 page load in Tier-2 cities and reduce our bandwidth bill."

Typical prompts: "How would you prepare IRCTC for Tatkal?" (pre-scale, virtual waiting room with a queue and honest wait times, rate limits and identity checks against bots, cache static data, strong consistency on seat allocation, graceful degradation of non-booking features); "Our app went down during the sale, what do you do?" (incident process: mitigate first, communicate, then root cause and postmortem; measure revenue impact); "Should we move to microservices?" (depends on team size and scaling pain; the cost is operational complexity).

::: quiz Check yourself
1. Rescale these to human time and explain why caches matter: a memory read, an SSD read, a Mumbai–US round trip.
2. Why can the average latency look fine while users complain? Which number would you watch instead?
3. Give one feature that belongs in a SQL database and one that suits NoSQL, and say why.
4. What is replication lag, and how might a user notice it?
5. Explain a hot shard using a phone directory.
6. Why did Hotstar pre-warm servers instead of relying on auto-scaling?
7. Place these on the consistency–availability scale: wallet balance, "people also bought", seat count on a flight, typing indicator in chat.
8. Define SLI, SLO and SLA for an OTP-login service, and say what an error budget lets the team do.
9. What does a feature flag let you do that an app-store release cannot? What went wrong in the CrowdStrike incident?
10. *(From the internet chapter)* A dashboard shows a spike in 503 errors during a sale. Is this a client-side or server-side problem, and which building block would you check first?
:::
