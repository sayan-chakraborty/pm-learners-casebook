%% chapter | Technology · Emerging tech | Blockchain: a ledger nobody can quietly rewrite | How a chain of blocks works, the four kinds of blockchain, where it has created real business value, and the questions that tell you whether you need one at all

Picture a neighbourhood savings group of twenty families, a chit fund of the kind common across India. One member keeps the account book. Everyone has to trust that she records every contribution honestly and never quietly changes page 12. Now imagine instead that **every family keeps an identical copy** of the book, every new entry is read out and checked by the group before everyone writes it down, and each page carries a seal that depends on the page before it. To cheat, you would have to secretly rewrite the same page in more than half the books at once, and redo every page after it. Cheating becomes practically impossible, and nobody needs to be the trusted bookkeeper.

That is the idea of a **blockchain**: a **distributed ledger** shared across many computers (nodes), where records are grouped into blocks, each block is cryptographically linked to the one before, and the network agrees on each new block before it is added. It was invented to run Bitcoin, but the ledger idea applies wherever several parties who do not fully trust each other need one shared record.

## How it works

```dia
title: A chain of blocks
sub: Each block stores the fingerprint (hash) of the previous one; change any old block and every later link breaks
arch({"b1": ("Block 101", "Transactions + time stamp; own hash 7a9f…", "N"), "b2": ("Block 102", "Stores prev hash 7a9f…; own hash c41e…", "N"), "b3": ("Block 103", "Stores prev hash c41e…; own hash 0b77…", "N"), "b4": ("Tampered block 102", "Edit one entry: hash changes, 103 no longer matches", "R")}, [("b1", "b2", "hash links"), ("b2", "b3", "hash links"), ("b4", "b3", "mismatch", "r")], rankdir="LR", wrapch=18)
```

A **hash** is a digital fingerprint: a short code calculated from the block's contents. Change even one character of the contents and the fingerprint changes completely. Because each block contains the previous block's fingerprint, the blocks form a chain; tampering with an old block breaks every link after it, and the thousands of other copies on the network immediately disagree.

```dia
title: How a transaction gets onto the chain
steps([("Request", "Asha sends 0.1 units to Ravi, signing with her private key", "The signature proves it is really her"), ("Broadcast", "The transaction is sent to nodes across the network", ""), ("Validate", "Nodes check the signature and that Asha actually has the funds", "Stops double-spending"), ("Agree (consensus)", "Nodes agree on the next block: by solving a puzzle (proof of work) or by staking value (proof of stake)", "Slow and costly on public chains"), ("Chain it", "The block is added; every node updates its copy", "Permanent: fixes are new reversing entries")], hl=[3])
```

Three properties follow:

- **Open and distributed.** Participants share one ledger instead of each keeping and reconciling their own. A transaction is recorded once for everyone, removing duplicated effort.
- **Immutable.** No participant can tamper with a recorded transaction. If there is an error, a new transaction must reverse it, and both remain visible, like a correction entry in accounting.
- **Secure through keys.** **Public-key cryptography** gives each participant two keys. The **public key** is like your account number or letterbox address: anyone can send to it. The **private key** is like the only key to that letterbox: whoever holds it can authorise transactions and prove ownership. Lose it and the assets are gone; nobody can reset it.

## Four kinds of blockchain

The two questions are: who may **read and join**, and who may **write and validate**?

```dia
title: Types of blockchain by permission
matrix("Who can write and validate: anyone → approved parties only", "Who can join and read: approved only → anyone", [("Public, permissionless", "Anyone reads, writes and validates. Maximum decentralisation and censorship-resistance; slower, energy-hungry, limited privacy. Bitcoin, Ethereum."), ("Public, permissioned", "Anyone can read, but only approved validators write. Balances openness and control; medium scalability."), ("Private, permissionless", "Only invited members join, but all members can read, write and commit. Rare in practice."), ("Private, permissioned", "Pre-approved members only; write rights limited further. Maximum control and compliance; high scalability for B2B. Hyperledger Fabric, R3 Corda.")])
```

## Where it has created business value

Most successful uses are **between organisations** that must share records but do not want any one of them to own the database.

```dia
title: Three well-documented enterprise results
src: HSBC/ING (May 2018); Walmart/IBM Food Trust (2018); OCBC, HSBC, MUFG with Singapore IMDA (Oct 2017), KPMG estimate
cards([("Faster trade finance", "HSBC and ING settled a soybean shipment from Argentina to Malaysia with digitised trade documents in 24 hours, versus 5–10 days on paper."), ("Food traceability", "Walmart and IBM traced the source of a mango pack in 2.2 seconds, versus about 7 days by the old process, speeding recalls."), ("Shared KYC", "Three banks in Singapore piloted verifying a customer once and reusing it across banks; KPMG estimated 25–50% cost savings.")], ncol=3)
```

Other applications: **cryptocurrency** (peer-to-peer digital money without a bank); **supply-chain tracking** (every hand-off recorded in a tamper-evident log); **smart contracts** (code on the chain that executes automatically when conditions are met, such as releasing payment when a shipment is scanned as delivered); **digital identity** (verifiable credentials the holder controls); **voting** and public records (auditable, hard to alter); and **tokenisation** of assets such as bonds or property.

## The shortcomings

- **Energy use.** Proof-of-work mining consumes enormous electricity. Ethereum's switch to proof of stake in September 2022 cut its energy use by over 99%, showing it is a design choice, not a law of nature.
- **Throughput.** Bitcoin processes only about 7 transactions per second. UPI averaged about 9,000 per second in August 2026. Public chains are slow because thousands of nodes must agree.
- **User experience.** Wallets, seed phrases, gas fees and irreversible mistakes confuse mainstream users. Send to a wrong address and there is no customer care.
- **Regulation.** Rules vary widely and change often. India, for example, taxes gains on crypto assets at 30% with 1% TDS on transfers (since 2022).
- **Garbage in, garbage forever.** A blockchain guarantees that a record was not changed; it cannot guarantee the record was true when entered. If a supplier scans a fake label, the chain faithfully preserves the lie. (This is called the oracle problem.)

## Do you actually need a blockchain?

Most proposals do not. A widely used test, adapted from the World Economic Forum and others:

```dia
title: Should this be a blockchain?
sub: Answer in order; most projects exit early to a normal database
tree(["Do you need a shared database?|If not: no blockchain", [["No|A spreadsheet or app will do"], ["Yes: do many parties write to it?", [["No, one writer|Centralised database"], ["Yes: do they trust each other, or one operator?", [["Yes|Shared or replicated database"], ["!No: is a trusted intermediary acceptable?", [["Yes|Use the intermediary (e.g. a clearing house)"], ["!No|Blockchain may fit"]]]]]]]]], wrapch=18)
```

::: key The one-line rule
A blockchain is a slow, expensive database whose one superpower is letting parties who do not trust each other share a record nobody controls. If there is a trusted operator, use a normal database.
:::

**In the interview.** "Should our supply-chain product use blockchain?" (walk the decision tree; name who writes, who trusts whom, and the oracle problem), "Explain blockchain to a 10-year-old" (the shared notebook with seals), "Why is UPI not on a blockchain?" (a trusted central operator, NPCI, exists; UPI needs thousands of transactions per second, instant finality and reversibility for errors, all of which a public blockchain makes harder). Trap: treating "decentralised" as automatically better.

%% article | Technology · Emerging tech | The Internet of Things: when objects get sensors and a connection | How connected devices sense, communicate, decide and act, from FASTag to factory machines

You drive through a toll plaza on the Mumbai–Pune Expressway without stopping. A small RFID sticker on your windscreen, **FASTag**, is read by a scanner above the lane, the toll is deducted from a linked account, and an SMS arrives before you have changed gear. FASTag was made mandatory on national highways in February 2021, and cash queues at most plazas shrank from minutes to seconds. The windscreen sticker, the lane reader, the payment switch and the SMS together are a small **Internet of Things (IoT)** system.

IoT is a network of physical devices with **sensors, software and connectivity** that let them collect data, exchange it, and act on it. It ranges from a fitness band or a smart electricity meter to thousands of vibration sensors in a steel plant or the traffic signals of a smart city.

## How IoT works

```dia
title: The IoT loop
loop([("Sense", "Sensors capture temperature, motion, location, vibration, light"), ("Communicate", "Data travels via Wi-Fi, Bluetooth, Zigbee, cellular or low-power networks, often using MQTT"), ("Process", "Analysed at the edge (on the device or a nearby gateway) or in the cloud"), ("Act", "Automated action or alert: open the barrier, cut the power, notify the user"), ("Learn", "Feedback improves rules and models over time")], center="IoT system", center_desc="Physical world → data → decision → physical world", edges=["", "", "", "", ""])
```

The connectivity choice is a product decision because it fixes range, battery life and cost.

| Option | Range | Power use | Typical use |
|---|---|---|---|
| RFID / NFC | Centimetres to a few metres | None on the tag | FASTag, metro cards, warehouse tags |
| Bluetooth Low Energy | ~10 m | Very low | Wearables, earbuds, smart locks |
| Zigbee / Thread | Tens of metres, mesh | Very low | Smart bulbs, home sensors |
| Wi-Fi | Home or office | High | Cameras, smart TVs, appliances |
| Cellular (4G/5G, NB-IoT, LTE-M) | Kilometres | Medium to low | Connected scooters, smart meters, fleet tracking |
| LoRaWAN | Several kilometres | Very low | Farm sensors, city infrastructure |

**MQTT** is a lightweight messaging protocol designed for small devices on unreliable networks: devices publish short messages to topics, and anything subscribed receives them. **Interoperability** standards such as **Matter** (launched in 2022 by major smart-home companies) aim to let devices from different brands work together.

```dia
title: Edge versus cloud processing
versus("Edge: decide on or near the device", [("Good for", "Split-second responses, poor connectivity, privacy (data stays local)"), ("Example", "A factory machine shuts itself down within milliseconds when vibration spikes"), ("Cost", "Less computing power; harder to update")], "Cloud: send data up, decide centrally", [("Good for", "Heavy analysis, combining data from many devices, training models"), ("Example", "Predicting which of 5,000 machines will fail next month"), ("Cost", "Latency, data charges, needs a connection")], verdict="Most real systems do both: react at the edge, learn in the cloud.")
```

## Types of IoT

```dia
title: Four kinds of IoT
cards([("Consumer IoT", "Convenience and lifestyle. Smart speakers, lights, appliances, fitness trackers, glucose monitors, connected scooters like Ather's."), ("Commercial IoT", "Customer experience and security in business settings: smart retail offers, hotel room controls, asset tracking in warehouses."), ("Industrial IoT", "Predictive maintenance, safety and efficiency in manufacturing, logistics and energy: remote machine monitoring."), ("Infrastructure IoT", "Sustainability and safety at city scale: smart grids and meters, water leak detection, traffic signals, FASTag tolling.")], ncol=4)
```

## Business value

- **Operational efficiency.** Amazon's warehouses use fleets of robots that bring shelves to pickers, speeding fulfilment and cutting labour cost.
- **Data-driven decisions.** Starbucks connects its coffee machines to monitor drink quality and push recipe changes remotely.
- **Customer experience.** Disney's MagicBand lets park visitors unlock hotel rooms, enter rides and pay with a tap of the wrist.
- **New revenue models.** John Deere sells precision-farming subscriptions built on data from connected tractors; connected-vehicle makers sell navigation and diagnostics packs. Hardware becomes a recurring service.

Coupled with AI, IoT enables **predictive** products (the machine that tells you it will fail next week) and personalisation from real-world behaviour.

## The challenges

**Security** is the big one: cheap devices with default passwords are easy to hijack. In 2016 the Mirai botnet enslaved hundreds of thousands of cameras and routers and used them to knock major websites offline. Add **battery life**, **patchy rural connectivity**, **privacy** (a smart meter reveals when you are home), **interoperability** between brands, and **long hardware lifecycles**: a device in the field for ten years needs over-the-air updates and a plan for when the company changes its cloud.

::: key The one-line rule
IoT turns physical events into data and data back into physical actions. The product is the whole loop, including the device's battery, its connection, its security and its updates, not just the app.
:::

**In the interview.** "Design a smart water meter for Indian apartments" (who pays and why: residents want fair bills, societies want leak alerts; connectivity in basements; battery life of years; tamper detection; edge rules for leaks, cloud for billing; privacy), "How would you monetise a connected product?" (hardware margin, subscriptions for premium features, data insights for B2B, but with consent). Strong line: *"For an IoT product I'd define the job at the level of the physical outcome, 'no leaks go unnoticed for more than an hour', and work backwards to sensing frequency, connectivity and battery."*

%% article | Technology · Emerging tech | AR and VR: adding to reality, or replacing it | How augmented and virtual reality work, where each fits, and the hardware realities that decide adoption

Open the Lenskart app, point your phone's camera at your face, and frames appear on it, moving as you turn your head. Open IKEA's app and a sofa sits in your living room at true scale. Walk out of a metro station, raise Google Maps in **Live View**, and arrows float on the street telling you which way to go. These are **augmented reality (AR)**: digital content layered onto the real world. Put on a Meta Quest headset and you are standing in a virtual cockpit or on a mountain; the real room disappears. That is **virtual reality (VR)**: a fully digital environment that replaces what you see.

```dia
title: The reality spectrum
scale("Real world", "Fully virtual", [("Real world", 0.02, "No digital layer"), ("AR", 0.3, "Digital overlays on the real view: phone camera, smart glasses"), ("Mixed reality", 0.62, "Digital objects that interact with the real room"), ("VR", 0.97, "Real world blocked out; headset")], lnote="User stays aware of surroundings", rnote="User fully immersed")
```

Together these are often called **XR (extended reality)**; "mixed reality" describes the middle, where virtual objects are anchored to and interact with real surfaces (Apple's Vision Pro and Meta's Quest 3 can blend both).

## How they work

```dia
title: How phone-based AR places a sofa in your room
steps([("See", "Camera and motion sensors capture the room as you move the phone", "Low light breaks it"), ("Understand", "Computer vision maps the floor, walls and your position (SLAM)", "Needs textured surfaces"), ("Anchor", "The 3D sofa is fixed to a spot on the floor at real scale", "Drift makes it 'float'"), ("Render", "The sofa is drawn over the camera view, 30–60 times a second, with lighting and shadows", "Heats the phone, drains battery"), ("Interact", "Tap, drag, rotate; buy", "Must feel natural")], hl=[1])
```

VR works differently. The headset shows a slightly different image to each eye to create depth, tracks your head (and often hands) in all directions many times a second, and redraws the world instantly as you move. The critical number is **motion-to-photon latency**, the delay between moving your head and the image updating: if it is too high (roughly above 20 milliseconds), the brain notices the mismatch between what the inner ear feels and what the eyes see, and many people feel sick. Spatial audio and haptic feedback (vibrations in controllers) add a sense of **presence**.

| | Augmented reality (AR) | Virtual reality (VR) |
|---|---|---|
| Goal | Enhance reality | Replace reality |
| Environment | Real world + digital overlays | Fully virtual |
| User awareness | Remains aware of surroundings | Immersed; surroundings hidden |
| Hardware | Smartphones, tablets, smart glasses | Headset + controllers or hand tracking |
| Interaction | Touch, gestures, voice, glasses | Head, hand and controller tracking |
| Best for | Navigation, shopping previews, maintenance, labels in view | Gaming, training, simulations, virtual tours |
| Examples | Pokémon GO, Snapchat filters, Google Maps Live View, IKEA, Lenskart try-on | Meta Quest, PlayStation VR, VR apps on Apple Vision Pro |

## Applications by industry

| Industry | AR example | VR example |
|---|---|---|
| Retail | Furniture and eyewear try-on at home | Virtual showrooms |
| Healthcare | Vein visualisation, surgical guidance | Surgical training simulations |
| Education | Interactive textbooks, 3D models on the desk | Virtual labs and field trips |
| Manufacturing | Step-by-step assembly instructions in view | Safety and equipment training |
| Navigation | Walking directions overlaid on the street | Virtual building walkthroughs |
| Real estate | See furniture in an empty flat | Virtual home tours before visiting |
| Entertainment | Pokémon GO, face filters | VR games, immersive concerts |

## When to build which

```dia
title: A decision guide
versus("Build AR when…", ["Users are interacting with the physical world.", "Location or context matters.", "They need real-time information overlaid on what they see.", ("Examples", "Navigation, shopping preview, warehouse picking, maintenance support.")], "Build VR when…", ["Full immersion improves learning or enjoyment.", "Simulation is safer or cheaper than the real thing.", "The experience is impossible physically.", ("Examples", "Pilot training, surgery practice, virtual tourism, gaming.")], verdict="AR reaches billions of phones today; VR needs a headset, so it wins where immersion is worth the hardware.")
```

| AR challenges | VR challenges |
|---|---|
| Device compatibility across thousands of phones | Expensive hardware; Apple Vision Pro launched at US$3,499 in 2024 |
| Tracking accuracy; objects drift | Motion sickness |
| Battery drain and heat | Fatigue and discomfort in long sessions |
| Lighting and environment issues | Limited adoption: few people own headsets |
| Privacy: cameras always watching | High cost of creating 3D content |

::: key The one-line rule
Choose AR when the real world is the context and VR when leaving it is the point. Success depends on latency, comfort and device reach more than on visual wow.
:::

**Why a PM cares.** Distribution decides AR/VR products: phone-based AR is available to hundreds of millions of Indian users today, while headsets remain niche, so most consumer wins in India are AR features inside existing apps (try-on, visual search, navigation). The metrics are practical: does try-on raise conversion and cut returns? How long before users feel tired? Does it work on a ₹12,000 phone in a dim room?

**In the interview.** "Should Nykaa invest in AR try-on?" (yes if it reduces uncertainty at purchase, the main driver of returns in beauty and eyewear; measure conversion and return rate by A/B test; ensure it works on mid-range phones and diverse skin tones), "Where does VR make business sense?" (training where mistakes are dangerous or expensive: pilots, surgeons, heavy machinery). Trap: proposing a VR headset product for a mass Indian consumer use case without addressing hardware adoption.

::: quiz Check yourself
1. Explain hashes and why tampering with an old block is detectable.
2. What do the public and private keys each do? What happens if you lose a private key?
3. Place Bitcoin and Hyperledger Fabric in the permission matrix and explain the trade-off.
4. Walk through the 'do you need a blockchain?' tree for UPI. Where does it exit?
5. Describe the IoT loop using FASTag. What is processed at the edge and what in the cloud?
6. Why would you pick LoRaWAN over Wi-Fi for farm soil sensors?
7. What is motion-to-photon latency and why does it matter in VR?
8. Give one AR and one VR product idea for an Indian company, and the metric you would use for each.
9. *(From the system-design chapter)* A connected scooter maker must push a firmware fix to 3 lakh scooters. How would you roll it out safely?
:::
