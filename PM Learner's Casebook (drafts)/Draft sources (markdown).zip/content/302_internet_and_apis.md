%% chapter | Technology · The internet | What happens when you open an app | Addresses, phone books, registered post and sealed envelopes: how a request actually travels, and how apps talk to each other through APIs

Open JioHotstar during an India–Pakistan match. Within a second or two the home screen appears, the score updates, and a live stream starts playing in HD. During the ICC Men's T20 World Cup final in March 2026, JioHotstar reported a peak of **72.5 million concurrent streams** (Reliance Industries / JioStar, 2026). Every one of those phones had to find the right servers, prove the connection was secure, and pull a steady flow of video, all at once.

None of this is magic. It rests on a handful of ideas that are easy to picture once you have the right everyday analogy. This chapter walks one request from your thumb to a server and back.

## Clients and servers

A **client** is the thing that asks; a **server** is the thing that answers. Your Swiggy app, your browser and your smart TV are clients. Swiggy's computers in a data centre in Mumbai are servers. A server is not a special kind of machine, just a computer whose job is to wait for requests and answer them, all day, for many clients at once.

Engineers split the work into the **frontend** (what runs on the client: screens, buttons, animations) and the **backend** (what runs on servers: business rules, data, payments). A **native app** is installed from the Play Store or App Store and runs directly on the phone; a **web app** runs inside the browser; a **progressive web app (PWA)** is a website that behaves like an app (installable, works partly offline). Flipkart Lite, a PWA launched in 2015, was built for exactly this reason: many Indian users had low-storage phones and patchy data.

## Step 1: finding the server (IP addresses and DNS)

Every device on the internet has an **IP address**, a number that works like a postal address: `142.250.183.14` is one of Google's. The older format, **IPv4**, has about 4.3 billion possible addresses, which the world ran out of. The newer **IPv6** has enough for every grain of sand many times over; India, led by Jio's network, is one of the heaviest users of IPv6 in the world. Within a machine, a **port** number is like the flat number inside the building: web traffic goes to port 443 (HTTPS) or 80 (plain HTTP).

People cannot remember numbers, so we use names like `hotstar.com`. The **Domain Name System (DNS)** is the internet's contacts app: it turns a name into an IP address.

```dia
title: How DNS finds hotstar.com
sub: Asked once, then remembered: most lookups are answered from a cache in step 1 or 2
steps([("Check memory", "Phone and browser check their own cache: looked this up recently?", "Answers in ~0 ms if cached"), ("Ask the resolver", "Ask the ISP's (Jio, Airtel) or a public resolver like 8.8.8.8", "Resolver has its own large cache"), ("Root server", "'Who handles .com?' Root points to the .com servers", "13 named root systems, copied worldwide"), ("TLD server", "'Who handles hotstar.com?' Points to its name servers", "Top-level domain: .com, .in, .org"), ("Authoritative server", "Returns the actual IP, with a time-to-live (TTL)", "TTL = how long others may cache it")], hl=[4])
```

**Why a PM cares.** DNS is invisible until it breaks, and then everything breaks. On 19–20 October 2025 a race condition in Amazon's automation left the DNS record for DynamoDB (a core AWS database) in its main US region **empty**. Programs could not find the database even though the database itself was fine; the failure cascaded into EC2, load balancers, Lambda and more, and parts of AWS were disrupted for over 14 hours, taking many consumer apps down with it (AWS post-event summary, Oct 2025). DNS also matters when you migrate or fail over: a short TTL lets you switch traffic quickly, a long one means some users keep going to the old address for hours.

## Step 2: sending the data (packets, TCP and UDP)

Data does not travel as one piece. It is chopped into small **packets** (typically about 1,500 bytes each), each labelled with the source and destination address, and each may take a different route through the network. At the other end they are put back together. The rules for this are the **TCP/IP** family of protocols.

Two rules sit on top of IP, and they make opposite trade-offs.

```dia
title: TCP versus UDP
sub: Registered post versus a live radio commentary
versus("TCP: reliable, ordered", [("Analogy", "Sending a book page by page by registered post. Every page is numbered and acknowledged; missing pages are resent."), ("How", "Starts with a handshake; confirms each packet arrived; resends losses; delivers in order."), ("Cost", "Extra round trips and waiting when a packet is lost."), ("Used for", "Web pages, APIs, payments, email, chat messages, file downloads.")], "UDP: fast, no guarantees", [("Analogy", "Live cricket commentary on radio. If you miss a ball, the commentator does not repeat it; he moves on."), ("How", "No handshake, no acknowledgement, no resending. Just send."), ("Cost", "Some data is lost or arrives out of order; the app must cope."), ("Used for", "Video calls, online gaming, live streams, DNS lookups, and QUIC, the base of HTTP/3.")], verdict="Choose TCP when every byte must arrive; choose UDP when late data is worse than missing data.")
```

A video call on Google Meet is the classic UDP case: a frame that arrives half a second late is useless, so it is better to skip it and show the next one. A UPI payment request is the opposite: every byte matters, so it runs over TCP.

## Step 3: asking for something (HTTP)

With a connection in place, the client asks for what it wants using **HTTP** (HyperText Transfer Protocol). HTTP is a simple request-and-response conversation: the client sends a **request** with a method, an address, some headers and sometimes a body; the server replies with a **status code**, headers and a body.

The **method** says what you want to do: **GET** fetches something, **POST** creates something, **PUT/PATCH** updates it, **DELETE** removes it. The **status code** says how it went. You will see these in bug reports and dashboards, so learn the families.

| Code | Meaning | Everyday reading |
|---|---|---|
| 200 OK / 201 Created | It worked | "Here is your menu" / "Order created" |
| 301 / 302 | Moved | "That page lives at a new address now" |
| 304 Not Modified | Use your copy | "Nothing changed since you last asked" (saves data) |
| 400 Bad Request | Client sent something malformed | App bug or bad input |
| 401 Unauthorized / 403 Forbidden | Not logged in / not allowed | Session expired; trying to see someone else's order |
| 404 Not Found | No such thing | Deleted product, broken link |
| 429 Too Many Requests | Slow down | You hit the rate limit |
| 500 Internal Server Error | Server broke | Bug on our side |
| 502 / 503 / 504 | Gateway error / unavailable / timeout | Overloaded or a service behind it is down |

Rule of thumb: **4xx means the client's side, 5xx means the server's side.** A dashboard showing 5xx errors spiking during a sale is a backend capacity problem; a spike in 401s right after a release is probably a login bug in the new app version.

HTTP is **stateless**: each request stands alone, and the server does not remember the previous one. So how does Amazon know you are logged in? The client attaches a **cookie** or a **token** (a signed pass) to every request, like showing your gym membership card at the door every time rather than expecting the guard to remember your face.

## Step 4: keeping it private (HTTPS and TLS)

Plain HTTP travels as readable text; anyone on the same café Wi-Fi could read it. **HTTPS** is HTTP inside a **TLS** (Transport Layer Security) tunnel. TLS does three jobs: it **encrypts** the data so only the two ends can read it; it **authenticates** the server with a **certificate**, a digital ID card signed by a trusted certificate authority, so you know you are really talking to your bank and not an impostor; and it **checks integrity**, so nobody can alter the data in transit. The padlock in the browser means all three are in place.

```dia
title: One page load, end to end
sub: Each arrow crossing the network costs at least one round trip; a round trip Mumbai–US East is ~200 ms, Mumbai–Chennai ~25 ms (illustrative)
seq(["Phone", "DNS resolver", "CDN edge (Mumbai)", "Origin servers"], [("Phone", "DNS resolver", "Where is hotstar.com?", "Skipped if cached"), ("DNS resolver", "Phone", "IP of the nearest edge"), ("Phone", "CDN edge (Mumbai)", "TCP handshake + TLS handshake", "1–2 round trips before any data"), ("Phone", "CDN edge (Mumbai)", "GET home page images and scripts"), ("CDN edge (Mumbai)", "Phone", "200 OK, served from edge cache", "Cache hit: fast, cheap"), ("Phone", "Origin servers", "GET personalised rows for this user (API)", "Cannot be cached for everyone"), ("Origin servers", "Phone", "200 OK, JSON data")])
```

What HTTPS does *not* do: it protects data **in transit**, not data sitting on the server ("at rest"), and it does not stop a server that is itself hacked or dishonest. Encryption at rest, access controls and audits cover those (see the security section of the system-design chapter).

## Step 5: bringing content closer (CDNs)

The speed of light in optical fibre is about 200,000 km per second. Mumbai to a data centre in Virginia is roughly 13,000 km each way, so physics alone sets a floor of about 130 ms for a round trip, and real networks roughly double it. A page that needs ten round trips would feel sluggish. You cannot make light faster, so you move the content closer.

A **Content Delivery Network (CDN)** is a network of servers spread across cities, each keeping copies of content. The user is routed to the nearest one, the **edge**. Only if the edge does not have the content (a **cache miss**) does it fetch it from the company's main servers, the **origin**, and keep a copy for the next person.

```dia
title: How a CDN serves a cricket highlight to users across India
sub: Popular files are fetched from the origin once, then served locally thousands of times
arch({"u1": ("Users in Chennai", "Phones request the highlight clip", "L"), "u2": ("Users in Delhi", "Same clip, 2,000 km away", "L"), "e1": ("Edge server, Chennai", "Holds a copy; serves locally in ~10 ms", "T"), "e2": ("Edge server, Delhi", "Cache miss on first request only", "T"), "o": ("Origin servers", "The master copy in the company's cloud", "N")}, [("u1", "e1", "nearby"), ("u2", "e2", "nearby"), ("e1", "o", "first request only", "d"), ("e2", "o", "first request only", "d")], rankdir="LR")
```

Netflix built its own CDN, **Open Connect**, and places its caching boxes inside ISPs' networks for free. As early as 2016 it said close to 90% of its traffic was delivered over direct connections between Open Connect and residential ISPs (Netflix, March 2016). When you press play in Pune, the film may be coming from a Netflix box in your ISP's building, not from the US.

**Why a PM cares.** CDNs cut **latency** (faster pages mean more conversions), cut **cost** (serving from the edge is cheaper than sending everything from the origin, and cloud providers charge for data leaving their network), and absorb **spikes** (a viral sale banner is served from hundreds of edges, not one server). The trade-off is **freshness**: cached copies can be stale. Prices and stock should not be cached for long; logos and product photos can be cached for days. Deciding what is safe to cache, for how long, is partly a product decision.

::: key The one-line rule
A request is a trip: find the address (DNS), open a reliable line (TCP), secure it (TLS), ask (HTTP), and fetch from the nearest copy (CDN). Every round trip costs time, so good systems remove trips and move content closer to the user.
:::

**In the interview.** "What happens when you type a URL and press enter?" is a classic warm-up, even for PMs. Walk the five steps above in plain words, then add one product insight: *"The first visit is slow because of DNS, TCP and TLS set-up, so for a flash sale I'd pre-warm the CDN with banner images and ask whether we can keep connections alive between app launches."* Other forms: "Why is our app slow for users in Tier-3 towns?" (distance to servers, few CDN edges, 3G networks, heavy images; measure by region and network type), "Should our live quiz use TCP or UDP?" (answers must arrive reliably: TCP, or WebSockets over TCP).

%% article | Technology · APIs | APIs: how software talks to software | The waiter, the menu and the doorbell: REST, webhooks, WebSockets, rate limits, and why an API is itself a product

When you book an Ola ride, the map comes from a mapping provider, the payment goes through a payment gateway to NPCI's UPI switch, the OTP arrives by an SMS provider, and the driver's phone gets a push notification through Google's or Apple's servers. None of these companies share code. They talk through **APIs**.

An **API (Application Programming Interface)** is an agreed way for one program to ask another for something. In the restaurant model, the API is the **waiter** and its documentation is the **menu**: you can only order what is listed, in the way it is listed, and you do not need to know how the kitchen works. The kitchen can change its stoves, recipes or staff, and as long as the menu stays the same, diners notice nothing. That separation is the whole point.

APIs can be **private** (a company's own app talking to its own backend), **partner** (Swiggy's restaurant partners' billing systems sending menu updates) or **public** (Google Maps, Razorpay, OpenAI). India's digital public infrastructure is largely a set of public API standards: **UPI** for payments, **Aadhaar eKYC** for identity, **DigiLocker** for documents, the **Account Aggregator** framework for sharing financial data with consent, and **ONDC** for open commerce. Any licensed player can plug in, which is why dozens of apps can offer UPI.

## REST: the most common API style

Most APIs you will meet follow a style called **REST**. The idea: everything is a **resource** with an address (a noun), and you act on it with the standard HTTP methods (verbs). Data usually travels as **JSON**, a simple text format of labelled values.

| What the app wants | REST request | Server replies |
|---|---|---|
| List biryani places in Bengaluru | `GET /restaurants?city=blr&dish=biryani` | 200 + list of restaurants |
| See one restaurant's menu | `GET /restaurants/4521/menu` | 200 + menu items |
| Place an order | `POST /orders` with cart in the body | 201 Created + order ID |
| Change delivery instructions | `PATCH /orders/98812` | 200 + updated order |
| Cancel the order | `DELETE /orders/98812` (or a cancel action) | 200, or 409 if already picked up |

A reply might look like this:

```
{ "order_id": 98812, "status": "PREPARING", "eta_minutes": 28,
  "rider": { "name": "Ravi", "lat": 12.9352, "lng": 77.6245 } }
```

REST is popular because it is simple, readable and easy to debug. Its weakness is **over-fetching** (getting fifty fields when the screen needs three, which wastes mobile data) and **under-fetching** (needing five calls to build one screen). Two alternatives address this:

- **GraphQL** (created at Facebook) lets the client ask for exactly the fields it needs in one request. Good for complex, data-heavy screens.
- **gRPC** (created at Google) sends compact binary messages over HTTP/2. Faster and lighter, but not human-readable; mostly used for service-to-service calls inside a company's backend.

## How does the app hear about changes?

HTTP is "ask and answer": the server cannot speak unless spoken to. But a food-delivery app needs to know when the restaurant accepts the order, and a chat app needs to show a new message instantly. There are four ways to solve this, and choosing between them is a real product trade-off between freshness, battery, and server cost.

```dia
title: Four ways to learn that something changed
sub: From the child asking 'are we there yet?' to the driver who calls you when he arrives
cards([("Polling", "Client asks every few seconds: 'Any update?' Simple, but wasteful: most answers are 'no', and it drains battery and servers."), ("Long polling", "Client asks, server holds the question open until there is news or a timeout. Fewer empty answers; still one request per update."), ("WebSockets", "One connection stays open and both sides can talk any time. Best for chat, live scores, rider tracking, collaborative editing."), ("Webhooks", "Server-to-server doorbell: 'Call this URL when X happens.' Razorpay calls the merchant's server when a payment succeeds.")], ncol=2)
```

**Push notifications** are a fifth path for when the app is closed: your server sends the message to Apple's (APNs) or Google's (FCM) push service, which wakes the phone. You do not control delivery timing or guarantees; the OS does.

A **webhook** deserves a closer look because it appears in almost every payments and SaaS integration.

```dia
title: A payment webhook
sub: The merchant's site does not keep asking 'did they pay?'; the gateway rings the doorbell
seq(["Customer's app", "Merchant server", "Payment gateway", "Bank / NPCI"], [("Customer's app", "Payment gateway", "Pay ₹1,299 for order 5521"), ("Payment gateway", "Bank / NPCI", "Collect via UPI"), ("Bank / NPCI", "Payment gateway", "Success"), ("Payment gateway", "Merchant server", "Webhook: payment.captured for order 5521", "Signed, so the merchant can verify it is genuine"), ("Merchant server", "Payment gateway", "200 OK, received", "No reply? The gateway retries later"), ("Merchant server", "Customer's app", "Order confirmed")])
```

Because webhooks are retried, the same message may arrive twice. The merchant must therefore process it **idempotently**: doing it twice must have the same effect as doing it once (do not ship two parcels). Idempotency comes up again in the UPI walkthrough in the system-design chapter.

## Rate limits: the queue manager at the counter

Every API has a capacity, and some callers are greedy or malicious. A **rate limit** caps how many requests one caller may make in a time window, for example 100 per minute per user. Past the limit, the API replies **429 Too Many Requests**. A common mechanism is the **token bucket**: each caller has a bucket that refills with tokens at a steady rate; each request spends a token; an empty bucket means wait. This allows short bursts while capping the average.

IRCTC is the Indian textbook case. When Tatkal bookings open at 10 am, genuine users compete with bots and touts. IRCTC has combined rate limiting and bot detection with identity checks: Tatkal bookings on its website and app need Aadhaar-authenticated accounts from 1 July 2025, with Aadhaar OTP added from 15 July 2025 (PIB, June 2025); it deactivated over 3 crore suspicious user IDs and reports its anti-bot measures cut malicious bot traffic by 55–65% (Business Today, Sep 2026).

::: words API vocabulary
**Endpoint:** one address an API answers at (`/orders`). **Request / response:** the question and the answer. **JSON:** the common text format for data. **API key / token:** the caller's identity pass. **Rate limit:** maximum calls per time window; 429 when exceeded. **API gateway:** the front door that checks keys, applies rate limits and routes calls to the right internal service. **Versioning:** keeping `/v1/` working while `/v2/` launches, so old apps do not break. **SDK:** a ready-made code library that wraps an API for developers. **Idempotent:** safe to repeat; doing it twice equals doing it once. **Latency:** time for one call; **throughput:** calls handled per second.
:::

**Contrasting case.** Tight coupling through APIs creates dependency risk. If your app calls a third-party address-lookup API on the checkout page and that provider goes down, your checkout goes down. Good design adds a **timeout** (stop waiting after 800 ms), a **fallback** (let the user type the address manually) and sometimes a second provider.

**Why a PM cares.**

- **APIs can be the product.** Stripe, Razorpay, Twilio and the AI model providers sell APIs; their "UX" is documentation, SDKs, error messages and sandbox testing. Developer experience decides adoption.
- **Old app versions live for years.** Many users never update. Any change to an API must stay **backward compatible** or be versioned, or you break the app on their phones. Ask "which app versions does this affect?"
- **Partner and platform strategy runs on APIs.** Opening an API invites an ecosystem (Shopify's apps, UPI's third-party apps) but also creates obligations: uptime promises, support, security reviews and rate-limit policy.
- **Rate limits are a pricing tool.** Free tier: 1,000 calls a day; paid tier: more. Many AI and SaaS products price exactly this way.

::: key The one-line rule
An API is a promise: "ask me this way and I will answer that way". Keep the promise stable, limit who can call it how often, and plan for the day the other side does not answer.
:::

**In the interview.** "Explain an API to a 10-year-old" (the waiter), "How would Zomato show live order status?" (WebSockets while the app is open, push notifications when it is closed, polling as a fallback on poor networks), "A partner wants to integrate with our platform; what do you consider?" (use cases, authentication, rate limits, versioning, SLA, pricing, abuse, data privacy). A strong line: *"I'd treat the partner API as a product with its own users, developers, and its own success metric: time to first successful call."*

::: quiz Check yourself
1. Trace a request from typing `hotstar.com` to seeing the page, naming the five steps.
2. Why did an empty DNS record take down services whose databases were perfectly healthy in the October 2025 AWS outage?
3. Give one product that should use UDP and one that must use TCP, and explain why.
4. What is the difference between a 4xx and a 5xx error? Which one points to a capacity problem?
5. What does HTTPS protect, and what does it not protect?
6. Polling, WebSockets, webhooks: which would you use for (a) live rider tracking, (b) telling a merchant a payment succeeded, (c) a weather widget that refreshes hourly?
7. Why must webhook handling be idempotent?
8. *(From the SDLC chapter)* At which SDLC stage should you decide whether an API change must stay backward compatible, and who needs to be involved?
:::
