%% chapter | Technology · Cloud | Renting the computer instead of buying it | What "the cloud" really is, the IaaS–PaaS–SaaS ladder, how cloud is bought and sold, and the decisions it pushes onto a PM's desk

In 2005, a Bengaluru startup that wanted to launch a website had to buy servers, rent space in a data centre, sign a bandwidth contract and hire someone to replace failed disks at 2 am. Capacity took weeks to add, so you bought for your biggest imagined day and paid for idle machines the rest of the year. Today the same team opens an account with AWS, Microsoft Azure or Google Cloud, picks a data centre in Mumbai or Hyderabad, and is serving users within the hour. When the IPL final brings ten times the traffic, they rent ten times the machines for the evening and hand them back at midnight.

That shift is **cloud computing**: the on-demand delivery of computing resources (servers, storage, databases, networking, AI models) over the internet, paid for as you use them, instead of owned.

## The electricity analogy

A century ago, large factories ran their own power plants. Then the grid arrived, and a factory simply plugged in and paid per unit. Nobody today builds a power plant to run an office. Cloud does the same for computing.

```dia
title: Cloud is computing as a utility
analogy([("Owning a generator for your house", "On-premises servers", "You buy the capacity up front (capital expense), size it for the peak, and maintain it yourself."), ("Paying the electricity bill by the unit", "Pay-as-you-go cloud", "No upfront cost; pay for what you use (operating expense); capacity is someone else's problem."), ("The grid never 'runs out' at your house", "Elasticity", "Scale up in minutes for a spike and back down afterwards, without buying anything."), ("Leaving the AC on in an empty room", "Idle cloud resources", "The meter keeps running. Forgotten servers are the number-one cause of surprise cloud bills.")])
```

## The ladder of service models: IaaS, PaaS, SaaS

Cloud comes in layers, depending on how much the provider manages for you. The classic analogy is getting pizza.

```dia
title: Pizza as a service
sub: The further right, the more is done for you, and the less you control
cards([("On-premises: make it at home", "You buy the oven, flour, toppings; you cook and clean. You manage everything: hardware to app."), ("IaaS: take-and-bake", "You get the kitchen and oven (virtual machines, storage, network); you install and run everything on top. AWS EC2, Azure VMs."), ("PaaS: pizza delivered", "The platform runs the servers, operating system and scaling; you just bring your code and data. Google App Engine, Heroku, managed databases."), ("SaaS: eat at the restaurant", "Ready-to-use software through a browser; you just use it. Gmail, Slack, Salesforce, Zoho, Freshdesk.")], ncol=4)
```

| | IaaS | PaaS | SaaS |
|---|---|---|---|
| You get | Raw infrastructure: virtual machines, storage, networks | A platform to build, deploy and run apps | Finished software |
| Provider manages | Hardware, data centre | Hardware + operating system + runtime + scaling | Everything |
| You manage | OS, runtime, app, data, security settings | Your app and data | Your users, settings and data |
| Best for | Custom infrastructure, special needs, large scale | Shipping fast with a small team | Standard business needs (email, CRM, HR, support) |
| PM focus | Flexibility, cost control | Speed of development | Adoption, integrations, vendor fit |
| Example scenario | Enterprise building its own platform | Startup MVP | Internal collaboration tool |

The rule of thumb: **moving down the ladder toward IaaS gives you more control and more engineering responsibility; moving up toward SaaS gives you speed and less control.**

Two newer rungs matter too. **Containers** (Docker) package an app with everything it needs so it runs the same everywhere, and **Kubernetes** runs thousands of containers and restarts or adds them automatically. **Serverless** or **functions-as-a-service** (AWS Lambda) goes further: you upload a small piece of code that runs only when triggered, and you pay per execution, down to the millisecond. It is excellent for spiky, occasional work (resize an image when it is uploaded) and can get expensive for constant heavy work.

## Where the cloud lives: deployment models

```dia
title: Public, private and hybrid cloud
cards([("Public cloud", "Shared infrastructure owned by AWS, Azure, Google, used over the internet. Scalable and cheap to start; less control; compliance needs care. Most startups."), ("Private cloud", "Infrastructure dedicated to one organisation, on its own premises or hosted. High control and security; expensive and slower to scale. Some banks, defence, government."), ("Hybrid cloud", "A mix: sensitive systems (core banking) on private, customer-facing apps on public, connected. Balance of control and scale; more complex to run."), ("Multi-cloud", "Using two or more public providers, to avoid lock-in, meet local rules or use each one's best services. More resilient, much harder to manage.")], ncol=2)
```

## How cloud is bought, and how cloud products are sold

Two different pricing questions often get mixed up. As a **buyer** of cloud, a company chooses how to pay AWS. As a **seller** of a SaaS product, it chooses how to charge its own customers.

```dia
title: Buying cloud capacity: three ways to pay for the same server
sub: Discounts are the providers' published maximums; actual savings vary
src: AWS pricing pages (Savings Plans up to 72%, Spot up to 90% off On-Demand), 2026
cards([("On-demand", "Pay by the second or hour, no commitment. Most flexible, highest unit price. Good for new or unpredictable workloads."), ("Reserved / committed", "Commit to 1 or 3 years of usage for a large discount (up to about 72%). Good for the steady base load you are sure of."), ("Spot / preemptible", "Spare capacity at up to about 90% off, but the provider can take it back with two minutes' notice. Good for batch jobs that can pause.")], ncol=3)
```

A mature company mixes them: reserved capacity for the base load that runs all day, on-demand for daily peaks, spot for model training and overnight analytics.

As a **seller**, the common SaaS models are:

| Model | How it works | PM view |
|---|---|---|
| Pay-as-you-go / usage | Charge per use: per API call, per GB, per message | Fair and scales with value; revenue fluctuates; customers fear bill shock |
| Subscription | Fixed monthly or annual fee | Predictable for both sides; heavy users may cost more than they pay |
| Tiered | Plans with rising limits and features (Free, Pro, Enterprise) | Serves segments; upgrade path is the growth engine |
| Freemium | Basic free forever, premium paid | Cheap acquisition; lives or dies on free-to-paid conversion |
| Reserved / committed | Customer commits to a volume for a discount | Locks in revenue; good for enterprise deals |

## Benefits and the catches

| Benefit | The catch on the other side |
|---|---|
| **Cost efficiency:** no upfront capital; pay for use (capex → opex) | **Cost overruns:** idle servers, oversized machines and data-transfer (egress) charges produce bills nobody expected |
| **Scalability and elasticity:** add capacity in minutes | **Vendor lock-in:** deep use of one provider's special services makes switching expensive |
| **Speed to market:** infrastructure in minutes, not months | **Security is shared:** the provider secures the cloud; you must secure what you put *in* it (the "shared responsibility model") |
| **Global reach:** regions close to users worldwide | **Data residency:** some laws require data to stay in the country |
| **Reliability:** built-in backups, multiple zones, failover | **Provider outages still happen:** the AWS US-East outage of October 2025 lasted over 14 hours for some services |

**Data residency in India** is a concrete example. Since RBI's 2018 directive on storage of payment system data, payment companies must store payment data only in India. The Digital Personal Data Protection Act, 2023 and its 2025 Rules add obligations on consent and cross-border transfers of personal data. A PM launching a fintech or health product must ask early: which data can leave India, and which regions are we allowed to use?

**Contrasting case.** Cloud is not always cheaper. At very large, steady scale, owning hardware can cost less. 37signals, the company behind Basecamp and HEY, publicly moved off public cloud in 2023 and reported large savings, because its load was predictable and its team could run servers. Cloud wins on flexibility and speed; ownership can win on steady-state cost.

::: key The one-line rule
Cloud turns computing into a variable cost you can dial up and down. That makes it fast and flexible, but it also means every feature has a running cost per user that someone must watch.
:::

**Why a PM cares.**

- **Cloud cost is unit economics.** "Cloud cost per order" or "per active user" belongs on the same dashboard as contribution margin. A feature that stores every video forever or calls an expensive AI model on every page view has a real, recurring cost.
- **Build on the right rung.** For a new product, favour managed services (PaaS, SaaS) to ship fast, and move lower only when scale or control demands it. Do not build what you can rent unless it is your differentiator: **compete on unique value, not on parity** in infrastructure.
- **Design for change.** Loose coupling between modules keeps you able to swap a provider or service later and makes it easier to optimise the expensive part without touching the rest.
- **Plan for residency, latency and compliance from day one**, and choose your own revenue model (subscription, usage, tiered) so that revenue rises with the costs usage creates.

**In the interview.** "Should our startup build on AWS or our own servers?" (cloud: no capex, speed, elasticity; revisit at steady massive scale), "Explain IaaS, PaaS and SaaS with examples" (pizza analogy, then one Indian example each: a bank running VMs on Azure, a startup deploying on a managed platform, Zoho or Freshworks as SaaS), "Our cloud bill doubled; what do you do?" (break it down by service and feature; look for idle and oversized resources, egress, logging, AI calls; move steady load to committed pricing; add per-team cost dashboards and budgets). A strong line: *"I'd treat cloud cost as a product metric, not a finance surprise, and track cost per order next to conversion."*

::: quiz Check yourself
1. Explain cloud computing using the electricity analogy, including what "idle resources" means.
2. Map on-premises, IaaS, PaaS and SaaS to the pizza analogy, and give one real example of each.
3. When would you choose reserved, on-demand and spot capacity for the same product?
4. What is the shared responsibility model? Give one thing the provider secures and one the customer must secure.
5. Why might an Indian payments company be unable to use a Singapore data centre for its payment data?
6. Give one situation in which owning servers beats public cloud.
7. *(From the system-design chapter)* How does cloud elasticity relate to horizontal scaling, and why did Hotstar still pre-warm capacity?
:::
