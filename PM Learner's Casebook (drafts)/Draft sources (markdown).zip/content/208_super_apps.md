%% chapter | Product dossier · Super-apps | One app to rule them all, and why it rarely works | WeChat became the operating system of daily life in China. Almost everyone who tried to copy it elsewhere failed or retreated. The reasons are one of the best strategy lessons in product management.

A morning in Shenzhen. Li pays for her baozi breakfast by scanning a QR code in WeChat. On the metro she books a doctor's appointment through a hospital's **mini program**, a small app that runs inside WeChat and needs no download. She splits lunch with colleagues in their group chat, pays her electricity bill, and hails a car. All of it happens inside one green app she opened at 7 a.m. and never closed.

A morning in Mumbai looks different. Priya pays for chai on PhonePe, orders lunch on Swiggy, books a cab on Uber, a train on IRCTC, and chats on WhatsApp. That is five apps from five companies, and she is happy with each. Several Indian companies have tried to make her use one app instead. None has managed it.

## The job, and why it is so hard

A super-app promises the user **"do everything without switching apps, with one login and one wallet."** It promises third-party businesses **"reach a billion users without building and marketing your own app."** For it to work, three things must be true together.

```dia
title: The super-app recipe
sub: Every layer must hold, starting from the bottom
pyramid([("Monetise the ecosystem", "Ads, payments fees, lending and cloud services across all the activity"), ("Distribution for others", "Third parties build inside the app because that is where users are (mini programs)"), ("Identity and money", "One login and one wallet or payment method used everywhere"), ("A daily anchor habit", "Something users open many times a day: messaging or payments")])
```

The bottom layer is the one most copies lack. WeChat's anchor is messaging, which people open dozens of times a day. Without an anchor like that, every added service is just another icon nobody taps.

%% article | Super-apps · WeChat | The benchmark | WeChat (Weixin in China) has about 1.4 billion monthly users. It is messaging, payments, social media, search and an app store rolled into one.

**Who it is for.** Almost every smartphone user in China, plus the Chinese diaspora. Positioning: not an app but *"a way of life"*, the infrastructure of daily communication and commerce. It is owned by Tencent.

**How it grew, layer by layer.**

```dia
title: How WeChat built its layers
sub: Each step used the habit from the step before
src: Tencent announcements; industry histories
timeline([("2011", "Messaging", "Free texts and voice notes; fast growth"), ("2012", "Moments + Official Accounts", "Social feed; brands and media publish to users"), ("2014–15", "WeChat Pay + Red Envelopes", "Lunar New Year cash gifts linked millions of bank cards"), ("2017", "Mini Programs", "Apps inside WeChat, no download needed"), ("2020", "Channels", "Short video inside WeChat"), ("2025–26", "AI assistants and agents", "Yuanbao inside chats; an embedded agent in testing")])
```

**The growth hack everyone studies: Red Envelopes.** At Chinese New Year people traditionally give cash in red envelopes. In 2014–15 WeChat let users send digital red envelopes in group chats, with random amounts and "grab it first" fun. To receive or send money you had to **link a bank card**. In a few days WeChat Pay gained a user base that had taken Alipay years to build. The lesson is to **attach a new product to an existing emotional ritual inside your anchor habit**.

```dia
title: The WeChat ecosystem
sub: Messaging sits at the centre; everything else borrows its daily habit
hub("WeChat", [("Chats and groups", "The anchor: dozens of opens a day"), ("WeChat Pay", "QR payments, transfers, red envelopes"), ("Mini Programs", "Third-party apps with no install: food, rides, hospitals, shops"), ("Official Accounts", "Brands and media publish to followers"), ("Channels and Moments", "Short video and a friends' feed; ad inventory"), ("Search and AI", "Find services, content and now agents inside the app")], center_desc="1.4B monthly users")
```

**Mini programs, explained.** A mini program is to WeChat what a website is to a browser. A café can build one in weeks. Users open it by scanning a QR code at the counter, it already knows who they are and how they pay, and it disappears when they are done. For businesses it removes the two biggest costs of an app: **building it for two platforms, and getting people to install it**.

**Business model.** Tencent earns from **marketing services** (ads in Moments, Channels, mini programs and search: RMB 43.6 billion in Q2 2026, +22%), **fintech** (payment fees, wealth products, loans), **cloud services** for mini-program developers, and games distributed through WeChat. Tencent is now spending heavily on AI (Tencent Q2 2026, via China Internet Watch).

**Moat.** Among the strongest in the world: **direct network effects** (everyone you know is on it), **platform network effects** (users attract mini programs, which attract users), and **switching costs** (your contacts, payment history, and every service's account are tied to one identity).

**Metrics.** *North Star:* daily active users across communication and services. *Inputs:* messages per user, mini-program daily users, WeChat Pay transactions, Channels watch time. *Guardrails:* regulatory compliance, user trust around data, load time of mini programs.

::: key What WeChat does next: the agent layer
The next version of the super-app may not need users to open mini programs at all. Tencent is testing an **AI agent inside WeChat** that can take a request ("book a table for four near the office on Friday") and carry it out across mini programs. If it works, the super-app becomes a **super-assistant**, and its moat, one identity plus one wallet plus thousands of services, becomes even more valuable.
:::

%% article | Super-apps · Paytm | India's most famous super-app attempt | Paytm tried to be India's WeChat. It then shrank back to what it did best: payments for shopkeepers.

**What Paytm tried.** Between 2015 and 2021 Paytm added a mall, travel, movie and event tickets, games, a stockbroker (Paytm Money), insurance, lending and a payments bank, all around its **wallet**. In 2016, when demonetisation removed most cash from circulation overnight, Paytm's wallet became many Indians' first digital payment.

```dia
title: Paytm's arc
sub: From wallet to super-app to focused merchant business
src: Company filings and press reports
timeline([("2016", "Demonetisation boom", "Wallet becomes India's default digital payment"), ("2016–19", "UPI launches and grows", "Free, interoperable bank payments erode the wallet's reason to exist"), ("2017–21", "Super-app expansion", "Mall, travel, tickets, games, bank, broking, lending"), ("Nov 2021", "IPO", "India's largest IPO then; shares fell sharply on debut"), ("2024", "RBI action; ticketing sold", "Payments Bank curbed; ticketing sold to Zomato"), ("FY26", "First full-year profit", "₹552 Cr profit; merchant-first focus")])
```

**Why it did not become WeChat.**

1. **The anchor disappeared.** Paytm's anchor was the wallet. UPI, launched in 2016, let anyone pay from a bank account in any app, for free. Once the wallet was not needed, the reason to open Paytm first went with it.
2. **No messaging habit.** Indians chat on WhatsApp, not Paytm, so Paytm had to *buy* each visit with cashback.
3. **Each vertical faced a focused specialist.** MakeMyTrip in travel, BookMyShow in tickets, Amazon and Flipkart in shopping, Zerodha in broking. A super-app's travel section is rarely better than a travel app.
4. **Regulation.** A bank inside an app with many businesses drew close regulatory attention, which led to the 2024 curbs.

**What worked instead.** Paytm focused on merchants: **1.57 crore storefronts with Soundbox devices**, merchant loans, and payments. Revenue grew 28% in Q1 FY27 and the company is profitable (Paytm Q1 FY27). Selling its ticketing business to Zomato in 2024 was the clearest signal that the super-app plan was over.

## Why super-apps mostly fail outside China


Outside China the record is mostly retreat, with a few partial successes that prove the rule. **Grab** and **Gojek** in South-East Asia grew from rides to food and payments in markets that were fragmented and cash-heavy. **Kakao** (Korea) and **LINE** (Japan, Thailand) built on messaging anchors. **Tata Neu** (2022) had no anchor: Tata Digital lost **₹4,974 Cr in FY26**, and Neu is being refocused on a co-branded credit card and loyalty (Inc42, 2026). **X**'s "everything app" plan depends on X Money, still in beta.

```dia
title: Why the super-app worked in China but rarely elsewhere
versus("China, 2011–2017", [("Mobile first", "Most people's first internet device was a phone"), ("App stores fragmented", "No Google Play; installing apps was hard, so mini programs were easier"), ("Messaging monopoly", "WeChat became the anchor for a billion people"), ("Payments leapfrog", "Went from cash straight to QR codes, inside WeChat")], "India and the West", [("Strong app stores", "Apple and Google make installing specialist apps easy"), ("Anchor owned by others", "WhatsApp owns chat; UPI makes payments work in every app"), ("Best-of-breed wins", "A focused app is usually better in its category"), ("Regulators and privacy", "Antitrust, data-protection and banking rules limit bundling")], verdict="A super-app needs a daily anchor, a wallet and weak app-store distribution all at once. India has UPI, but the anchor (WhatsApp) belongs to a company whose payments failed.")
```

```dia
title: Anchor strength versus breadth of services
sub: Where the attempts sit (author's judgement)
matrix("Breadth of services", "Daily anchor strength", [("Strong anchor, narrow", "WhatsApp, PhonePe: huge habit, few services"), ("True super-app", "WeChat; partly Grab, Kakao"), ("Niche app", "One job, occasional use"), ("Mall without a door", "Many services, no reason to open daily: Tata Neu")], points=[("WeChat", 0.88, 0.62), ("WhatsApp", 0.15, 0.6), ("PhonePe", 0.4, 0.56), ("Grab", 0.7, 0.54), ("Paytm (2021)", 0.72, 0.2), ("Tata Neu", 0.62, 0.12)])
```

::: key The rule to remember
**Bundle around a habit, not around a logo.** A super-app works when one very frequent job (chatting, paying) pulls users in daily, and other services ride on that visit. A group of good businesses placed under one icon, with no shared daily habit, is a portfolio, not a super-app.
:::

## Likely interview questions

1. **"Should PhonePe become a super-app?"** It has the anchor (payments) but UPI is interoperable, so the habit is weak. Suggest adding services that sit next to payments (bills, credit, insurance) rather than food or travel.
2. **"How would you make WhatsApp India's super-app?"** It has the anchor. Build business chats with native checkout, payments, and bills and tickets as mini-apps. The risks are trust and regulators.
3. **"Why did Tata Neu struggle?"** There was no daily anchor, the brands underneath did not work together smoothly, and loyalty points alone do not create a habit.
4. **"Design a mini-program platform for India."** Solve the cold start with a few high-frequency partners (IRCTC, utilities, metro tickets), then add a developer kit and discovery through QR codes.
5. **"What metric tells you a super-app is working?"** Services used per user and the share of users who use two or more services weekly, not total downloads.

::: quiz Recall: super-apps
1. Name the four layers of the super-app recipe from bottom to top.
2. What is a mini program, and which two costs does it remove for a business?
3. Explain the Red Envelope growth hack and the lesson behind it.
4. Give three reasons Paytm did not become India's WeChat.
5. Why does UPI make an Indian super-app harder, not easier?
6. Give one super-app that partly succeeded outside China and the reason.
7. (Payments) What does WhatsApp Pay's history tell you about distribution versus habit?
:::
