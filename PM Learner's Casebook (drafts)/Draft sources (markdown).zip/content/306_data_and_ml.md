%% chapter | Technology · Data and machine learning | Teaching computers by example | What AI, machine learning and deep learning actually mean, how a model learns, how recommendations work, and how a PM decides whether a problem needs ML at all

Suppose you are the PM for fraud at a payments app and you try to catch fraud with rules. "Block any payment above ₹50,000 from a new device." "Flag five payments to different people within a minute." You write fifty rules. Fraudsters notice and switch to ₹49,000 payments spread over six minutes. You write fifty more. Meanwhile genuine users who just bought a new phone are getting blocked.

Now try something different. Take ten million past transactions, each labelled "fraud" or "genuine" after investigation, and let a program **find the patterns itself**: the combinations of amount, time, device age, location, payee history and typing speed that separate the two. When fraudsters change tactics, retrain on the new examples. That is **machine learning**.

```dia
title: Traditional programming versus machine learning
versus("Traditional programming", [("Input", "Rules written by people + data"), ("Output", "Answers"), ("Example", "IF amount > ₹50,000 AND device age < 1 day THEN block"), ("Good when", "The logic is clear, stable and must be explainable, like GST calculation or a KYC checklist.")], "Machine learning", [("Input", "Data + the right answers (labels)"), ("Output", "Rules, learned: a model"), ("Example", "Model scores each payment 0–1 for fraud risk from hundreds of signals"), ("Good when", "The patterns are too many, too subtle or change too fast to write by hand.")], verdict="ML flips programming around: instead of writing the rules, you provide examples and the computer infers the rules.")
```

## AI, ML, deep learning, generative AI: the nesting dolls

These terms are used loosely, but they fit inside each other.

```dia
title: The nesting dolls of AI
sub: Each layer is a subset of the one below it
pyramid([("Generative AI and LLMs", "Deep-learning models that create new text, images, audio, code. ChatGPT, Claude, Gemini, Midjourney."), ("Deep learning", "ML using many-layered neural networks; learns complex patterns in images, speech and language from huge data."), ("Machine learning", "Systems that learn patterns from data instead of following hand-written rules. Fraud scores, churn prediction."), ("Artificial intelligence", "The whole field: machines doing tasks that normally need human intelligence: perceiving, reasoning, deciding, including rule-based systems.")])
```

## The main ways machines learn

```dia
title: Types of machine learning
tree(["Machine learning|Learning patterns from data", [["Supervised|Learns from labelled examples", ["Regression|Predicts a number: delivery time, house price, demand", "Classification|Predicts a category: spam, fraud, will churn"]], ["Unsupervised|Finds structure in unlabelled data", ["Clustering|Groups similar items: customer segments", "Dimensionality reduction|Compresses many features into a few"]], ["Reinforcement|Learns by trial, error and reward", ["Examples|Game-playing, robotics, ranking, pricing"]], ["Self-supervised|Makes its own labels from raw data", ["Examples|LLMs predicting the next or hidden word"]]]], wrapch=22, rankdir="LR")
```

- **Supervised learning** is learning with an answer key. Show the model thousands of past orders with their actual delivery times and it learns to predict delivery time for a new order (**regression**, because the answer is a number). Show it emails marked spam or not and it learns to sort new emails (**classification**, because the answer is a category).
- **Unsupervised learning** has no answer key. Give it every customer's purchase history and it finds natural groups: weekend party shoppers, monthly bulk buyers, daily milk-and-bread buyers (**clustering**). Marketing then names and targets those segments.
- **Reinforcement learning** learns by acting and receiving rewards, like training a dog with treats. A game-playing program tries moves, wins or loses, and gradually learns strategy. It is also used to tune recommendations and prices over time, and, as a later chapter explains, to shape how chatbots respond.
- **Self-supervised learning** creates its own labels from raw data: hide a word in a sentence and ask the model to guess it. This is how today's large language models are pre-trained on vast amounts of text without anyone labelling it.

## How a model is trained

Think of a student preparing for the CAT. She practises on thousands of questions (**training**), checks herself on mock tests she has not seen and adjusts her strategy (**validation**), and finally sits the real exam once (**testing**). If she simply memorised the answers to the practice papers she would ace them and fail the real exam. In ML that failure has a name: **overfitting**.

```dia
title: The life of an ML model
sub: Most of the work, and most of the failures, are in data and monitoring, not in the algorithm
vsteps([("Define the prediction", "Exactly what are we predicting, for whom, and what decision will it drive? 'Probability this order is late by 10+ minutes.'", "A vague target produces a useless model."), ("Collect and label data", "Past orders with features (distance, restaurant, weather, time) and the true outcome (late or not).", "Garbage in, garbage out; biased data gives biased models."), ("Split the data", "Training set (~70%) to learn; validation set (~15%) to tune; test set (~15%) touched once, at the end.", "Test data must stay unseen or scores are inflated."), ("Train and tune", "The algorithm adjusts itself to fit the training data; engineers adjust settings (hyperparameters) using the validation set.", "Watch for overfitting: great on training, poor on validation."), ("Evaluate", "Score on the test set with metrics that match the business cost of errors (see precision and recall later).", "Accuracy alone is often misleading."), ("Deploy", "Serve predictions inside the product, often behind a feature flag and an A/B test.", "Decide the fallback if the model is down."), ("Monitor and retrain", "Track live performance; retrain when the world changes (data drift).", "Covid changed shopping overnight; old models broke.")], hl=[1, 6])
```

::: words Words to know
**Feature:** an input signal the model uses (order distance, hour, rain). **Label:** the right answer for a training example (late: yes). **Model:** the learned function that turns features into a prediction. **Training / inference:** learning from data / using the model to predict. **Hyperparameter:** a setting chosen by engineers, not learned (how deep a tree may grow). **Overfitting:** memorising the training data, failing on new data. **Underfitting:** too simple to capture the pattern. **Data drift:** real-world data changes so the model's past lessons stop applying. **Ground truth:** the verified correct answer, often slow or costly to get (a fraud investigation can take weeks).
:::

## Three families of algorithms, and what to ask about each

You do not need to know how the algorithms work inside. You do need to know their personalities.

| Family | Great for | Ask your team | Watch out for |
|---|---|---|---|
| **Linear models** (linear and logistic regression) | A simple, fast baseline; predictable, explainable outcomes | "Is the relationship roughly linear? How much better is anything fancier than this baseline?" | Oversimplifying; misses interactions ("late night *and* new device") |
| **Tree-based models** (decision trees, random forests, gradient-boosted trees such as XGBoost) | Tabular business data: credit scoring, fraud, churn. Often the strongest choice for spreadsheet-like data | "Can we show the business the main decision drivers?" | Overfitting if trees grow too deep |
| **Neural networks** (deep learning) | Images, speech, language, very large complex datasets | "Do we have enough data and compute? How will we explain a decision?" | The black-box problem: hard to explain a single prediction, which matters for trust, debugging and regulation |

A PM who asks "what is the simple baseline, and how much does the complex model beat it by?" earns instant respect. Many teams ship a neural network where a logistic regression would have done 95% as well at a tenth of the cost.

## Neural networks, without the maths

A neural network is loosely inspired by the brain: layers of simple units ("neurons") connected to each other. Picture a panel of judges in rows. The first row each look at raw inputs; each judge in the next row listens to the first row's opinions, **giving more weight to some judges than others**; the final judge announces a verdict. Training means adjusting how much each judge trusts each other judge until the verdicts match the right answers on millions of examples.

```dia
title: A tiny neural network scoring a payment for fraud
sub: Real networks have millions to billions of weights; the idea is the same
arch({"i1": ("Amount", "₹48,500", "L"), "i2": ("Hour", "2:40 am", "L"), "i3": ("Device age", "Registered 3 hours ago", "L"), "h1": ("Hidden unit A", "Learns 'unusual time + new device'", "B"), "h2": ("Hidden unit B", "Learns 'large amount for this user'", "B"), "o": ("Output", "Fraud probability 0.91 → step-up check", "R")}, [("i1", "h1", ""), ("i2", "h1", "weight"), ("i3", "h1", ""), ("i1", "h2", ""), ("i2", "h2", ""), ("i3", "h2", ""), ("h1", "o", ""), ("h2", "o", "")], rankdir="LR", wrapch=18)
```

The key terms: **input layer** (receives features), **hidden layers** (learn intermediate patterns nobody programmed, such as "late-night + new device"), **output layer** (the prediction), **weights** (how much each connection matters), **activation function** (decides how strongly a unit passes its signal on), and **training** (nudging all the weights, a little at a time, to reduce errors; the method is called backpropagation). Deeper networks learn more complex patterns but need more data and more computing power. Neural networks power image recognition, speech-to-text, recommendations, fraud detection and every large language model.

## Recommender systems: how Netflix, YouTube and Flipkart choose for you

Open YouTube and the home page is different for every person in your family. Recommenders decide much of what gets watched, bought and listened to on large platforms. Netflix has said for years that most of what members watch comes from recommendations rather than search. Two basic ideas sit underneath.

```dia
title: Two ways to recommend
versus("Content-based filtering", [("Idea", "'You liked this; here are similar items.' Uses item features: genre, cast, brand, price."), ("Example", "Watched three Malayalam thrillers → more Malayalam thrillers."), ("Strengths", "Works for brand-new items with good descriptions; easy to explain."), ("Weakness", "Stays in your lane: little discovery; needs good item data.")], "Collaborative filtering", [("Idea", "'People who behave like you also liked…' Uses only behaviour, not item features."), ("Example", "Fans of your three thrillers also loved a Korean drama → you get the drama."), ("Strengths", "Finds surprising, relevant items; no item metadata needed."), ("Weakness", "Cold start: new users and new items have no behaviour yet; popular items dominate.")], verdict="Almost every large product uses a hybrid, plus rules for diversity, freshness and business goals.")
```

Real systems at scale work in stages, because scoring millions of items for every user on every visit is too slow.

```dia
title: How a large-scale recommender works
sub: The funnel from millions of items to the ten you see
src: Pattern described in YouTube's published recommender paper (Covington et al., 2016); illustrative numbers
funnel([("Catalogue", "10 crore items", 1.0, "Everything that could be shown"), ("Candidate generation", "~1,000", 0.6, "Fast, rough models pull items similar to your history or liked by similar users"), ("Ranking", "~100", 0.35, "A heavier model scores each candidate: will you click, watch, buy?"), ("Re-ranking", "~10", 0.18, "Business rules: diversity, freshness, no repeats, promoted items, safety"), ("Your screen", "10 tiles", 0.1, "Your clicks and skips become new training data")])
```

**Cold start** is the classic PM problem in recommenders. New users: ask for a few preferences at onboarding, use location and device signals, and show popular items. New items: use content features and give them a little exploration traffic. **Filter bubbles** are the other: optimising only for clicks shows you more of the same, which can bore users over time or amplify harmful content. That is why re-ranking adds diversity and why "what are we optimising for?" (clicks, watch time, satisfaction surveys, long-term retention) is the most important PM question about any recommender.

## What ML is good at, and where it hurts

```dia
title: The promise and the problems of AI/ML
versus("What it gives you", [("Automation", "Handles repetitive judgement at scale: sort tickets, verify documents."), ("Personalisation", "A different, better experience for each user."), ("Better decisions", "Predictions from patterns people cannot see."), ("Scale", "Millions of decisions a second."), ("Improvement", "Gets better as data accumulates.")], "What it costs you", [("Data quality", "Poor or unrepresentative data gives wrong predictions."), ("Bias and fairness", "Amazon dropped an experimental hiring model in 2018 after it penalised CVs mentioning 'women's' (Reuters)."), ("Privacy and security", "Sensitive data must be protected; DPDP Act applies."), ("Explainability", "Hard to justify a loan rejection made by a black box."), ("Cost and hallucination", "Compute is expensive; generative models can produce confident nonsense.")], lc="#379A8B", rc="#E3120B")
```

## Should this be an ML feature at all? A PM's checklist

```dia
title: Five questions before building an AI/ML feature
cards([("1. Product goal", "What user problem are we solving? Why does it need ML rather than a rule? How does it support the product goal?"), ("2. Data readiness", "What data do we have and need? Is it accurate, representative and unbiased? Enough of it? Can we get labels?"), ("3. MVP and integration", "What is the smallest AI feature that delivers value? How does it fit into the product? What happens when the model is unavailable?"), ("4. Success metrics", "Model metrics (precision, recall), product metrics (conversion, CTR, retention) and the acceptable false-positive / false-negative trade-off."), ("5. Monitoring and trust", "How will users understand and trust outputs? How do we detect drift? What is the rollback or fallback plan?")], ncol=3)
```

::: key The one-line rule
Use ML when the pattern is real, the data exists, the rules would be too many or change too fast, and a wrong answer is survivable or catchable. Otherwise, write the rule.
:::

**Contrasting case.** Many "AI features" are better as rules. Calculating GST, enforcing a refund policy, or routing tickets that contain an order ID needs no model. ML adds cost, unpredictability and a monitoring burden; a PM should be able to say "this does not need ML" as confidently as "this does".

%% article | Technology · Generative AI | From predicting to creating: generative AI | How GenAI differs from the ML above, what it can generate, and the new problems it brings

Traditional ML **predicts or classifies**: is this payment fraud, will this user churn, how long will delivery take. **Generative AI** **creates** new content: an email, an image, a song, a working piece of code, a video. It learns the patterns of enormous datasets well enough to produce new examples that fit them.

```dia
title: Traditional ML versus generative AI
versus("Traditional ML", [("Output", "A prediction: a number, a category, a score."), ("Data", "Often structured, business-specific tables."), ("Example", "A fraud score of 0.91 on one payment."), ("Evaluation", "Clear right answers: was it fraud or not?")], "Generative AI", [("Output", "New content: text, images, audio, video, code."), ("Data", "Huge, mostly unstructured, multimodal datasets."), ("Example", "Drafting a polite reply to an angry customer email."), ("Evaluation", "Many acceptable answers; quality is judged against a rubric (see the chapter on evals).")], verdict="GenAI is built on deep learning but changes the product problem: outputs are open-ended, so defining 'good' becomes the hard part.")
```

| Type | What it does | Popular products | PM use cases |
|---|---|---|---|
| Text | Human-like writing, summarising, answering | ChatGPT, Claude, Gemini | Support assistants, summaries, content drafts, search |
| Image | Pictures from a text prompt | Midjourney, DALL·E, Adobe Firefly, Imagen | Marketing creatives, product mock-ups, catalogue images |
| Code | Writes, explains and fixes code | GitHub Copilot, Cursor, Claude Code | Developer productivity, rapid prototypes |
| Audio | Speech and music | ElevenLabs, Suno | Voice assistants, dubbing, accessibility, vernacular content |
| Video | Video from text or images | Veo, Runway, Sora | Ads, product demos, training content |

Common applications: conversational assistants and customer support, content creation and summarisation, enterprise knowledge assistants, coding help, marketing and design automation, and increasingly **agents** that take actions (covered two chapters from now).

The challenges are new in kind, not just in degree: **hallucinations** (fluent, confident, false statements), **bias** in generated content, **privacy and security** risks (users paste sensitive data; attackers hide instructions in documents), **high and variable compute cost** per use, and **copyright and IP** questions about training data and outputs. Each has a product answer, and the next three chapters cover them.

**In the interview.** Expect "What's the difference between AI, ML and deep learning?" (the nesting dolls, with one example each), "How does Netflix recommend?" (content-based versus collaborative, cold start, the candidate–ranking funnel, what it optimises), "Would you use ML for X?" (the five-question checklist, and be willing to say no), and "What could go wrong with this model?" (bias in data, drift, explainability, fallback). A strong line: *"Before choosing a model I'd ask what decision it drives and what a wrong prediction costs. For loan approvals I'd accept a slightly less accurate but explainable tree model, because we must tell rejected applicants why."*

::: quiz Check yourself
1. Explain the difference between traditional programming and ML using the fraud example.
2. Place AI, ML, deep learning and generative AI in the nesting dolls, with one example each.
3. Is predicting next week's demand for onions regression, classification or clustering? What about grouping customers by shopping style?
4. What are the training, validation and test sets for? What is overfitting, in the CAT analogy?
5. When would you prefer a tree-based model over a neural network?
6. Explain the cold-start problem and two ways to reduce it for a new user.
7. Why does a large recommender use candidate generation before ranking?
8. *(From the system-design chapter)* A fraud model runs on every UPI payment. What should the product do if the model service times out?
:::
