%% chapter | Product dossier · Ad tech | The auction that runs before the page loads | Every free app and website is paid for by an auction that finishes in about a tenth of a second. Google and Meta run the biggest. InMobi and Media.net, both built in India, show how smaller players survive around them.

At 9:02 p.m. you search Google for "running shoes under ₹3,000", tap nothing, and go to a cricket news site. The page takes a moment to load. In that pause your browser asked the site's ad server for an ad. The ad server sent a description of the slot, the page and (if allowed) some signals about you to an exchange. Dozens of advertisers' buying systems bid, one won, and a shoe ad appeared next to the match report. The whole process took about **100–200 milliseconds**. It happens billions of times a day, and it pays for most of the free internet.

## The job, and the market

Advertisers hire ad tech for **"reach the right people at the right moment, at a price that pays back, and prove it worked."** Publishers such as news sites, apps and games hire it for **"earn the most per page view or app session without driving readers away."** Users never hire it, but they have a stake in it: **"keep the internet free, show me relevant ads, don't be creepy."** Most ad-tech product decisions trade those three interests against each other.

```dia
title: India's digital ad market, 2025
sub: Share of ₹94,700 Cr digital ad spend (+26% YoY)
src: FICCI-EY Media & Entertainment report (Mar 2026), via Storyboard18
stack100([("2025", [("Google + Meta (search, social, video)", 64), ("E-commerce / retail media", 23), ("Everyone else", 13)])], note="Retail media (ads on Amazon, Flipkart, Blinkit, Zomato) grew 50% to ₹22,000 Cr. 'Everyone else' includes news sites, OTT, InMobi, ShareChat and others.")
```

## How the stack works

```dia
title: The ad-tech stack, from advertiser to your screen
sub: The open web; walled gardens like Google Search and Meta do all of this inside one company
layers([("Advertiser and agency", "Sets budget, audience, creative and goal (clicks, installs, sales)", "A shoe brand and its media agency"), ("DSP (demand-side platform)", "Software that bids for the advertiser in real time", "Google DV360, The Trade Desk, InMobi DSP"), ("Ad exchange", "Marketplace where bids meet ad slots; runs the auction", "Google AdX, others"), ("SSP (supply-side platform)", "Software that sells a publisher's slots to many exchanges and buyers", "InMobi Exchange, Media.net, PubMatic"), ("Publisher ad server", "Decides which ad fills each slot, including direct deals", "Google Ad Manager (DFP)"), ("Publisher and user", "The app or site you use; the ad appears here", "A cricket news site")])
```

```dia
title: One real-time bidding auction
sub: About 100–200 ms from page load to ad on screen
src: Simplified OpenRTB flow
seq(["Your phone", "Publisher ad server", "Exchange / SSP", "Advertisers' DSPs"], [("Your phone", "Publisher ad server", "Page loads; ad slot needs an ad", ""), ("Publisher ad server", "Exchange / SSP", "Bid request: slot, page, device, consented signals", "Privacy rules decide what can be sent"), ("Exchange / SSP", "Advertisers' DSPs", "Who wants this impression?", "Dozens of bidders in parallel"), ("Advertisers' DSPs", "Exchange / SSP", "Bids in under ~100 ms", "Late bids are ignored"), ("Exchange / SSP", "Your phone", "Winning ad delivered and counted", "Impression and click tracked")])
```

```dia
title: Walled gardens versus the open web
versus("Walled gardens (Google Search, YouTube, Meta, Amazon)", [("Data", "Logged-in users; first-party data on intent, interests and purchases"), ("Stack", "Buying, auction, serving and measurement all in-house"), ("Advertiser view", "Easy, effective, but hard to verify independently")], "Open web (programmatic)", [("Data", "Thin signals; depends on cookies, device IDs, context"), ("Stack", "Many companies in the chain, each taking a fee"), ("Advertiser view", "More choice and transparency, but more waste and fraud")], verdict="Privacy changes (Apple's 2021 tracking prompt, India's DPDP Act) weakened open-web targeting and strengthened walled gardens and contextual ads.")
```

%% article | Ad tech · Google | The intent machine | Google's ads work because people tell it what they want. Its search auction is the most studied pricing system in product management.

**Who it is for.** Advertisers of every size, from a Jaipur dentist to Unilever. Publishers use AdSense and Google Ad Manager to sell their space. Positioning: *"be there when customers are looking."* Search ads grew **17%** in Q2 2026 and YouTube ads 13%, and **AI Mode** in Search passed 1 billion monthly users (Alphabet Q2 2026).

**The search auction.** Google does not simply sell the top spot to the highest bidder. Each ad gets an **Ad Rank ≈ bid × quality** (quality means expected click-through, relevance and landing-page experience). The winner pays only enough to beat the next ad's rank. Better ads therefore pay less, which keeps results useful and users clicking.

```dia
title: Why the highest bid doesn't always win
sub: Two advertisers bidding for 'running shoes under 3000'; simplified
src: Simplified Google Ads auction logic; values illustrative
formula([("Brand A", "Bid ₹50 × quality 4", "Ad Rank 200"), ("Brand B", "Bid ₹30 × quality 8", "Ad Rank 240: wins"), ("B's price per click", "Next rank ÷ own quality + ₹0.01 = 200 ÷ 8", "≈ ₹25")], result="B wins the top slot and pays about ₹25, half of A's bid, because its ad is more useful", ops=["vs", "→"])
```

```dia
title: A Google results page in 2026, annotated
sub: Ads, AI answers and organic results compete for the same screen
phone([("Search: running shoes under 3000", 0.5, "#DCEFE0"), ("AI Overview (with sponsored product slots)", 1.4, "#DDE8F0"), ("Sponsored: shopping ads with prices", 1.0, "#F6E6B8"), ("Sponsored: text ad", 0.5, "#F6E6B8"), ("Organic results", 1.4), ("People also ask", 0.5)], [(0, "Intent in the query", "The user states exactly what they want. That is why search ads convert best."), (1, "AI Overview", "AI answers keep users on Google. Ads inside them are the new inventory."), (2, "Shopping ads", "Price and image in the ad; paid per click."), (3, "Text ads, labelled", "The 'Sponsored' label keeps trust. Guardrail: users must not feel tricked."), (4, "Organic results", "Unpaid; what makes users return and trust the page.")])
```

**The publisher side, and the 2026 ruling.** Google also runs the most used **publisher ad server** (Google Ad Manager, formerly DFP) and the largest **exchange** (AdX). In April 2025 a US court ruled that Google had illegally monopolised these markets. On **16 September 2026** Judge Brinkema's remedies were unsealed. Google **does not have to sell AdX**, but must make AdX and DFP work with the open-source **Prebid** system, send AdX bids to rival ad servers on the same terms, share bid data with publishers, stop favouring its own tools, and accept a technical monitor for six years (AdExchanger, Sep 2026).

**Moat.** **Intent data** from search is a cornered resource. **Scale** on both sides of the market. **Switching costs** for advertisers whose campaigns, data and skills are built on Google Ads. The risk is that AI assistants answer questions directly, which changes where ads appear and how many clicks there are.

**Metrics.** *North Star:* advertiser value delivered (conversions at target cost). *Inputs:* queries with commercial intent, ad click-through rate, conversion rate, advertisers active. *Guardrails:* user satisfaction with results, ad load per query, invalid-click rate.

%% article | Ad tech · Meta | The prediction machine | Meta cannot see what you search for. It predicts what you will buy from what you do, and it has become the best system in the world at doing that.

**Who it is for.** Advertisers who want to create demand, not just capture it: D2C brands, app developers, small businesses. Positioning: *"find your customers, wherever they are across our apps."* Meta's **Q2 2026 revenue was $60.8 billion (+28%)**, with ad impressions up 14% and price per ad up 12% (Meta).

**How the auction differs.** Meta's auction ranks ads by **total value ≈ bid × estimated action rate + ad quality**. The "estimated action rate" is Meta's prediction that *this* person will click, install or buy. The better Meta predicts, the more each impression is worth to advertisers, and the more Meta earns without showing more ads.

| Product | Advertiser problem | Why designed this way | Metric |
|---|---|---|---|
| Advantage+ campaigns | "I don't know whom to target" | AI chooses audience, placement and budget | $75B annual run rate (Meta) |
| AI creative tools | "I can't make 20 ad versions" | Generates images, video and text variants | 9M small businesses using them |
| Click-to-WhatsApp ads | "Indian customers want to chat first" | Ad opens a WhatsApp chat with the business | Conversations started |
| Reels ads | "Attention moved to short video" | Full-screen ads between Reels | Reels ad revenue |
| Conversions API | "Apple's tracking prompt hid my results" | Sends conversion data server-to-server with consent | Measured conversions |

**The privacy shock and the answer.** When Apple introduced **App Tracking Transparency** in 2021, most users declined tracking, and Meta said the change would cost it about $10 billion in 2022. Meta's response was to invest in **AI that predicts from less data**. It now reports that new AI ranking models raised ad conversions by up to 15.7% on Facebook (Meta Q2 2026). The lesson for product managers: *when a key input disappears, the company with the best models recovers first.*

**Moat.** Scale of engagement data across 3.6 billion daily people, AI infrastructure (capex of $130–145 billion in 2026), and millions of small advertisers who have learned its tools. Risks: regulation (EU, India's DPDP Act), teen-safety concerns, and dependence on Apple and Google platforms.

**Metrics.** *North Star:* advertiser conversions at target cost. *Inputs:* impressions, conversion rate, advertisers using Advantage+, creative variants per campaign. *Guardrails:* ad load and user sentiment, policy-violating ads, and scam ads.

%% article | Ad tech · InMobi | India's first unicorn, on the lock screen | InMobi built a mobile ad network from Bengaluru in 2007, then bet on Glance, content on the phone's lock screen. In 2025 its founders bought back control ahead of an Indian listing.

**Who it is for.** On the buy side, app developers and brands wanting mobile reach, especially in Asia. On the sell side, app publishers selling their ad slots through InMobi's exchange. Positioning: *"mobile-first advertising and discovery."*

**What it runs.** (1) **InMobi Advertising**: a DSP for advertisers and an exchange/SSP for app publishers, focused on in-app ads. (2) **Glance**: a lock-screen content service pre-installed through deals with Android phone makers, which shows news, games and shopping cards when you wake your phone. It also owns the short-video app **Roposo**.

**Why Glance is interesting, and controversial.** The lock screen is the most-viewed screen on any phone, dozens of times a day. Owning it gives huge reach without users downloading anything, which is a **distribution** advantage. But because it comes pre-installed and users did not choose it, it draws complaints about intrusiveness. The guardrail is **opt-out rates and user complaints**, not only views.

**Business.** InMobi is private. Estimates put its annual revenue at roughly **$600–700 million**. In 2025 it bought back SoftBank's stake for about **$250 million**, financed with debt, leaving its founders with majority control ahead of a planned Indian IPO (IPO Central, 2025).

**Moat.** Relationships with Android phone makers (a cornered distribution channel), in-app data at scale in emerging markets, and a full stack (DSP + SSP). Its weaknesses: dependence on phone makers' deals, and competition from Google's and Meta's own app-install ads.

::: key What I would build next at InMobi / Glance
**User-controlled lock screen.** *Problem:* users feel Glance was pushed on them. *Bet:* a first-boot choice of topics (cricket, recipes, jobs) with one-tap off. *Metric:* 30-day retention of users who opted in, and revenue per opted-in user (which should rise as it becomes more relevant).
:::

%% article | Ad tech · Media.net | Ads that read the page, not the person | Media.net, built in Mumbai and Dubai, runs the contextual ads behind the Yahoo and Bing network. As tracking gets harder, its old-fashioned idea is back in fashion.

**Who it is for.** Publishers such as news sites, blogs and reference sites that want revenue from ads matched to their content. Advertisers reach them through Microsoft's and Yahoo's search advertising. Media.net was founded by Divyank Turakhia in 2010 and sold to a Chinese consortium (Miteno) in 2016 for about **$900 million** (TechCrunch).

**How contextual advertising works.** Instead of tracking *who* you are, the system reads *what the page is about*. An article on marathon training shows ads, or "related searches" links, for running shoes. When a reader clicks, Media.net and the publisher share the advertiser's payment. It is essentially **search advertising placed on content pages**.

```dia
title: Behavioural versus contextual targeting
versus("Behavioural (tracking-based)", [("Signal", "Your browsing history, app use, purchases"), ("Strength", "Precise; follows you across sites"), ("Weakness", "Needs cookies or IDs; privacy laws and Apple limit it")], "Contextual (content-based)", [("Signal", "The words and topic of the page you're reading"), ("Strength", "Privacy-safe; works without personal data"), ("Weakness", "Less precise; depends on content quality")], verdict="Contextual targeting was old-fashioned in 2015. After Apple's ATT, the EU's GDPR and India's DPDP Act, it is a growth market again.")
```

**Moat.** Its long-standing position running the **Yahoo! Bing Network Contextual Ads** programme, a large engineering team in India, and semantic technology that understands page content. The risk is dependence on one demand partner, plus publishers' traffic falling as AI answers reduce clicks to websites.

::: key What I would build next at Media.net
**Contextual ads for AI answers.** *Problem:* AI chat answers are becoming a new kind of "page", and they have no ad model beyond the big platforms. *Bet:* a contextual ad unit that AI apps and publishers can place next to generated answers, matched to the topic and not the person. *Metric:* publisher revenue per 1,000 AI answers; user complaints (guardrail).
:::

## Comparing the four

| | Google | Meta | InMobi | Media.net |
|---|---|---|---|---|
| Core signal | Search intent | Predicted interest from behaviour | In-app and lock-screen context | Page content |
| Position | Walled garden + open-web stack | Walled garden | Open-web mobile (DSP + SSP) + Glance | Contextual network, publisher side |
| Main product | Search, YouTube, Ad Manager, AdX | Advantage+, Reels, click-to-WhatsApp | InMobi Exchange, Glance | Contextual ads, related searches |
| Moat | Intent data, scale | Engagement data, AI | Phone-maker distribution | Demand partnership, semantic tech |
| Main risk | Antitrust, AI answers | Privacy, regulation | Intrusiveness, OEM deals | Partner dependence, falling clicks |

```dia
title: Where each player gets its targeting signal
sub: Author's judgement
matrix("Owns the audience directly (logged-in users)", "Uses personal data (vs context)", [("Personal data, rented audience", "Open-web DSPs relying on IDs"), ("Personal data, own audience", "Meta, Google: walled gardens"), ("Context, rented audience", "Media.net: reads the page"), ("Context, own audience", "Glance lock screen, retail media")], points=[("Meta", 0.85, 0.66), ("Google", 0.72, 0.58), ("InMobi Exchange", 0.25, 0.58), ("Media.net", 0.18, 0.18), ("Glance", 0.66, 0.24)])
```

## Likely interview questions

1. **"Explain real-time bidding to a non-technical person."** An auction for every ad slot, finished in the time a page takes to load. Name the buyer (DSP), the seller (SSP) and the marketplace (exchange).
2. **"Why does Google charge the winner less than its bid?"** Ad Rank combines bid and quality, and the winner pays just enough to beat the next rank. This rewards useful ads and keeps users clicking.
3. **"Meta's ad revenue per user in India is a fraction of the US. How would you raise it?"** Click-to-WhatsApp ads for small businesses, UPI-linked conversions, regional creatives, and better measurement.
4. **"Design metrics for a new ad format in AI answers."** Advertiser conversions, user satisfaction with answers, and ad load per answer. Guardrail: trust in the answer.
5. **"Apple blocks tracking. You're a PM at a mobile ad network. What do you do?"** Contextual signals, first-party data partnerships with consent, on-device modelling, and measurement based on aggregate data.
6. **"What changes for publishers after the 2026 Google ad-tech ruling?"** Easier use of rival ad servers and Prebid with AdX demand, more transparency on bids. Watch whether publisher revenue per 1,000 views rises.

::: quiz Recall: ad tech
1. Name the parts of the open-web ad-tech stack in order, with one example each.
2. Walk through an RTB auction in five steps.
3. Compute the price paid: Brand X bids ₹40 with quality 5; Brand Y bids ₹25 with quality 10. Who wins and what do they pay?
4. How did Meta respond to Apple's App Tracking Transparency?
5. What is contextual advertising, and why is it growing again?
6. What did the September 2026 Google ad-tech remedies require, and what did they not require?
7. (Messaging) How do click-to-WhatsApp ads link Meta's ad business to WhatsApp's revenue?
:::
